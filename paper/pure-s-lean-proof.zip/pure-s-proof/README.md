# Universal Computation with the S Combinator under Parallel Innermost Reduction

Markus Baumann · Formal proof supplement

The 81 Lean files in `formal/` define the reduction, its observers and the machine simulations. Start with `formal/Certified.lean` for the binary-string input–output theorem, `formal/Majority.lean` for all detections along the single-contraction schedule and `formal/Chronology.lean` for the chronological recovery theorem. The nine declarations checked by Nanoda are listed in [the verification record](verification.txt).

The [one-page audit guide](TCB_AUDIT.md) maps the mathematical definitions to source lines and contains the exact types of all nine theorems in a collapsible section.

## Replay the proof

Install [Elan](https://github.com/leanprover/elan), Git and Python 3.10 or later. In the directory containing this file run

```sh
lake exe cache get Mathlib.Computability.Halting Mathlib.Computability.PartrecCode Mathlib.Computability.Reduce Mathlib.Computability.StateTransition Mathlib.Computability.TuringMachine.PostTuringMachine Mathlib.Computability.TuringMachine.ToPartrec Mathlib.Data.Fintype.EquivFin
lake env python3 verify.py --fresh --examples
```

The first command obtains the pinned library dependencies and their cached build products. The second compiles every local proof from source in a new temporary directory, checks the axiom reports for the nine declarations and replays every local module with Lean’s kernel. The `--fresh` option also replays the entire import closure of `Certified`, `Chronology` and `Majority`, separately, from an empty kernel environment. The `--examples` option runs the six supplementary Python demonstrations. The Lean summary begins with `PASS: 81 source modules compiled and replayed`.

## Check the exported proofs with Nanoda

After fetching the cache, run

```sh
python3 check_external.py
```

This builds the requested proof modules with Lake, invokes `leanexport` and checks the declarations and their dependencies with `nanoda_bin`. The script uses these programs from the pinned Lake environment. For an installation with separately installed binaries, pass their paths with `--exporter` and `--checker`. It prints the SHA-256 digest of the export and the names of all nine checked declarations. The permitted axioms are `propext`, `Classical.choice` and `Quot.sound`.

The exact toolchain and library revision, the release outputs and the proof-export digest are recorded in [verification.txt](verification.txt). The transcripts appear in [verification/](verification/). The programs in `code/` illustrate small instances. The quantified mathematical claims are the Lean theorems.

For a short worked example, run `python3 code/pure_s_two_cell.py` from this directory.
