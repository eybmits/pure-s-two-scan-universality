# Direct simulation by pure S reduction

This package accompanies Markus Baumann's *Direct Simulation of Turing Machines by Parallel Innermost S-Reduction*. Start with the paper. The smallest running example needs only Python. The proof replay also needs Lean and its two checking tools.

## Watch three machine steps

From this directory, run

```sh
python3 canonical_demo.py
```

The machine has one state. It writes 1, moves right on 0 and left on 1. Its initial tape contains 01. The program loads the raw S tree exported by Lean, applies the same parallel innermost rule to the whole tree, and starts a fresh observation at its root after each round. It uses sharing and demand-driven evaluation to represent large trees. The evaluator has no access to the machine, transition table or reader.

| Round | Depth of reported node | Direction | Focus stack | Opposite stack |
| ---: | ---: | --- | --- | --- |
| 0 | 0 | Right | 01 | empty |
| 28 | 20 | Right | 1 | 1 |
| 238 | 222 | Left | 1 | 1 |
| 546 | 522 | Left | empty | 11 |

The script checks all rounds from 0 through 546. For the first eight rounds it also compares the entire demand-driven tree with an eager reduction. Five of the 90 tags are placed first to shorten directory lookup in this example. All 8,100 entries remain. Run `python3 count_leaves.py` to reproduce the expanded tree and checkpoint sizes in Section 6. A second demo, `python3 direct.py`, uses a balanced directory and reaches a halt. Its round numbers apply to that example. The alternate demo's Python reader assumes a well-formed machine seed. The Lean reader is defined on every ground S tree.

## Replay the proofs

Use Python 3.10 or later, Git, the Lean 4.35.0 release including `lake`, `leanchecker` and `leanexport`, and Nanoda 0.4.19 (`nanoda_bin`). The Lake manifest records exact revisions of Mathlib and its dependencies. The toolchain version is in `lean-toolchain`.

With these executables on PATH, run

```sh
python3 verify.py
```

The first run needs network access and disk space for the pinned dependencies. To reuse an installed Mathlib checkout and compiled dependencies, pass its enclosing Lake packages directory. The following commands first obtain the relevant cache, then reuse it for the isolated build.

```sh
lake exe cache get Mathlib.Computability.TuringMachine.ToPartrec Mathlib.Computability.TuringMachine.PostTuringMachine Mathlib.Computability.PartrecCode Mathlib.Computability.StateTransition
python3 verify.py --packages .lake/packages
```

`--lean-bin`, `--exporter`, and `--nanoda` accept alternate executable locations. The verifier copies the local proof sources into a new temporary project, builds them, checks the dependency revisions, prints the types and axiom sets, replays the imported modules with an empty Lean kernel environment, and checks the exported declarations with Nanoda. It also regenerates the example seed and requires byte equality before replaying the Python examples. The release run is in `checks/`. Subsequent runs write to `replay-checks/`. Logs identify which constants were checked. Source and proof-export digests are recorded separately.

To inspect and regenerate just the runnable example in an ordinary Lake build, use

```sh
lake build
lake env lean --run CanonicalDemo.lean regenerated.dag
cmp canonical_seed.dag regenerated.dag
python3 test_direct.py
```

## What the statements mean

| Question | Where to look in the Lean sources |
| --- | --- |
| What is an S tree and one innermost round? | `TwoScans.Term` in `Anchors.lean` and `TwoScans.Frames.pi` in `Frames.lean`. |
| How is the next physical call built? | `DirectControlled.span_step` in `DirectControlledStep.lean`, the tape equations in `DirectMemory.lean`, and the finite table in `DirectMemoryRoute.lean`. |
| Why does a new observer find exactly the correct call? | `DirectNesting.strict_ancestry` shows that the next absolute address properly extends the last and specifies the result on every intervening round. `DirectTrajectory.selection_regular` gives a finite bottom-up automaton for a marked address. |
| How are the two stacks read without running the machine? | `DirectMemory.Decode.read_correct` and `DirectCost.pair_budget`. Each recursive visit follows a proper subtree. The decoder receives the alphabet and the selected S tree. |
| What relates the simulated model to a standard Turing machine? | `DirectPost.respects` implements each Mathlib TM0 move with one oriented step and each stationary write with two. `DirectOutput.source_signal` identifies exactly the terminal tape output. |
| Is the halting condition regular on arbitrary raw trees? | `DirectQueries.hit_regular` and `DirectCertified.read_regular`. The fixed terminal-state tag test uses no machine transition function. |
| Does the same system compute every partial computable function on binary strings? | `DirectCertified.universality` names the concrete encoder and reader before it quantifies over the function. `DirectSerial.first_output` gives a first-hit protocol after individual contractions using two copies. |

The formal universal transition table exists by Mathlib's finite universal-machine construction. A supplied finite table can be compiled directly, as in the runnable one-state example. The paper gives the linear-time implementation argument for fixed interfaces on an expanded tree. The formal cost lemmas bound the depth, number of descriptor visits and decoded stack lengths. Kernel acceptance concerns the stated propositions and definitions. It is distinct from external human review and the decision of the prize committee.

The earlier two-scan manuscript cited in the paper is included as `references/TwoScan.pdf` (version 1.2.0). To build the direct-emulation paper, run `latexmk -pdf -cd paper/main.tex`. Markus Baumann directed the research. OpenAI Codex assisted extensively with proof development, Lean formalization, testing and writing.
