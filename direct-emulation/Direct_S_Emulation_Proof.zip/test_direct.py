"""Reference checks for raw rounds, demand-driven snapshots and machine readout."""

from functools import lru_cache
from itertools import product
import unittest

from direct import CHECK, Encoding, Label, Machine, Trees, chain, decode, inspect, run, snapshot
from lazy_snapshot import Snapshots


# The unshared reference uses None for S and plain tuples for application.
# It returns whether the input contained a redex, separately from the reduct.
@lru_cache(maxsize=None)
def reference_round(term):
    if term is None:
        return False, None
    left, right = term
    left_active, left_result = reference_round(left)
    right_active, right_result = reference_round(right)
    if left_active or right_active:
        return True, (left_result, right_result)
    if left is not None and left[0] is not None and left[0][0] is None:
        x, y = left[0][1], left[1]
        return True, ((x, right), (y, right))
    return False, term


def raw_reference_cases(raw, limit):
    sizes = [[], [(0, None)]]
    for leaves in range(2, limit + 1):
        sizes.append([
            (raw.app(l, r), (lt, rt))
            for size_l in range(1, leaves)
            for l, lt in sizes[size_l]
            for r, rt in sizes[leaves - size_l]
        ])
    return [term for group in sizes for term in group]


def observe(enc, root, mode=CHECK):
    """Read one full snapshot, recording which indirect pop branches are followed."""
    popped = []
    while True:
        choice = inspect(enc, root, mode)
        if mode[0] == 'pop' and choice[0] == 'down':
            popped.append(enc.label_after(root).kind)
        if choice[0] != 'down':
            result = decode(enc, choice) if choice[0] == 'report' else None
            return result, popped
        _, side, mode = choice
        root = (enc.t.right if side else enc.t.left)[root]


def coordinate_view(config, head):
    _, d, focus, other = config
    step = 1 if d else -1
    cells = {head + i * step: v for i, v in enumerate(focus)}
    cells.update({head - (i + 1) * step: v for i, v in enumerate(other)})
    return {i: v for i, v in cells.items() if v}


class DirectVerification(unittest.TestCase):
    def test_all_ground_terms_through_nine_leaves(self):
        raw = Trees()
        lazy = Snapshots(raw)
        cases = raw_reference_cases(raw, 9)
        self.assertEqual(len(cases), 2056)

        @lru_cache(maxsize=None)
        def expand(t):
            return None if t == 0 else (expand(raw.left[t]), expand(raw.right[t]))

        @lru_cache(maxsize=None)
        def realize(t):
            if isinstance(t, int):
                return t
            l, r = lazy.children(t)
            return raw.app(realize(l), realize(r))

        for first, source in cases:
            eager, expected = first, source
            for age in range(9):
                active, following = reference_round(expected)
                lazy_term = lazy.at(first, age)
                self.assertEqual(realize(lazy_term), eager)
                self.assertEqual(expand(eager), expected)
                self.assertEqual(lazy.normal[lazy_term], not active)
                self.assertEqual(lazy.arity[lazy_term], raw.arity[eager])
                eager, expected = raw.pi(eager), following

    def test_real_seed_all_rounds_through_first_transition(self):
        # A one-step writer. Run the full eager S tree including its unused
        # table branches all the way through detection, for both input symbols.
        machine = Machine(2, 1, lambda q, bit: (1, 1 - bit, 1))
        for bit in (0, 1):
            start = (0, 1, (bit,), ())
            enc = Encoding(machine)
            eager = run(enc, start, 1, 'whole')
            self.assertEqual(eager, run(enc, start, 1, 'lazy'))
            self.assertEqual(eager, run(enc, start, 1, 'projected'))
            self.assertEqual(eager[-1][1], (1, 1, (), (1 - bit,)))

            raw = enc.t
            seed = enc.seed(start[2], start[3], *start[:2])
            engine = Snapshots(raw)
            t = seed
            observed = []
            for age in range(eager[-1][0] + 1):
                enc.t = raw
                eager_report = snapshot(enc, t)
                enc.t = engine
                self.assertEqual(snapshot(enc, engine.at(seed, age)), eager_report)
                if eager_report is not None:
                    observed.append((age, eager_report))
                t = raw.pi(t)
            enc.t = raw
            self.assertEqual(observed, eager)

    def test_indirect_pop_and_tape_identity_after_reversals(self):
        directions = (0, 1, 0, 1, 1)
        def delta(q, bit):
            return (q + 1, 1 - bit, directions[q]) if q < len(directions) else (q, bit, 1)
        machine = Machine(6, 5, delta)
        start = (0, 1, (0, 1, 1, 1), (1, 0))
        enc = Encoding(machine)
        events = run(enc, start, 5, 'projected')
        self.assertEqual(events, run(enc, start, 5, 'lazy'))
        self.assertEqual([k for k, _ in events], [0, 31, 64, 99, 136, 185])

        # A coordinate-indexed tape independently checks each decoded tape.
        head = 0
        tape = coordinate_view(start, head)
        for _, config in events:
            q, direction, focus, _ = config
            self.assertEqual(coordinate_view(config, head), tape)
            self.assertEqual(focus[0] if focus else 0, tape.get(head, 0))
            if q == machine.halt:
                break
            _, written, move = delta(q, tape.get(head, 0))
            if written:
                tape[head] = written
            else:
                tape.pop(head, None)
            head += 1 if move else -1

        seed = enc.seed(start[2], start[3], *start[:2])
        engine = Snapshots(enc.t)
        enc.t = engine
        longest_turn_pop = 0
        reports = []
        for k in range(events[-1][0] + 1):
            report, trace = observe(enc, engine.at(seed, k))
            longest_turn_pop = max(longest_turn_pop, trace.count('turn'))
            if report is not None:
                reports.append((k, report))
        self.assertGreaterEqual(longest_turn_pop, 2)
        self.assertEqual(reports, events)

    def test_unchosen_checkpoint_shape_is_ignored(self):
        enc = Encoding(Machine(2, 1, lambda q, bit: (1, bit, 1)))
        g = enc.t
        u = enc.base((1,), 0, 1)
        v = enc.base((0,), 0, 1)
        e = g.pair(u, g.cell(v))
        h = g.pair(v, g.pair(v, e))
        label = Label('straight', 1, 1, 1, False)
        tag = enc.tag(label)
        n = g.cell(enc.descriptor(label, h))
        tree = g.app(g.installer(tag), h)
        for _ in range(8):
            tree = g.pi(tree)
        builder = g.left[g.left[tree]]
        fake = g.left[builder]
        self.assertEqual(fake, g.app(n, n))
        self.assertEqual(inspect(enc, fake, CHECK)[0], 'report')
        # The routed reader moves right at this builder, skipping the fake.
        mode = chain((0, 0, 1, 0), ('installed', True))
        self.assertIsNone(observe(enc, tree, mode)[0])

    def test_initial_halt_and_feed_variants(self):
        halted = Encoding(Machine(1, 0, lambda q, bit: (0, bit, 0)))
        for d, f, m in product((0, 1), ((), (0,), (0, 1, 0)), ((), (1, 0))):
            start = (0, d, f, m)
            self.assertEqual(run(halted, start, 2, 'lazy'), [(0, start)])


if __name__ == '__main__':
    unittest.main(verbosity=2)
