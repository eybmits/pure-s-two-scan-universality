"""Demand-driven evaluation of exact whole-tree parallel snapshots.

This evaluator sees only S and application. It accepts arbitrary finite S terms.
Its cache is shared between calls, but every requested snapshot starts at the seed.
"""
from functools import lru_cache


class Lookup:
    def __init__(self, f):
        self.f=f
    def __getitem__(self, key):
        return self.f(key)


class Snapshots:
    def __init__(self, terms):
        self.raw=terms
        self.A=terms.A
        self.left=Lookup(lambda t: self.children(t)[0])
        self.right=Lookup(lambda t: self.children(t)[1])
        self.normal=Lookup(lambda t: not isinstance(t,tuple) and terms.normal[t])
        self.arity=Lookup(self.head_arity)

    @lru_cache(maxsize=None)
    def finish(self,t,k):
        """Earliest normal form up to round k, or None if no such round exists."""
        raw=self.raw
        if raw.normal[t]:
            return 0,t
        if k==0:
            return None
        l,r=raw.left[t],raw.right[t]
        a=self.finish(l,k)
        if a is None:
            return None
        b=self.finish(r,k)
        if b is None:
            return None
        time=max(a[0],b[0])
        if raw.arity[a[1]]!=2:
            return time,raw.app(a[1],b[1])
        if time==k:
            return None
        z=self.finish(self.contract(a[1],b[1]),k-time-1)
        return None if z is None else (time+1+z[0],z[1])

    def contract(self,l,r):
        x,y=self.raw.fields(l)
        return self.raw.app(self.raw.app(x,r),self.raw.app(y,r))

    def at(self,t,k):
        v=self.finish(t,k)
        return v[1] if v is not None else ((t,k) if k else t)

    @lru_cache(maxsize=None)
    def children(self,t):
        if not isinstance(t,tuple):
            return self.raw.left[t],self.raw.right[t]
        start,k=t
        l,r=self.raw.left[start],self.raw.right[start]
        a=self.finish(l,k-1)
        b=self.finish(r,k-1) if a is not None else None
        if a is None or b is None:
            return self.at(l,k),self.at(r,k)
        # A suspension is known to be nonnormal; this root must have contracted.
        assert self.raw.arity[a[1]]==2
        rem=k-1-max(a[0],b[0])
        return self.children(self.at(self.contract(a[1],b[1]),rem))

    def head_arity(self,t):
        if not isinstance(t,tuple):
            return self.raw.arity[t]
        n=0
        while n<3 and t!=0:
            n+=1
            t=self.left[t]
        return n

    def fields(self,t):
        return self.right[self.left[t]],self.right[t]

    def uncell(self,t):
        return self.right[self.right[t]]
