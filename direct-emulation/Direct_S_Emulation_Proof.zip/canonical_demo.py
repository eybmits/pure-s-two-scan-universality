"""Replay a deterministic write-and-reverse program on the Lean-exported S seed.

Run python3 canonical_demo.py. To regenerate the raw seed, use the pinned Lean
environment and run lean --run CanonicalDemo.lean canonical_seed.dag.
"""
from dataclasses import dataclass
from itertools import product
from pathlib import Path
import sys

from direct import Trees
from lazy_snapshot import Snapshots


@dataclass(frozen=True)
class Label:
    kind: str
    direction: bool | None  # the only machine state is Unit
    symbol: int | None
    end_after: bool


def label_alphabet():
    first = [
        Label("base", True, 0, False),
        Label("baseEmpty", True, None, True),
        Label("base", True, 1, True),
        Label("straight", True, 1, True),
        Label("turn", False, 1, True),
    ]
    all_labels = (
        Label(*fields) for fields in product(
            ("zero", "baseEmpty", "base", "straight", "turn"),
            (None, False, True), (None, 0, 1), (False, True)
        )
    )
    return first + [k for k in all_labels if k not in first]


def load_seed(path):
    terms = Trees()
    ids = [0]
    with path.open() as source:
        version, root, size = source.readline().split()
        if version != "S-DAG-1":
            raise ValueError("Unrecognized S-DAG header")
        for line in source:
            left, right = map(int, line.split())
            if not (0 <= left < len(ids) and 0 <= right < len(ids)):
                raise ValueError("Invalid application address")
            ids.append(terms.app(ids[left], ids[right]))
    if len(ids) != int(size) + 1 or not (0 <= int(root) < len(ids)):
        raise ValueError("Incomplete seed file")
    return terms, ids[int(root)]


class Reader:
    """Literal control of DirectControl.control and structural DirectDecode.read."""
    def __init__(self, terms, raw):
        self.raw = raw
        self.armed_marker = terms.A
        labels = label_alphabet()
        self.directory_index = {key: i for i, key in enumerate(product(labels, repeat=2))}
        self.by_marker = {}
        marker = 0
        for k in labels:
            self.by_marker[marker] = k
            marker = terms.app(0, marker)

    def at(self, t, path):
        for side in path:
            if t is None or t == 0:
                return None
            t = self.raw.right[t] if side else self.raw.left[t]
        return t

    def label(self, t):
        # Decode.inspect matches S (S k) payload before looking up k.
        if self.at(t, (0, 0)) != 0 or self.at(t, (0, 1, 0)) != 0:
            return None
        return self.by_marker.get(self.at(t, (0, 1, 1)))

    def stack(self, t):
        heads = []
        while True:
            lab = self.label(t)
            if lab is None:
                return None
            if lab.kind in ("zero", "baseEmpty"):
                break
            if lab.symbol is None:
                return None
            route = {"base": (1, 1, 1, 1), "straight": (1, 0, 1),
                     "turn": (1, 1, 1, 0, 1)}[lab.kind]
            heads.append((lab.symbol, lab.kind == "turn"))
            t = self.at(t, route)
        result = ()
        for symbol, turned in reversed(heads):
            result = (symbol,) + (result[1:] if turned else result)
        return result

    def decode(self, t):
        u = self.at(t, (0, 1, 1))
        v = self.at(t, (1, 1, 1))
        lab = self.label(v)
        if lab is None or lab.direction is None:
            return None
        focus, opposite = self.stack(u), self.stack(v)
        if focus is None or opposite is None:
            return None
        return lab.direction, focus, opposite

    def after(self, phase, parameter, k):
        if phase == "library":
            if k.kind not in ("base", "baseEmpty"):
                return (0,), phase, parameter
            if parameter is None:
                return (0, 1), "check", None
            address = (1,) * self.directory_index[parameter] + (0,)
            return (0, 0) + address + (0, 0, 1, 0), "installed", parameter[0].end_after
        if phase == "pop":
            if k.kind == "base":
                return (1,), "check", None
            if k.kind == "straight":
                return (1, 1, 1), "check", None
            return (1, 1, 0), "pop", None
        if phase == "installed":
            if k.kind == "turn":
                return (1, 1, 1), "check", None
            if parameter:
                return (0,), "library", None
            return (1, 1, 0), "pop", None
        raise ValueError("Unknown reader state")

    def select(self, t):
        pending, phase, parameter = (), "check", None
        path = []
        while t != 0:
            left, right = self.raw.children(t)
            if pending:
                side, pending = pending[0], pending[1:]
                child = right if side else left
                if self.raw.normal[child]:
                    return None
            elif phase == "check":
                if self.raw.normal[right]:
                    if self.at(left, (0, 1)) == self.armed_marker:
                        return tuple(path), t
                    return None
                # These are the same finite lookaheads as DirectControl.summary.
                focus = self.by_marker.get(self.at(left, (1, 0, 1, 0, 1, 1)))
                opposite = self.by_marker.get(self.at(left, (1, 1, 1, 1, 0, 1, 1)))
                if focus is None or opposite is None:
                    return None
                pending, phase, parameter = (1, 1, 1, 0), "library", (focus, opposite)
                side, child = 1, right
            else:
                if self.raw.normal[right]:
                    return None
                lab = self.by_marker.get(self.at(left, (0, 1)))
                if lab is None:
                    return None
                pending, phase, parameter = self.after(phase, parameter, lab)
                side, child = 1, right
            path.append(side)
            t = child
        return None


def check_eager_prefix(terms, snapshots, seed, depth):
    """Compare all raw nodes of early lazy snapshots with the eager parallel rule."""
    tree = seed
    for n in range(depth + 1):
        compare = [(snapshots.at(seed, n), tree)]
        seen = set()
        while compare:
            delayed, eager = compare.pop()
            if (delayed, eager) in seen:
                continue
            seen.add((delayed, eager))
            if isinstance(delayed, int):
                # Hash-consed node ID equality is exact structural equality.
                assert delayed == eager, (n, delayed, eager)
            else:
                assert eager != 0
                left, right = snapshots.children(delayed)
                compare.extend(((left, terms.left[eager]), (right, terms.right[eager])))
        if n != depth:
            tree = terms.pi(tree)


def main():
    sys.setrecursionlimit(max(5000, sys.getrecursionlimit()))
    seed_file = Path(__file__).with_name("canonical_seed.dag")
    terms, seed = load_seed(seed_file)
    snapshots = Snapshots(terms)
    check_eager_prefix(terms, snapshots, seed, 8)
    print("Eager and lazy complete S trees agree through round 8.")
    reader = Reader(terms, snapshots)
    expected = [
        (0,   (True,  (0, 1), ())),
        (28,  (True,  (1,),   (1,))),
        (238, (False, (1,),   (1,))),
        (546, (False, (),     (1, 1))),
    ]
    def word(xs):
        return "".join(map(str, xs)) or "empty"

    observed, last_path = [], None
    print(f"Lean seed: {len(reader.by_marker)} labels, {len(reader.directory_index)} unary directory entries")
    for n in range(expected[-1][0] + 1):
        selected = reader.select(snapshots.at(seed, n))
        if selected is None:
            continue
        path, checkpoint = selected
        observed.append((n, reader.decode(checkpoint)))
        if last_path is not None:
            assert len(path) > len(last_path) and path[:len(last_path)] == last_path
        last_path = path
        direction, focus, opposite = observed[-1][1]
        print(f"round {n:3}: depth {len(path):3}, {'right' if direction else 'left'}, "
              f"focus {word(focus)}, opposite {word(opposite)}")
    assert observed == expected, observed
    print("Checked all 547 round snapshots. Exactly four checkpoints, each below its predecessor.")


if __name__ == "__main__":
    main()
