"""Reproduce Section 6's expanded S-leaf counts from the Lean-exported seed."""

import sys
from pathlib import Path

from canonical_demo import Reader, load_seed
from lazy_snapshot import Snapshots


def main():
    sys.setrecursionlimit(max(5000, sys.getrecursionlimit()))
    terms, seed = load_seed(Path(__file__).with_name("canonical_seed.dag"))
    snapshots = Snapshots(terms)
    reader = Reader(terms, snapshots)

    # Each stored application refers to two earlier nodes. Add their counts
    # even when the children are identical: the expanded tree has both copies.
    sizes = [1]

    def leaves(node):
        while len(sizes) <= node:
            i = len(sizes)
            sizes.append(sizes[terms.left[i]] + sizes[terms.right[i]])
        return sizes[node]

    print("Round | address depth | checkpoint leaves")
    for n in (0, 28, 238, 546):
        selected = reader.select(snapshots.at(seed, n))
        if selected is None:
            raise ValueError(f"Expected a checkpoint at round {n}")
        address, node = selected
        left, right = snapshots.children(node)
        # At a genuine checkpoint both children are normal raw terms.
        assert isinstance(left, int) and terms.normal[left]
        assert isinstance(right, int) and terms.normal[right]
        print(f"{n:5} | {len(address):13} | {leaves(left) + leaves(right):17,}")

    tree = seed
    for _ in range(8):
        tree = terms.pi(tree)
    print(f"Whole tree at round 8: {leaves(tree):,} S-leaves")


if __name__ == "__main__":
    main()
