import DirectNesting

#check DirectNesting.strict_ancestry
#check DirectSerial.first_output
#check DirectCertified.universality
#check DirectTrajectory.all_snapshots
#check DirectTrajectory.selection_regular
#check DirectTrajectory.hit_iff
#check DirectQueries.hit_regular
#check DirectControlled.span_step
#check DirectCost.pair_budget
#check DirectOutput.source_signal

#print axioms DirectNesting.strict_ancestry
#print axioms DirectSerial.first_output
#print axioms DirectCertified.universality
#print axioms DirectTrajectory.all_snapshots
#print axioms DirectTrajectory.selection_regular
#print axioms DirectTrajectory.hit_iff
#print axioms DirectQueries.hit_regular
#print axioms DirectControlled.span_step
#print axioms DirectCost.pair_budget
#print axioms DirectOutput.source_signal
