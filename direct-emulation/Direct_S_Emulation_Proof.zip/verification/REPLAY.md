# Replaying the direct S proof

Run the following command from the extracted proof directory. The project pins Lean 4.35.0 and the exact Mathlib and secondary dependency revisions in `lake-manifest.json`. Place the corresponding Lean tools, `leanexport` and Nanoda 0.4.19 (`nanoda_bin`) on PATH. Python 3.10 or later runs the audit and examples.

```sh
python3 verify.py
```

The script creates an empty temporary project, copies the shipped Lean sources into it, builds them, and writes its results to `replay-checks/` in the extracted directory. To work offline, use an existing Lake `.lake/packages` directory containing the pinned dependencies and their builds. It may be shared with other local projects. For example,

```sh
python3 verify.py --packages /path/to/.lake/packages --lean-bin /path/to/lean/bin
```

The audit records the type and `#print axioms` result of every endpoint listed in `verification/Endpoints.lean`. It replays their common root using `leanchecker --fresh`, which rebuilds the transitive kernel environment from imported declarations. Separately, `leanexport` writes the dependencies of exactly the listed declarations. Nanoda type-checks that export with `propext`, `Classical.choice` and `Quot.sound` as the allowed axioms and prints each checked theorem. The transcript records the export size and SHA-256. The type, axiom allow-list and successful check are the semantic tests. An export digest also depends on the exporter and ordering.

The last two tests compare independent Python reduction routines and regenerate the executable example seed directly from Lean. The audit checks the regenerated seed byte-for-byte, then runs the example against the raw snapshots. These tests illustrate the semantics. The general statements are proved by the theorems replayed above.

The script records source digests in `source-sha256.txt`, package revisions in `dependencies.txt`, the full endpoint types in `endpoint-types.log` and the external checker's theorem printouts in `nanoda-endpoints.log`. The top-level result is `audit.log`. The pinned dependency checkouts can reuse existing dependency build artifacts. All local project modules are rebuilt from their `.lean` sources.

## Reading the checked statements

| Declaration | What to inspect |
| --- | --- |
| `DirectCertified.universality` | A single finite interpreter, encoder and readout precede the quantifier over partial computable binary-string functions. Detection has a regular domain and the seed has linear size. |
| `DirectNesting.strict_ancestry` | One positive interval per machine instruction, strictly increasing address depths, and the exact reader result for every intermediate round. The next address extends the preceding one by the branch named in the theorem. |
| `DirectTrajectory.all_snapshots` | The selected subtree and the decoded source tape on every checkpoint and intervening round. |
| `DirectControlled.span_step` | The physical evolution and reader control for one encoded instruction, including reversals. |
| `DirectTrajectory.selection_regular` | A finite tree automaton recognizes the domain of the selector and another recognizes a correctly marked selection. |
| `DirectTrajectory.hit_iff`, `DirectQueries.hit_regular` | Agreement between a state test on the decoded tape and a regular test on a raw S snapshot. |
| `DirectOutput.source_signal` | The fixed universal interpreter signals exactly the intended evaluation result. |
| `DirectSerial.first_output` | Two copies give the correct first output on the fixed sweep of individual contractions. |
| `DirectCost.pair_budget` | The sum of the two descriptor traversal budgets is bounded by the leaf count of the input checkpoint. |
