import DirectTrajectory

/-! An executable instance of the same unary-directory compiler used in the proof.
Run this file with Lean's --run option and a destination filename. The output
encodes the actual ground S seed as a DAG of raw applications, in postorder. -/
namespace CanonicalDemo
open DirectMemory DirectTrajectory TwoScans

abbrev Tag := Desc.Tag Unit Bool
def rightward : Mark Unit := ⟨(),true⟩
def leftward : Mark Unit := ⟨(),false⟩

-- This permutation reduces the cost of accessing relevant leaves in a unary
-- directory. All 90 tags and all 8,100 entries are retained.
def firstLabels : List Tag :=
  [⟨.base,rightward,false,false⟩, ⟨.baseEmpty,rightward,none,true⟩,
   ⟨.base,rightward,true,true⟩, ⟨.straight,rightward,true,true⟩,
   ⟨.turn,leftward,true,true⟩]
def allLabels := Alphabet.tags (⟨[()],by intro x; cases x; simp⟩ : Alphabet Unit) Alphabet.bools
def tags : Alphabet Tag :=
  ⟨firstLabels ++ allLabels.items.filter (fun t => !firstLabels.contains t), by
    intro t
    by_cases h : t ∈ firstLabels <;> simp [h,allLabels.cover]⟩

def machine : Machine Unit Bool := fun _ bit => ⟨(),true,!bit⟩
def initial : Tape Unit Bool := ⟨rightward,[false,true],[]⟩

example : DirectTerminal.clock (next machine false) 3 initial = ⟨leftward,[],[true,true]⟩ := rfl

structure Graph where
  children : Array (Nat × Nat) := #[]
  index : Std.HashMap (Nat × Nat) Nat := {}

/-- Node zero is S. Every other node is a pair of earlier nodes. -/
def share : Term → StateM Graph Nat
  | .s => pure 0
  | .app left right => do
    let key := (← share left, ← share right)
    let graph ← get
    if let some n := graph.index[key]? then return n
    let n := graph.children.size + 1
    set (Graph.mk (graph.children.push key) (graph.index.insert key n))
    return n

def exportSeed (path : System.FilePath) : IO Unit := do
  let (root, graph) := (share (seed tags machine false initial)).run {}
  let handle ← IO.FS.Handle.mk path .write
  handle.putStrLn s!"S-DAG-1 {root} {graph.children.size}"
  for (left,right) in graph.children do
    handle.putStrLn s!"{left} {right}"
  IO.println s!"Exported the CanonicalDemo seed ({tags.items.length} labels, {graph.children.size} applications)."

end CanonicalDemo

def main (args : List String) : IO UInt32 := do
  match args with
  | [path] => CanonicalDemo.exportSeed path; return 0
  | _ => IO.eprintln "Usage: lean --run CanonicalDemo.lean DESTINATION"; return 1
