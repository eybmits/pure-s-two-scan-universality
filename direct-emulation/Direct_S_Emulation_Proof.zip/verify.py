"""Replay the complete local source proof, its fresh Lean kernel check, and its Nanoda export."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}
MODULE = "DirectNesting"


def digest(path):
    state = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            state.update(block)
    return state.hexdigest()


def run(command, root, env, stdout=None):
    options = {"stdout": stdout if stdout is not None else subprocess.PIPE,
               "stderr": None if stdout is not None else subprocess.STDOUT}
    process = subprocess.run(command, cwd=root, env=env, **options)
    data = process.stdout.decode(errors="replace") if process.stdout else ""
    if process.returncode:
        raise RuntimeError(f"Command failed ({process.returncode}): {command}\n{data[-8000:]}")
    return data


def axioms(names, report):
    actual = {}
    for name, used in re.findall(r"^'([^']+)' depends on axioms: \[([^\]]*)\]", report, re.M):
        actual[name] = set(s.strip() for s in used.split(",") if s.strip())
    for name in re.findall(r"^'([^']+)' does not depend on any axioms", report, re.M):
        actual[name] = set()
    if set(names) != set(actual) or any(a - ALLOWED for a in actual.values()):
        raise RuntimeError(f"Unexpected endpoint axiom report: {actual}")
    return actual


def verify(root, packages, lean_bin, exporter, nanoda, checks):
    env = os.environ.copy()
    if lean_bin:
        env["PATH"] = str(lean_bin.resolve()) + os.pathsep + env["PATH"]
    env.pop("LEAN_PATH", None)
    checks.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((root / "lake-manifest.json").read_text())
    pin = (root / "lean-toolchain").read_text().strip().split(":v")[-1]
    version = run(["lean", "--version"], root, env).strip()
    if not re.search(r"\bversion " + re.escape(pin) + r"\b", version):
        raise RuntimeError(f"Expected Lean {pin}, found {version}")
    nd = run([nanoda, "--help"], root, env).splitlines()[0]
    if nd != "nanoda_bin 0.4.19":
        raise RuntimeError(f"Expected Nanoda 0.4.19, found {nd}")
    endpoints_file = root / "verification/Endpoints.lean"
    listing = endpoints_file.read_text()
    names = re.findall(r"^#check ([\w.]+)$", listing, re.M)
    prints = re.findall(r"^#print axioms ([\w.]+)$", listing, re.M)
    if not names or len(set(names)) != len(names) or prints != names:
        raise RuntimeError("Every endpoint must have exactly one #check and one #print axioms.")
    src = sorted((root / "formal").glob("*.lean"))
    if not any(p.stem == MODULE for p in src):
        raise RuntimeError("The formal source directory is missing the final theorem.")
    for path in src:
        if re.search(r"\b(sorry|admit|native_decide)\b|^\s*(?:private\s+)?axiom\s", path.read_text(), re.M):
            raise RuntimeError(f"Unexpected unchecked construct in {path.name}")
    inputs = src + [root / name for name in ["lake-manifest.json", "lakefile.lean", "lean-toolchain",
              "verify.py", "direct.py", "lazy_snapshot.py", "test_direct.py",
              "canonical_demo.py", "canonical_seed.dag", "CanonicalDemo.lean"]] + [endpoints_file]
    inputs = sorted(inputs, key=lambda p: str(p.relative_to(root)))
    source_hashes = "".join(f"{digest(p)}  {p.relative_to(root)}\n" for p in inputs)
    (checks / "source-sha256.txt").write_text(source_hashes)
    status = [version, nd, f"{len(src)} local Lean sources"]
    print("\n".join(status), flush=True)
    with tempfile.TemporaryDirectory(prefix="direct-s-proof-") as scratch:
        fresh = Path(scratch)
        for path in inputs:
            copy = fresh / path.relative_to(root)
            copy.parent.mkdir(exist_ok=True, parents=True)
            shutil.copy2(path, copy)
        if packages:
            target = fresh / ".lake/packages"
            target.parent.mkdir()
            target.symlink_to(packages.resolve(), target_is_directory=True)
        print("Building every local Lean module in a fresh Lake project ...", flush=True)
        build = run(["lake", "--reconfigure", "build"], fresh, env)
        (checks / "source-build.log").write_text(build)
        dep_lines = []
        for entry in manifest["packages"]:
            where = fresh / ".lake/packages" / entry["name"]
            rev = run(["git", "-C", str(where), "rev-parse", "HEAD"], fresh, env).strip()
            if rev != entry["rev"]:
                raise RuntimeError(f"Unexpected revision for {entry['name']}: {rev}")
            changes = run(["git", "-C", str(where), "diff", "--name-only", "HEAD", "--", "*.lean", "lakefile.*"], fresh, env).strip()
            if changes:
                raise RuntimeError(f"Modified tracked package proof/config files in {entry['name']}: {changes}")
            dep_lines.append(f"{entry['name']} {rev}")
        (checks / "dependencies.txt").write_text("\n".join(dep_lines) + "\n")
        status.append("Source build passed. All dependency revisions matched the manifest.")
        print("Checking endpoint types and axiom sets ...", flush=True)
        types = run(["lake", "env", "lean", "verification/Endpoints.lean"], fresh, env)
        if "error:" in types or "sorryAx" in types:
            raise RuntimeError("The endpoint report contains an error or sorryAx.")
        usage = axioms(names, types)
        (checks / "endpoint-types.log").write_text(types)
        print("Replaying the full import closure in an empty Lean kernel environment ...", flush=True)
        kernel = run(["lake", "env", "leanchecker", "--fresh", "--verbose", MODULE], fresh, env)
        (checks / "leanchecker.log").write_text(kernel)
        if MODULE not in kernel:
            raise RuntimeError("The verbose leanchecker report does not identify the requested module.")
        status.append(f"leanchecker --fresh --verbose {MODULE} passed.")
        export = fresh / "export.ndjson"
        with export.open("wb") as handle:
            run(["lake", "env", exporter, MODULE, "--", *names], fresh, env, stdout=handle)
        sha = digest(export)
        status.append(f"SHA-256 {sha}  export.ndjson ({export.stat().st_size} bytes)")
        pretty = fresh / "nanoda-statements.txt"
        pretty.touch()
        config = {"export_file_path": str(export), "permitted_axioms": sorted(ALLOWED),
                  "unpermitted_axiom_hard_error": True, "nat_extension": True,
                  "string_extension": True, "pp_declars": names, "pp_output_path": str(pretty),
                  "pp_options": {"proofs": False, "width": 100}, "print_success_message": True}
        (fresh / "nanoda.json").write_text(json.dumps(config))
        print("Rechecking exported declarations with Nanoda ...", flush=True)
        response = run(["lake", "env", nanoda, "nanoda.json"], fresh, env)
        if not re.search(r"Checked [\d,]+ declarations with no errors", response):
            raise RuntimeError(f"Missing Nanoda success report: {response}")
        response = response.strip()
        statements = pretty.read_text()
        if set(re.findall(r"^theorem\s+(\S+)\s*:", statements, re.M)) != set(names):
            raise RuntimeError("Nanoda did not print precisely the requested theorem names.")
        (checks / "nanoda-endpoints.log").write_text(statements)
        (checks / "nanoda.log").write_text(response + "\n")
        status.append(response)
        status.extend(f"{name}: {', '.join(sorted(usage[name]))}" for name in names)
        tests = run([sys.executable, "-B", "test_direct.py"], fresh, env)
        (checks / "python-regression.log").write_text(tests)
        status.append("All Python regression tests passed.")
        generated = fresh / "regenerated.dag"
        demo = run(["lake", "env", "lean", "--run", "CanonicalDemo.lean", str(generated)], fresh, env)
        if digest(generated) != digest(fresh / "canonical_seed.dag"):
            raise RuntimeError("The canonical demo seed did not regenerate byte-for-byte.")
        demo += run([sys.executable, "-B", "canonical_demo.py"], fresh, env)
        (checks / "canonical-demo.log").write_text(demo)
        status.append("Canonical Lean demo seed reproduced byte-for-byte; Python whole-tree demo passed.")
        (checks / "audit.log").write_text("\n".join(status) + "\n")
        print("\n".join(status))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project", type=Path, default=ROOT, help="source project containing formal/")
    p.add_argument("--packages", type=Path, help="previously installed pinned Lake packages, enabling offline replay")
    p.add_argument("--lean-bin", type=Path, help="directory containing the pinned Lean and Lake executables")
    p.add_argument("--exporter", default="leanexport")
    p.add_argument("--nanoda", default="nanoda_bin")
    p.add_argument("--checks", type=Path, help="write replay results to this directory (default replay-checks/)")
    args = p.parse_args()
    project = args.project.resolve()
    verify(project, args.packages, args.lean_bin, args.exporter, args.nanoda,
           args.checks.resolve() if args.checks else project / "replay-checks")
