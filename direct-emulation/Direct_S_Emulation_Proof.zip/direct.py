"""A raw parallel-innermost S reducer, a finite-control snapshot reader and a tape demo.

Use python3 direct.py. Normal subtrees are shared. The optional projected replay
uses the context lemma to discard siblings only after verifying each physical descent.
"""
from dataclasses import dataclass
from lazy_snapshot import Snapshots
import argparse


class Trees:
    """0 is S. All other node ids denote the application of two earlier nodes."""
    def __init__(self):
        self.left, self.right = [-1], [-1]
        self.arity, self.normal = [0], [True]
        self.nodes, self.rounds = {}, {}
        self.A = self.app(0, 0)
        self.B = self.app(0, self.A)

    def app(self, a, b):
        key = (a, b)
        if key not in self.nodes:
            self.nodes[key] = len(self.left)
            self.left.append(a)
            self.right.append(b)
            self.arity.append(min(3, self.arity[a]+1))
            self.normal.append(self.normal[a] and self.normal[b] and self.arity[a] < 2)
        return self.nodes[key]

    def pair(self, a, b):
        return self.app(self.app(0, a), b)

    def fields(self, t):
        return self.right[self.left[t]], self.right[t]

    def cell(self, u):
        return self.app(self.B, self.app(0,u))

    def uncell(self, t):
        return self.right[self.right[t]]

    def pi(self, t):
        if self.normal[t]:
            return t
        if t not in self.rounds:
            a, b = self.left[t], self.right[t]
            if self.normal[a] and self.normal[b]:
                x, y = self.fields(a)
                v = self.app(self.app(x,b), self.app(y,b))
            else:
                v = self.app(self.pi(a), self.pi(b))
            self.rounds[t] = v
        return self.rounds[t]

    def installer(self, tag):
        a, p = self.app, self.pair
        k = a(0, tag)
        w = p(p(self.A, self.B), self.B)
        def assemble(g, h):
            return p(a(0,h), g)
        return assemble(a(0,k), assemble(0,w))


@dataclass(frozen=True)
class Label:
    kind: str
    state: int
    direction: int
    symbol: int
    tail_empty: bool


class Machine:
    """Binary tape alphabet with blank 0. State halt is silently totalized."""
    def __init__(self, states, halt, delta):
        self.states, self.halt, self.delta = states, halt, delta


class Encoding:
    def __init__(self, machine):
        self.machine, self.t = machine, Trees()
        self.tags, self.labels = {}, {}
        self.bits = (machine.states-1).bit_length()
        self.empty_label = Label('zero',0,1,0,True)
        self.empty = self.t.cell(self.descriptor(self.empty_label,0))
        def subtree(depth, bits):
            if depth:
                return self.t.pair(subtree(depth-1,bits*2),subtree(depth-1,bits*2+1))
            state, direction, symbol, opp_empty, tail_empty = self.split_bits(bits)
            state %= machine.states
            nxt, written, move = machine.delta(state,symbol)
            kind = 'straight' if direction==move else 'turn'
            lab = Label(kind,nxt,move,written, bool(opp_empty if kind=='straight' else tail_empty))
            return self.t.installer(self.tag(lab))
        self.table = subtree(self.bits+4,0)
        self.library = self.t.pair(self.table,self.empty)

    def tag(self, lab):
        if lab not in self.tags:
            # Normal, uniquely decodable chains for the finitely many labels.
            term = self.t.app(0, max(self.labels) if self.labels else 0)
            self.tags[lab], self.labels[term] = term,lab
        return self.tags[lab]

    def split_bits(self, bits):
        return bits>>4, (bits>>3)&1, (bits>>2)&1,(bits>>1)&1,bits&1

    def descriptor(self, lab, payload):
        return self.t.pair(self.t.app(0,self.tag(lab)),payload)

    def label(self,u):
        k,_=self.t.fields(u)
        return self.labels[self.t.right[k]]

    def label_after(self,t):
        # Left child is (S tag) x and remains normal throughout its lifetime.
        return self.labels[self.t.right[self.t.left[self.t.left[t]]]]

    def base(self, word,state,direction):
        t=self.t
        u=self.descriptor(Label('baseEmpty',state,direction,0,True),t.pair(self.library,self.empty))
        for i,symbol in enumerate(reversed(word)):
            u=self.descriptor(Label('base',state,direction,symbol,i==0),t.pair(self.library,t.cell(u)))
        return u

    def seed(self, word, opposite=(),state=0,direction=1):
        t=self.t
        return t.app(t.cell(self.base(word,state,direction)),t.cell(self.base(opposite,state,direction)))

    def address(self,u,v):
        x,y=self.label(u),self.label(v)
        key=(((y.state*2+y.direction)*2+x.symbol)*2+(y.kind in ('zero','baseEmpty')))*2+x.tail_empty
        return key,x.tail_empty

    def tape(self,u):
        t=self.t
        out=[]
        while True:
            lab=self.label(u)
            if lab.kind in ('zero','baseEmpty'):
                return tuple(out)
            out.append(lab.symbol)
            if lab.tail_empty:
                return tuple(out)
            while True:
                lab=self.label(u)
                _,payload=t.fields(u)
                if lab.kind=='base':
                    _,old=t.fields(payload)
                    u=t.uncell(old)
                    break
                _,j=t.fields(payload)
                _,e=t.fields(j)
                old_focus,old_opp=t.fields(e)
                if lab.kind=='straight':
                    u=t.uncell(old_opp)
                    break
                assert lab.kind=='turn'
                u=old_focus


CHECK=('check',)
STOP=('stop',)

def go(side,mode):
    return ('go',side,mode)

def chain(route,mode):
    for side in reversed(route):
        mode=go(side,mode)
    return mode


def inspect(enc,t,mode):
    """Return wait, report, stop, or a physical child and its next finite mode."""
    g=enc.t
    l,r=g.left[t],g.right[t]
    def down(side,following):
        child=r if side else l
        return ('down',side,following) if child!=-1 and not g.normal[child] else ('wait',)
    if mode==STOP:
        return ('stop',)
    if mode==CHECK:
        if r!=-1 and not g.normal[r]:
            e=g.right[l]
            u,m=g.fields(e)
            v=g.uncell(m)
            if enc.label(v).state==enc.machine.halt:
                return ('stop',)
            key,empty=enc.address(u,v)
            return down(1,chain((1,1,1,0),('lib','table',key,empty)))
        if l!=-1 and g.normal[l] and g.arity[l]==2 and g.fields(l)[0]==g.A:
            u,v=g.uncell(l),g.uncell(r)
            lab=enc.label(v)
            return ('report',lab.state,lab.direction,u,v)
        return ('wait',)
    if mode[0]=='go':
        return down(mode[1],mode[2])
    if mode[0] in ('lib','pop','installed'):
        if r==-1 or g.normal[r]:
            return ('wait',)
        lab=enc.label_after(t)
        if mode[0]=='lib':
            _,target,key,empty=mode
            if lab.kind in ('base','baseEmpty'):
                if target=='zero':
                    next_mode=chain((0,1),CHECK)
                else:
                    bits=tuple((key>>j)&1 for j in reversed(range(enc.bits+4)))
                    next_mode=chain((0,0)+bits+(0,0,1,0),('installed',empty))
            else:
                assert lab.kind in ('straight','turn')
                next_mode=go(0,mode)
        elif mode[0]=='pop':
            if lab.kind=='base':
                next_mode=go(1,CHECK)
            elif lab.kind=='straight':
                next_mode=chain((1,1,1),CHECK)
            else:
                assert lab.kind=='turn'
                next_mode=chain((1,1,0),mode)
        elif lab.kind=='turn':
            next_mode=chain((1,1,1),CHECK)
        elif mode[1]:
            next_mode=go(0,('lib','zero',0,False))
        else:
            next_mode=chain((1,1,0),('pop',))
        return down(1,next_mode)
    raise ValueError(mode)


def decode(enc, report):
    _,q,d,u,v=report
    return q,d,enc.tape(u),enc.tape(v)


def snapshot(enc,t):
    mode=CHECK
    while True:
        obs=inspect(enc,t,mode)
        if obs[0]!='down':
            return (decode(enc,obs) if obs[0]=='report' else None)
        _,side,mode=obs
        t=(enc.t.right if side else enc.t.left)[t]


def reference(machine,start,steps):
    q,d,f,m=start
    yield start
    for _ in range(steps):
        if q==machine.halt:
            return
        q,c,move=machine.delta(q,f[0] if f else 0)
        rest=f[1:]
        f,m=(rest,(c,)+m) if move==d else (m,(c,)+rest)
        d=move
        yield q,d,f,m


def run(enc,start,steps,method="lazy"):
    q,d,f,m=start
    seed=enc.seed(f,m,q,d)
    tree=seed
    mode=CHECK
    round_no=0
    raw=enc.t
    if method=="lazy":
        enc.t=Snapshots(raw)
    wanted=iter(reference(enc.machine,start,steps))
    observed=[]
    while len(observed)<=steps:
        if method=="lazy":
            config=snapshot(enc,enc.t.at(seed,round_no))
        elif method=="whole":
            config=snapshot(enc,tree)
        else:
            while True:
                obs=inspect(enc,tree,mode)
                if obs[0]!='down':
                    break
                _,side,mode=obs
                tree=(enc.t.right if side else enc.t.left)[tree]
            config=decode(enc,obs) if obs[0]=='report' else None
        if config is not None:
            assert config==next(wanted), (round_no,config)
            observed.append((round_no,config))
            if config[0]==enc.machine.halt or len(observed)>steps:
                break
        if method!="lazy":
            tree=enc.t.pi(tree)
        round_no+=1
    enc.t=raw
    return observed


def demo(method="lazy"):
    # Write 1 on blank, go right, turn left, branch on the returned symbol.
    def delta(q,a):
        if q==0: return 1,1,1
        if q==1: return 2,0,0
        if q==2: return (3 if a==1 else 2),a,1
        return 3,a,1
    enc=Encoding(Machine(4,3,delta))
    start=(0,1,(),())
    for r,c in run(enc,start,3,method):
        print(f'round {r:3}   state {c[0]}   direction {c[1]}   focus {c[2]}   opposite {c[3]}')
    return enc

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--method',choices=('lazy','whole','projected'),default='lazy',help='exact demand-driven snapshot, eager full DAG, or contextual path replay')
    demo(parser.parse_args().method)
