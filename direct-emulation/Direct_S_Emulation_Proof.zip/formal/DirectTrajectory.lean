import DirectControlledStep
import DirectDecode
import DirectTerminal

/-! Uniform direct simulation on the ground-S orbit. The checkpoint reader
is a function only of the finite alphabet; both the transition table and the
initialized tape live in the S seed. -/
namespace DirectTrajectory
open TwoScans TwoScans.Term TwoScans.Frames TwoScans.Automata
open DirectMemory DirectMemory.Encoding DirectMemory.Compiled
open DirectS DirectReader DirectControl DirectControlled DirectTerminal
variable {Q Γ : Type} [DecidableEq Q] [DecidableEq Γ]

abbrev Machine (Q Γ : Type) := Q → Γ → Instruction Q Γ

def optional (M : Machine Q Γ) (q : Q) (a : Γ) := some (M q a)

def next (M : Machine Q Γ) (blank : Γ) (c : DirectMemory.Tape Q Γ) :=
  Heap.tapeAdvance c (M c.control.state (c.focus.head?.getD blank))

def hnext (M : Machine Q Γ) (blank : Γ) (h : Heap Q Γ) : Heap Q Γ :=
  match h.opposite.mark with
  | none => h
  | some state =>
    let i := M state.state (h.focus.top.getD blank)
    Heap.advance h (i.moveRight != state.rightward) ⟨i.nextState,i.moveRight⟩ i.write

omit [DecidableEq Q] [DecidableEq Γ] in
theorem hnext_spec (M : Machine Q Γ) (blank : Γ) (t : DirectMemory.Tape Q Γ)
    {h : Heap Q Γ} (rep : h.Represents t) :
    (hnext M blank h).Represents (next M blank t) ∧
      Heap.machineStep (optional M) blank h = some (hnext M blank h) := by
  have head : h.focus.top = t.focus.head? := by rw [← rep.2.2.1, Desc.top_contents]
  constructor
  · simpa [hnext,next,rep.1,head] using
      Heap.represents_advance h t (M t.control.state (t.focus.head?.getD blank)) rep
  · simp [Heap.machineStep,hnext,optional,rep.1]

def history (M : Machine Q Γ) (blank : Γ) (c : DirectMemory.Tape Q Γ) (i) :=
  clock (hnext M blank) i (Heap.initial c)

omit [DecidableEq Q] [DecidableEq Γ] in
theorem history_correct (M : Machine Q Γ) (blank : Γ) (c : DirectMemory.Tape Q Γ) (i) :
    (history M blank c i).Represents (clock (next M blank) i c) := by
  induction i with
  | zero => exact Heap.represents_initial c
  | succ i ih =>
    unfold history
    rw [clock_succ, clock_succ (next M blank)]
    exact (hnext_spec M blank _ ih).1

def seed (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ) (c : DirectMemory.Tape Q Γ) :=
  (encoding tags (optional M) blank).checkpoint (Heap.initial c)

def point (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ) (c : DirectMemory.Tape Q Γ) (i) :=
  (encoding tags (optional M) blank).checkpoint (history M blank c i)

def select (tags : Tags Q Γ) (t : Term) : Option (List Bool) := (reader tags).select t CP

def readSnapshot (tags : Tags Q Γ) (t : Term) : Option (DirectMemory.Tape Q Γ) := do
  let p ← select tags t
  let focus ← atPath t p
  DirectMemory.Decode.read tags focus

theorem point_span (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ) (c : DirectMemory.Tape Q Γ) (i : Nat) :
    ∃ n p, Span (reader tags) true n p (point tags M blank c i) CP (point tags M blank c (i+1)) CP := by
  have rep := history_correct M blank c i
  have move := (hnext_spec M blank _ rep).2
  have path := span_step tags (optional M) blank _ _ rep.2.1 move
  simpa only [Journey, point,history,clock_succ (hnext M blank) i] using path

theorem read_point (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ) (c : DirectMemory.Tape Q Γ) (i) :
    DirectMemory.Decode.read tags (point tags M blank c i) = some (clock (next M blank) i c) :=
  DirectMemory.Decode.read_correct tags (optional M) blank _ _ (history_correct M blank c i)

/-- At every round tᵢ+k before the next checkpoint the reader is completely
determined. Every successful output is a physical state on one nested trace. -/
theorem all_snapshots (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ) (c : DirectMemory.Tape Q Γ) :
    ∃ (duration : Nat → Nat) (branch : Nat → List Bool),
      (∀ i, 0 < duration i) ∧
      (∀ i, time duration i < time duration (i+1)) ∧
      (∀ i, Track (duration i) (branch i) (point tags M blank c i) (point tags M blank c (i+1))) ∧
      (∀ i, atPath (rounds (time duration i) (seed tags M blank c)) (location branch i) =
        some (point tags M blank c i)) ∧
      (∀ i k, k < duration i →
        select tags (rounds (time duration i+k) (seed tags M blank c)) =
          (if k=0 then some (location branch i) else none)) ∧
      ∀ i k, k < duration i →
        readSnapshot tags (rounds (time duration i+k) (seed tags M blank c)) =
          (if k=0 then some (clock (next M blank) i c) else none) := by
  classical
  let a := point tags M blank c
  let d (i) := Classical.choose (point_span tags M blank c i)
  let p (i) := Classical.choose (Classical.choose_spec (point_span tags M blank c i))
  have h (i) : Span (reader tags) true (d i) (p i) (a i) CP (a (i+1)) CP :=
    Classical.choose_spec (Classical.choose_spec (point_span tags M blank c i))
  have at₀ (i) : atPath (rounds (time d i) (seed tags M blank c)) (location p i) = some (a i) := by
    change atPath (rounds (time d i) (a 0)) (location p i) = some (a i)
    simpa only [Nat.add_zero,rounds] using (orbit_physical h i 0)
  have sel (i k) (hk : k < d i) : select tags (rounds (time d i+k) (seed tags M blank c)) =
      if k=0 then some (location p i) else none := orbit_checkpoint h i k hk
  refine ⟨d,p,fun i => (h i).positive,time_strict h,fun i => (h i).track,at₀,sel,?_⟩
  intro i k hk
  unfold readSnapshot
  rw [sel i k hk]
  cases k with
  | zero => simp [at₀, a, read_point]
  | succ k => rfl

theorem trajectory_cases (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ) (c : DirectMemory.Tape Q Γ) (n) :
    let t := rounds n (seed tags M blank c)
    select tags t = none ∨ ∃ i p, select tags t = some p ∧
      atPath t p = some (point tags M blank c i) ∧
      readSnapshot tags t = some (clock (next M blank) i c) := by
  obtain ⟨d,p,positive,_,_,loc,sel,read⟩ := all_snapshots tags M blank c
  obtain ⟨i,k,hk,rfl⟩ := time_partition positive n
  cases k with
  | zero =>
    exact Or.inr ⟨i,location p i,by simpa using sel i 0 hk,
      by simpa using loc i,by simpa using read i 0 hk⟩
  | succ k => exact Or.inl (by simpa using sel i (k+1) hk)

theorem read_graph (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ)
    (c y : DirectMemory.Tape Q Γ) :
    (∃ n, readSnapshot tags (rounds n (seed tags M blank c)) = some y) ↔
      ∃ i, clock (next M blank) i c = y := by
  obtain ⟨d,p,positive,_,_,_,_,snap⟩ := all_snapshots tags M blank c
  constructor
  · rintro ⟨n,hit⟩
    obtain ⟨i,k,hk,rfl⟩ := time_partition positive n
    rw [snap i k hk] at hit
    split at hit
    · exact ⟨i, Option.some.inj hit⟩
    · contradiction
  · rintro ⟨i,rfl⟩
    exact ⟨time d i,by simpa using snap i 0 (positive i)⟩

theorem selection_regular (tags : Tags Q Γ) :
    MarkRegular (fun t => (select tags t.erase).any t.atPath = true) ∧
    Regular (fun t => (select tags t).isSome = true) :=
  full_regular tags CP (by change 0 ≤ _; omega)

theorem linear_seed (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ) :
    ∃ a b, ∀ c, size (seed tags M blank c) ≤ a+b*(c.focus.length+c.opposite.length) :=
  seed_linear_size tags (optional M) blank

end DirectTrajectory

#print axioms DirectTrajectory.all_snapshots
#print axioms DirectTrajectory.read_graph
#print axioms DirectTrajectory.selection_regular
#print axioms DirectTrajectory.linear_seed
