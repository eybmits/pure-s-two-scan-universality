import DirectDecode
import DirectReader

/-! Bounds on the physical work of the snapshot reader. Size here counts S
leaves of the ordinary expanded tree (an N-leaf tree has 2N-1 nodes).
Tag tables and the reader program are fixed independently of the input. -/
namespace DirectCost
open TwoScans TwoScans.Term TwoScans.Frames DirectReader DirectMemory
open DirectMemory.Decode DirectS

/-- A reported address takes at most as many vertices as there are leaves.
The result is independent of the particular reader or the finite-state tests. -/
theorem selection_depth {Q H} (r : Reader Q H) {q : Q} {tree path}
    (selected : r.select tree q = some path) : path.length + 1 ≤ size tree := by
  induction tree generalizing q path with
  | s =>
    simp only [Reader.select] at selected
    split at selected
    · cases selected; exact Nat.le_refl _
    · contradiction
  | app l t il it =>
    simp only [Reader.select] at selected
    split at selected
    · contradiction
    · cases selected
      exact sizePos _
    · rename_i k _
      cases observed : r.select l k with
      | none => simp [observed] at selected
      | some p =>
        simp [observed] at selected; subst path
        have bound := il observed; have positive := sizePos t
        simp only [List.length_cons,size]; omega
    · rename_i k _
      cases observed : r.select t k with
      | none => simp [observed] at selected
      | some p =>
        simp [observed] at selected; subst path
        have bound := it observed; have positive := sizePos l
        simp only [List.length_cons,size]; omega

variable {Q Γ : Type} [DecidableEq Q] [DecidableEq Γ]

/-- Count even the recursive inspections that an early missing symbol could
have avoided. Any successful old descriptor is on a fixed nonempty path. -/
def stackVisits (symbols : Alphabet (Desc.Tag Q Γ)) (t : Term) : Nat :=
  match inspect symbols t with
  | none => 1
  | some k =>
    match k.k with
    | .zero | .baseEmpty => 1
    | .base =>
      match _h : atPath t basePath with
      | none => 1
      | some old => 1 + stackVisits symbols old
    | .straight =>
      match _h : atPath t straightPath with
      | none => 1
      | some old => 1 + stackVisits symbols old
    | .turn =>
      match _h : atPath t turnPath with
      | none => 1
      | some old => 1 + stackVisits symbols old
termination_by size t
decreasing_by all_goals apply atPath_strict; assumption

theorem stack_visits_le (symbols : Alphabet (Desc.Tag Q Γ)) (t : Term) :
    stackVisits symbols t ≤ size t := by
  suffices bound : ∀ (n : Nat) (t : Term), size t = n → stackVisits symbols t ≤ size t from
    bound _ t rfl
  intro n
  induction n using Nat.strongRecOn with
  | ind n ih =>
    intro t eq
    have positive := sizePos t
    rw [stackVisits]
    split
    · omega
    · split
      · omega
      · omega
      all_goals
        split
        · omega
        · rename_i old ho
          have smaller := atPath_strict ho
          have previous := ih (size old) (by omega) old rfl
          omega



theorem stack_output_le (symbols : Alphabet (Desc.Tag Q Γ)) (t : Term) {xs : List Γ}
    (out : stack symbols t = some xs) : xs.length ≤ stackVisits symbols t := by
  suffices bound : ∀ (n : Nat) (t : Term), size t = n → ∀ xs, stack symbols t = some xs →
      xs.length ≤ stackVisits symbols t from bound _ t rfl xs out
  intro n
  induction n using Nat.strongRecOn with
  | ind n ih =>
    intro t eq xs out
    rw [stack] at out
    rw [stackVisits]
    cases hk : inspect symbols t with
    | none => simp [hk] at out
    | some tag =>
      cases kind : tag.k with
      | zero | baseEmpty => simp [hk,kind] at out; subst xs; exact Nat.zero_le _
      | base | straight | turn =>
        simp only [hk,kind] at out ⊢
        split at out
        · contradiction
        · rename_i old seen
          split
          · rename_i failed; rw [failed] at seen; contradiction
          · rename_i old' eq'
            rw [seen] at eq'; cases eq'
            have smaller := atPath_strict seen
            cases cell : tag.head with
            | none => simp [cell] at out
            | some symbol =>
              cases tail : stack symbols old with
              | none => simp [cell,tail] at out
              | some ys =>
                have previous := ih (size old) (by omega) old rfl ys tail
                simp [cell,tail] at out
                subst xs
                simp only [List.length_cons,List.length_tail]
                omega

/-- The two roots given to the stack readers lie in opposite subtrees of the
checkpoint. Their combined visit budget is at most its leaf count. -/
theorem pair_budget (symbols : Alphabet (Desc.Tag Q Γ)) {t u v : Term}
    (focus : atPath t [false,true,true] = some u)
    (opposite : atPath t [true,true,true] = some v) :
    stackVisits symbols u + stackVisits symbols v ≤ size t := by
  cases t with
  | s => contradiction
  | app l r =>
    have left : size u ≤ size l := atPath_size (t:=l) (p:=[true,true]) focus
    have right : size v ≤ size r := atPath_size (t:=r) (p:=[true,true]) opposite
    have fu := stack_visits_le symbols u
    have fv := stack_visits_le symbols v
    simp only [size]; omega

end DirectCost
#print axioms DirectCost.selection_depth
#print axioms DirectCost.stack_output_le
#print axioms DirectCost.pair_budget
