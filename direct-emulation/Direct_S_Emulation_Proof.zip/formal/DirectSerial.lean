import DirectCertified
import SerialReadout

/-! The direct construction can be run one ordinary contraction at a time,
testing the same regular condition after every move and stopping at its first
success. The two copies are parts of one finite pure-S tree. -/
namespace DirectSerial
open TwoScans TwoScans.Frames TwoScans.Automata TwoScans.SerialReadout SerialTableau Turing

set_option linter.style.haveILetI false
theorem first_output :
    ∃ (P : Type) (fp : FinStates P) (dp : DecidableEq P) (st : Inhabited P)
      (M : @TM0.Machine UniversalPost.Cell P st) (a b : Nat), letI := fp; letI := dp; letI := st
      let D := double (DirectCertified.read P)
      let E := fun p x => let e := DirectCertified.encode M p x; pack e e
      Regular (fun t => ∃ y, D t = some y) ∧
      (∀ p x, size (E p x) ≤ a + b*(p.length+x.length)) ∧
      (∀ p x n, Path (E p x) (post (E p x) n) (rounds n (E p x))) ∧
      ∀ f : List Bool →. List Bool, Partrec f → ∃ p : List Bool, ∀ x y,
        (∃ n, readFirst D (E p x) n = some y) ↔ y ∈ f x := by
  obtain ⟨P,fp,dp,st,M,a,b,reg,cap,works⟩ := DirectCertified.universality
  letI := fp
  letI := dp
  letI := st
  let e := DirectCertified.encode M
  let d := DirectCertified.read P
  refine ⟨P,fp,dp,st,M,1+2*a,2*b,regular_double d reg,?_,fun p x n => prefix_path _ n,?_⟩
  · intro p x
    have := cap p x
    simp only [pack,size,Nat.mul_assoc]
    omega
  · intro f hf
    obtain ⟨p,graph⟩ := works f hf
    refine ⟨p,fun x y => ?_⟩
    constructor
    · rintro ⟨n,out⟩
      exact (graph x y).mp (first_from_parallel d (e p x) n out)
    · intro member
      obtain ⟨n,hit⟩ := (graph x y).mpr member
      obtain ⟨z,first⟩ := parallel_has_first d (e p x) n hit
      have hz := (graph x z).mp (first_from_parallel d (e p x) n first)
      exact ⟨n,Part.mem_unique hz member ▸ first⟩

end DirectSerial
#print axioms DirectSerial.first_output
