import DirectMemoryRoute

/-! On each stack the decoder only visits successively smaller physical
subtrees. Its fixed table recognizes the finite label. It never calls a
machine transition or unfolds an S reduction. -/
namespace DirectMemory.Decode
open TwoScans TwoScans.Term TwoScans.Frames DirectS
open Encoding Compiled
variable {Q Γ : Type} [DecidableEq Q] [DecidableEq Γ]

def lookup (symbols : Alphabet (Desc.Tag Q Γ)) (t : Term) : Option (Desc.Tag Q Γ) :=
  symbols.items.find? (fun k => decide (marker symbols k = t))

@[simp] theorem lookup_marker (symbols : Alphabet (Desc.Tag Q Γ)) (k : Desc.Tag Q Γ) :
    lookup symbols (marker symbols k) = some k := by
  unfold lookup
  cases eq : symbols.items.find? (fun a => decide (marker symbols a = marker symbols k)) with
  | some a =>
    congr 1
    have ha := List.find?_some (p := fun a => decide (marker symbols a = marker symbols k)) eq
    exact marker_unique symbols (of_decide_eq_true ha)
  | none =>
    have hs := List.find?_eq_none.mp eq k (symbols.cover k)
    simp at hs

def inspect (symbols : Alphabet (Desc.Tag Q Γ)) : Term → Option (Desc.Tag Q Γ)
  | .app (.app .s (.app .s k)) _ => lookup symbols k
  | _ => none

@[simp] theorem inspect_descriptor (symbols : Alphabet (Desc.Tag Q Γ)) (k : Desc.Tag Q Γ) (p) :
    inspect symbols (descriptor (marker symbols k) p) = some k := lookup_marker symbols k

@[simp] theorem inspect_encode (symbols : Alphabet (Desc.Tag Q Γ)) (δ) (blank) (u : Desc Q Γ) :
    inspect symbols ((encoding symbols δ blank).encode u) = some u.tag := by
  cases u <;> apply inspect_descriptor

theorem at_nil (t : Term) : atPath t [] = some t := by cases t <;> rfl

def basePath := [true,true,true,true]
def straightPath := [true,false,true]
def turnPath := [true,true,true,false,true]

theorem atPath_size {t u p} (seen : atPath t p = some u) : size u ≤ size t := by
  induction p generalizing t with
  | nil => simpa [atPath] using (by simpa [atPath] using seen : t = u) ▸ Nat.le_refl (size u)
  | cons b ps ih =>
    cases t with
    | s => simp [atPath] at seen
    | app l r =>
      cases b with
      | false => exact Nat.le_trans (ih (t:=l) seen) (Nat.le_add_right _ _)
      | true => exact Nat.le_trans (ih (t:=r) seen) (Nat.le_add_left _ _)

theorem atPath_strict {t u b p} (seen : atPath t (b::p) = some u) : size u < size t := by
  cases t with
  | s => simp [atPath] at seen
  | app l r =>
    have hl := sizePos l
    have hr := sizePos r
    cases b with
    | false => have le := atPath_size (t:=l) seen; simp only [size]; omega
    | true => have le := atPath_size (t:=r) seen; simp only [size]; omega

/-- One path per stack cell (one lookup per descriptor). At a reversal we
read the older focus and discard its first symbol. All paths have length at
most five. Outside the representation, malformed or missing data give none. -/
def stack (symbols : Alphabet (Desc.Tag Q Γ)) (t : Term) : Option (List Γ) :=
  match inspect symbols t with
  | none => none
  | some tag =>
    match tag.k with
    | .zero | .baseEmpty => some []
    | .base =>
      match _hb : atPath t basePath with
      | none => none
      | some old => do return (← tag.head) :: (← stack symbols old)
    | .straight =>
      match _hs : atPath t straightPath with
      | none => none
      | some old => do return (← tag.head) :: (← stack symbols old)
    | .turn =>
      match _ht : atPath t turnPath with
      | none => none
      | some old => do return (← tag.head) :: (← stack symbols old).tail
termination_by size t
decreasing_by all_goals apply atPath_strict; assumption

/-- An encoding represents its complete stack, independently of the machine
table used in the library. Reversals may be arbitrarily deeply nested. -/
theorem stack_correct (symbols : Alphabet (Desc.Tag Q Γ)) (δ) (blank) (u : Desc Q Γ) :
    stack symbols ((encoding symbols δ blank).encode u) = some u.contents := by
  let e := encoding symbols δ blank
  induction u with
  | zero => rw [stack,inspect_encode]; rfl
  | baseEmpty m => rw [stack,inspect_encode]; rfl
  | base m c t ih =>
    have path : atPath (e.encode (Desc.base m c t)) basePath = some (e.encode t) := at_nil _
    rw [stack,inspect_encode]
    dsimp only [e] at path
    simp only [Desc.tag, Desc.kind, Desc.top, Desc.contents]
    split <;> rename_i hp <;> rw [path] at hp
    · contradiction
    · cases hp; simp [ih]
  | grown b m c u v hu hv =>
    cases b with
    | false =>
      have path : atPath (e.encode (Desc.grown false m c u v)) straightPath = some (e.encode v) := at_nil _
      rw [stack,inspect_encode]
      dsimp only [e] at path
      simp only [Desc.tag, Desc.kind, Desc.top, Desc.contents]
      split <;> rename_i hp <;> rw [path] at hp
      · contradiction
      · cases hp; simp [hv]
    | true =>
      have path : atPath (e.encode (Desc.grown true m c u v)) turnPath = some (e.encode u) := at_nil _
      rw [stack,inspect_encode]
      dsimp only [e] at path
      simp only [Desc.tag, Desc.kind, Desc.top, Desc.contents]
      split <;> rename_i hp <;> rw [path] at hp
      · contradiction
      · cases hp; simp [hu]

/-- The decoder takes the selected original S subtree. The table and its
transition rules are absent from its arguments. -/
def read (symbols : Alphabet (Desc.Tag Q Γ)) (t : Term) : Option (Tape Q Γ) := do
  let u ← atPath t [false,true,true]
  let v ← atPath t [true,true,true]
  let k ← inspect symbols v
  let m ← k.control
  let f ← stack symbols u
  let o ← stack symbols v
  return ⟨m,f,o⟩

theorem read_correct (symbols : Alphabet (Desc.Tag Q Γ)) (δ) (blank)
    (h : Heap Q Γ) (t : Tape Q Γ) (rep : h.Represents t) :
    read symbols ((encoding symbols δ blank).checkpoint h) = some t := by
  obtain ⟨control, _, hf, ho⟩ := rep
  let e := encoding symbols δ blank
  have vu : atPath (e.checkpoint h) [false,true,true] = some (e.encode h.focus) := at_nil _
  have vv : atPath (e.checkpoint h) [true,true,true] = some (e.encode h.opposite) := at_nil _
  unfold read
  rw [vu,vv]
  simp [e, Desc.tag, control, stack_correct, hf, ho]

end DirectMemory.Decode

#print axioms DirectMemory.Decode.read_correct
