import DirectTrajectory
import DirectQueries

namespace DirectTrajectory
open TwoScans TwoScans.Frames DirectMemory DirectControl
variable {Q Γ : Type} [DecidableEq Q] [DecidableEq Γ]

/-- The finite test on the selected physical node returns exactly the answer
to querying that source state. All non-checkpoint rounds return false. -/
theorem hit_iff (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ) (c : Tape Q Γ)
    (pred : Q → Bool) (n : Nat) :
    let t := rounds n (seed tags M blank c)
    DirectQueries.hit tags pred t = (readSnapshot tags t).any (fun y => pred y.control.state) := by
  let t := rounds n (seed tags M blank c)
  change DirectQueries.hit tags pred t = (readSnapshot tags t).any _
  rcases trajectory_cases tags M blank c n with absent | ⟨i,p,selected,phys,read⟩
  · rw [DirectQueries.hit_none tags pred absent]
    simp [readSnapshot, t, absent]
  · rw [DirectQueries.hit_at tags pred (optional M) blank selected phys (history_correct M blank c i)]
    rw [show readSnapshot tags t = some _ from read]
    rfl

end DirectTrajectory
#print axioms DirectTrajectory.hit_iff
