import Std

/-! Memory semantics of a two-stack tape. Both old descriptors survive in a
new environment. A new cell may refer to the old opposite stack or to the
tail of the old focus, depending on whether the machine reversed direction. -/
namespace DirectMemory

structure Mark (Q : Type) where
  state : Q
  rightward : Bool
  deriving DecidableEq, Repr

inductive Kind where
  | zero | baseEmpty | base | straight | turn
  deriving DecidableEq, Repr

inductive Desc (Q Γ : Type) where
  | zero
  | baseEmpty (mark : Mark Q)
  | base (mark : Mark Q) (symbol : Γ) (rest : Desc Q Γ)
  | grown (turn : Bool) (mark : Mark Q) (symbol : Γ)
      (oldFocus oldOpposite : Desc Q Γ)
  deriving Repr

namespace Desc
variable {Q Γ : Type}

def empty : Desc Q Γ → Bool
  | .zero | .baseEmpty _ => true
  | .base .. | .grown .. => false

def tailEmpty : Desc Q Γ → Bool
  | .zero | .baseEmpty _ => true
  | .base _ _ t => t.empty
  | .grown false _ _ _ v => v.empty
  | .grown true _ _ u _ => u.tailEmpty

def kind : Desc Q Γ → Kind
  | .zero => .zero
  | .baseEmpty _ => .baseEmpty
  | .base .. => .base
  | .grown false .. => .straight
  | .grown true .. => .turn

def top : Desc Q Γ → Option Γ
  | .zero | .baseEmpty _ => none
  | .base _ c _ | .grown _ _ c _ _ => some c

def mark : Desc Q Γ → Option (Mark Q)
  | .zero => none
  | .baseEmpty s | .base s .. | .grown _ s .. => some s

def contents : Desc Q Γ → List Γ
  | .zero | .baseEmpty _ => []
  | .base _ c t => c :: t.contents
  | .grown false _ c _ v => c :: v.contents
  | .grown true _ c u _ => c :: u.contents.tail

def canonical (u : Desc Q Γ) : Desc Q Γ := if u.empty then .zero else u

/-- Empty tails are always returned as the fixed empty sentinel. -/
def tail : Desc Q Γ → Desc Q Γ
  | .zero | .baseEmpty _ => .zero
  | .base _ _ t => t.canonical
  | .grown false _ _ _ v => v.canonical
  | .grown true _ _ u _ => u.tail

@[simp] theorem canonical_contents (u : Desc Q Γ) : u.canonical.contents = u.contents := by
  cases u with
  | zero | baseEmpty | base => rfl
  | grown b => cases b <;> rfl

@[simp] theorem canonical_empty (u : Desc Q Γ) : u.canonical.empty = u.empty := by
  cases u <;> rfl

@[simp] theorem top_contents (u : Desc Q Γ) : u.contents.head? = u.top := by
  cases u with
  | zero | baseEmpty | base => rfl
  | grown b => cases b <;> rfl

@[simp] theorem empty_contents (u : Desc Q Γ) : u.contents.isEmpty = u.empty := by
  cases u with
  | zero | baseEmpty | base => rfl
  | grown b => cases b <;> rfl

@[simp] theorem tail_contents (u : Desc Q Γ) : u.tail.contents = u.contents.tail := by
  induction u with
  | zero | baseEmpty => rfl
  | base s c t ih => exact canonical_contents _
  | grown b s c u v hu hv => cases b <;> simp [tail, contents, hu]

@[simp] theorem tail_empty (u : Desc Q Γ) : u.tail.empty = u.tailEmpty := by
  induction u with
  | zero | baseEmpty => rfl
  | base => exact canonical_empty _
  | grown b s c u v hu hv => cases b <;> simp [tail, tailEmpty, hu]

theorem canonical_eq_zero {u : Desc Q Γ} (h : u.empty = true) :
    u.canonical = .zero := by simp [canonical, h]

theorem tail_eq_zero {u : Desc Q Γ} (h : u.tailEmpty = true) : u.tail = .zero := by
  induction u with
  | zero | baseEmpty => rfl
  | base => exact canonical_eq_zero h
  | grown b s c u v hu hv =>
    cases b with
    | false => exact canonical_eq_zero h
    | true => exact hu h

structure Tag (Q Γ : Type) where
  k : Kind
  control : Option (Mark Q)
  head : Option Γ
  endAfter : Bool
  deriving DecidableEq, Repr

def tag (u : Desc Q Γ) : Tag Q Γ := ⟨u.kind, u.mark, u.top, u.tailEmpty⟩

/-- The finite lookup table computes the label of the new cell using only the
two old top labels and the finite instruction. -/
def newTag (turn : Bool) (s : Mark Q) (c : Γ) (a b : Tag Q Γ) : Tag Q Γ :=
  ⟨if turn then .turn else .straight, some s, some c,
    if turn then a.endAfter else b.head.isNone⟩

theorem top_none_empty (u : Desc Q Γ) : u.top.isNone = u.empty := by cases u <;> rfl

theorem tag_grown (b : Bool) (s : Mark Q) (c : Γ) (u v : Desc Q Γ) :
    (grown b s c u v).tag = newTag b s c u.tag v.tag := by
  cases b with
  | false => cases v <;> rfl
  | true => rfl

/-- Library search on a valid opposite descriptor follows the previous
opposite descriptor once for every allocated cell. -/
def hasLibrary : Desc Q Γ → Bool
  | .zero => false
  | .baseEmpty _ | .base .. => true
  | .grown _ _ _ _ v => v.hasLibrary

def initial (s : Mark Q) : List Γ → Desc Q Γ
  | [] => .baseEmpty s
  | c :: t => .base s c (initial s t)

@[simp] theorem initial_contents (s : Mark Q) (xs : List Γ) :
    (initial s xs).contents = xs := by induction xs <;> simp [initial, contents, *]

@[simp] theorem initial_library (s : Mark Q) (xs : List Γ) :
    (initial s xs).hasLibrary = true := by cases xs <;> rfl

@[simp] theorem initial_meta (s : Mark Q) (xs : List Γ) :
    (initial s xs).mark = some s := by cases xs <;> rfl

end Desc

/-- A configuration read in the orientation of the last head move. The next
input is the first symbol of the focus list, or the blank symbol if empty. -/
structure Tape (Q Γ : Type) where
  control : Mark Q
  focus : List Γ
  opposite : List Γ
  deriving DecidableEq, Repr

structure Heap (Q Γ : Type) where
  focus : Desc Q Γ
  opposite : Desc Q Γ
  deriving Repr

structure Instruction (Q Γ : Type) where
  nextState : Q
  write : Γ
  moveRight : Bool
  deriving DecidableEq, Repr

namespace Heap
variable {Q Γ : Type}

def Represents (h : Heap Q Γ) (t : Tape Q Γ) : Prop :=
  h.opposite.mark = some t.control ∧ h.opposite.hasLibrary = true ∧
    h.focus.contents = t.focus ∧ h.opposite.contents = t.opposite

def initial (t : Tape Q Γ) : Heap Q Γ :=
  ⟨.initial t.control t.focus, .initial t.control t.opposite⟩

theorem represents_initial (t : Tape Q Γ) : Represents (initial t) t := by
  simp [Represents, initial]

def advance (h : Heap Q Γ) (b : Bool) (s : Mark Q) (c : Γ) : Heap Q Γ :=
  ⟨if b then h.opposite else h.focus.tail, .grown b s c h.focus h.opposite⟩

def tapeAdvance (t : Tape Q Γ) (i : Instruction Q Γ) : Tape Q Γ :=
  let b := i.moveRight != t.control.rightward
  ⟨⟨i.nextState, i.moveRight⟩, if b then t.opposite else t.focus.tail,
    i.write :: (if b then t.focus.tail else t.opposite)⟩

theorem represents_advance (h : Heap Q Γ) (t : Tape Q Γ) (i : Instruction Q Γ)
    (ht : h.Represents t) :
    (advance h (i.moveRight != t.control.rightward) ⟨i.nextState, i.moveRight⟩ i.write).Represents
      (tapeAdvance t i) := by
  obtain ⟨_, lib, hf, hv⟩ := ht
  cases hb : (i.moveRight != t.control.rightward) <;>
    simp [Represents, advance, tapeAdvance, hb, Desc.mark, Desc.hasLibrary, Desc.contents, lib, hf, hv]

/-- One deterministic dispatch from the top labels. An absent instruction is a
halt, and lack of a control label is an invalid raw state. -/
def machineStep (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ) (h : Heap Q Γ) :
    Option (Heap Q Γ) := do
  let s ← h.opposite.mark
  let i ← δ s.state (h.focus.top.getD blank)
  pure (advance h (i.moveRight != s.rightward) ⟨i.nextState, i.moveRight⟩ i.write)

def tapeStep (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ) (t : Tape Q Γ) :
    Option (Tape Q Γ) :=
  (δ t.control.state (t.focus.head?.getD blank)).map (tapeAdvance t)

def Related {α β : Type} (R : α → β → Prop) : Option α → Option β → Prop
  | none, none => True
  | some a, some b => R a b
  | _, _ => False

theorem machine_step_correct (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ)
    {h : Heap Q Γ} {t : Tape Q Γ} (ht : h.Represents t) :
    Related Represents (machineStep δ blank h) (tapeStep δ blank t) := by
  have head : h.focus.top = t.focus.head? := by rw [← ht.2.2.1, Desc.top_contents]
  cases hδ : δ t.control.state (t.focus.head?.getD blank) with
  | none => simp [machineStep, tapeStep, ht.1, head, hδ, Related]
  | some i => simpa [machineStep, tapeStep, ht.1, head, hδ, Related] using represents_advance h t i ht

end Heap
end DirectMemory
