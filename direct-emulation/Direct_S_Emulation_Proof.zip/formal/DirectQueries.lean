import DirectControl

/-! A fixed detector reads one finite state label at the actual selected
subtree. The same finite fold works on arbitrary ground S snapshots. -/
namespace DirectQueries
open TwoScans TwoScans.Term TwoScans.Automata
open DirectS DirectReader DirectControl DirectMemory DirectMemory.Compiled
variable {Q Γ : Type} [DecidableEq Q] [DecidableEq Γ]

/-- From C(u) C(v), the three right choices give v. Its label has path LRR. -/
def statePath := [true,true,true] ++ tagPath

def cellQuery (tags : Tags Q Γ) (pred : Q → Bool) : Attribute Bool :=
  (lookup tags statePath tags.items).map fun tag =>
    (tag.bind (·.control)).any (fun m => pred m.state)

def hit (tags : Tags Q Γ) (pred : Q → Bool) (t : Term) : Bool :=
  ((reader tags).select t ([],.check)).any (fun p =>
    (atPath t p).any (cellQuery tags pred).get)

theorem hit_none (tags : Tags Q Γ) (pred : Q → Bool) {t : Term}
    (noneSeen : (reader tags).select t ([],.check) = none) : hit tags pred t = false := by
  simp [hit,noneSeen]

theorem cellQuery_at (tags : Tags Q Γ) (pred : Q → Bool) (δ) (blank : Γ)
    {h : Heap Q Γ} {c : Tape Q Γ} (rep : h.Represents c) :
    (cellQuery tags pred).get ((encoding tags δ blank).checkpoint h) = pred c.control.state := by
  let e := encoding tags δ blank
  have field : atPath (e.checkpoint h) statePath = some (marker tags h.opposite.tag) := by
    have part : atPath (e.checkpoint h) [true,true,true] = some (e.encode h.opposite) := by
      simp [Encoding.checkpoint,cell,atPath]
    exact path_append part (encoded_tag tags δ blank _)
  rw [cellQuery,get_map,lookup_spec tags statePath tags.items _ _ (tags.cover _) field]
  simp [Desc.tag,rep.1]

theorem hit_at (tags : Tags Q Γ) (pred : Q → Bool) (δ) (blank : Γ)
    {t : Term} {p : List Bool} {h : Heap Q Γ} {c : Tape Q Γ}
    (selected : (reader tags).select t ([],.check) = some p)
    (physical : atPath t p = some ((encoding tags δ blank).checkpoint h))
    (rep : h.Represents c) : hit tags pred t = pred c.control.state := by
  simp [hit,selected,physical,cellQuery_at tags pred δ blank rep]

theorem hit_regular (tags : Tags Q Γ) (pred : Q → Bool) :
    Regular (fun t => hit tags pred t = true) := by
  classical
  let a := cellQuery tags pred
  have hp : Regular (fun u => a.get u = true) :=
    ⟨a.State,a.states,a.alg,a.out,fun _ => Iff.rfl⟩
  letI := finiteModes tags
  letI := (summary tags).states
  let q : State Q Γ := ([],.check)
  have hq : Fits tags q := Nat.zero_le _
  obtain ⟨V,v,alg,finish,ok⟩ :=
    regular_at_selected (boundedReader tags) (⟨q,hq⟩ : Small tags) hp
  refine ⟨V,v,alg,finish,fun t => (ok t).trans ?_⟩
  simp only [bounded_agrees]
  change (∃ p u, (reader tags).select t q = some p ∧ atPath t p = some u ∧ a.get u = true) ↔
    ((reader tags).select t q).any (fun p => (atPath t p).any a.get) = true
  cases hs : (reader tags).select t q with
  | none => simp
  | some p =>
    simp only [Option.some.injEq,Option.any_some]
    cases ha : atPath t p with
    | none => simp [ha]
    | some u => simp [ha]

end DirectQueries
#print axioms DirectQueries.hit_regular
#print axioms DirectQueries.hit_at
