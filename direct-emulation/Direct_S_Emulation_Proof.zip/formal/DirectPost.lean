import FiniteUniversalPost
import DirectMemoryRoute

/-! The source semantics really is a standard two-sided universal Turing tape.
A write-only Post instruction takes two oriented head moves. -/
namespace DirectPost
open Turing DirectMemory StateTransition
open Relation
variable {Γ P : Type} [Inhabited Γ] [Inhabited P]
abbrev Control (P : Type) := P × Bool -- true: returning from a write

def instruction (M : TM0.Machine Γ P) : Control P → Γ → Option (Instruction (Control P) Γ)
  | (p,true), a => some ⟨(p,false),a,false⟩
  | (p,false), a => (M p a).map fun (p', op) => match op with
    | .move .right => ⟨(p',false),a,true⟩
    | .move .left => ⟨(p',false),a,false⟩
    | .write b => ⟨(p',true),b,true⟩

def view {Q : Type} (t : DirectMemory.Tape Q Γ) : Turing.Tape Γ :=
  ⟨t.focus.head?.getD default,
   ListBlank.mk (if t.control.rightward then t.opposite else t.focus.tail),
   ListBlank.mk (if t.control.rightward then t.focus.tail else t.opposite)⟩

def start (xs : List Γ) : DirectMemory.Tape (Control P) Γ := ⟨⟨(default,false),true⟩,xs,[]⟩

theorem view_start (xs : List Γ) : view (start (P:=P) xs) = Turing.Tape.mk₁ xs := by
  cases xs <;> rfl

omit [Inhabited P] in
theorem view_advance {Q : Type} (t : DirectMemory.Tape Q Γ) (i : Instruction Q Γ) :
    view (Heap.tapeAdvance t i) =
      ((view t).write i.write).move (if i.moveRight then .right else .left) := by
  rcases t with ⟨⟨q,d⟩,f,m⟩
  rcases i with ⟨q',w,d'⟩
  cases d <;> cases d' <;> cases f with
  | nil => cases m <;> rfl
  | cons a f => cases f <;> cases m <;> rfl

theorem write_read (t : Turing.Tape Γ) : t.write t.head = t := by cases t; rfl

def aligned (c : TM0.Cfg Γ P) (t : DirectMemory.Tape (Control P) Γ) : Prop :=
  t.control.state = (c.q,false) ∧ view t = c.Tape

theorem respects (M : TM0.Machine Γ P) :
    Respects (TM0.step M) (Heap.tapeStep (instruction M) default) aligned := by
  rintro ⟨q,tape⟩ t ⟨hq,hv⟩
  change t.control.state = (q,false) at hq
  change view t = tape at hv
  subst tape
  simp only [TM0.step]
  cases hm : M q (view t).head with
  | none =>
    simp only [Option.map_none]
    simp [Heap.tapeStep,hq,instruction,show t.focus.head?.getD default = (view t).head from rfl,hm]
  | some i =>
    rcases i with ⟨q',op⟩
    have single (i : Instruction (Control P) Γ)
        (h : instruction M t.control.state (view t).head = some i) :
        StateTransition.Reaches₁ (Heap.tapeStep (instruction M) default) t (Heap.tapeAdvance t i) :=
      Relation.TransGen.single (show Heap.tapeStep (instruction M) default t = _ by
        unfold Heap.tapeStep; change (instruction M _ (view t).head).map _ = _; rw [h]; rfl)
    cases op with
    | move d =>
      cases d with
      | left =>
        let i : Instruction (Control P) Γ := ⟨(q',false),(view t).head,false⟩
        refine ⟨Heap.tapeAdvance t i, ⟨rfl,?_⟩,single i ?_⟩
        · simp [i,view_advance]
        · simp [i,hq,instruction,hm]
      | right =>
        let i : Instruction (Control P) Γ := ⟨(q',false),(view t).head,true⟩
        refine ⟨Heap.tapeAdvance t i, ⟨rfl,?_⟩,single i ?_⟩
        · simp [i,view_advance]
        · simp [i,hq,instruction,hm]
    | write b =>
      let i : Instruction (Control P) Γ := ⟨(q',true),b,true⟩
      let mid := Heap.tapeAdvance t i
      let j : Instruction (Control P) Γ := ⟨(q',false),(view mid).head,false⟩
      refine ⟨Heap.tapeAdvance mid j,⟨rfl,?_⟩,(single i ?_).tail ?_⟩
      · rw [view_advance]
        change ((view mid).write (view mid).head).move .left = _
        rw [write_read]
        simp [mid,view_advance,i]
      · simp [i,hq,instruction,hm]
      · rfl

theorem eval_tape (M : TM0.Machine Γ P) (input : List Γ) (out : ListBlank Γ) :
    out ∈ TM0.eval M input ↔
    ∃ t, t ∈ StateTransition.eval (Heap.tapeStep (instruction M) default) (start input) ∧
      (view t).right₀ = out := by
  have init : aligned (TM0.init input) (start (P:=P) input) := ⟨rfl,view_start _⟩
  constructor
  · intro mem
    obtain ⟨c,hc,rfl⟩ := (Part.mem_map_iff _).mp mem
    obtain ⟨t,atEnd,ht⟩ := StateTransition.tr_eval (respects M) init hc
    exact ⟨t,ht,congrArg Turing.Tape.right₀ atEnd.2⟩
  · rintro ⟨t,ht,rfl⟩
    obtain ⟨c,atEnd,hc⟩ := StateTransition.tr_eval_rev (respects M) init ht
    exact (Part.mem_map_iff _).mpr ⟨c,hc,congrArg Turing.Tape.right₀ atEnd.2.symm⟩

end DirectPost
#print axioms DirectPost.respects
#print axioms DirectPost.eval_tape
