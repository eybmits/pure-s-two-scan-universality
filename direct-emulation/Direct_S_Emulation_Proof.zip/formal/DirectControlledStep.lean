import DirectControl

/-! The actual finite-word control through every intermediate round of one
encoded machine transition, including repeated reversals. -/
namespace DirectControlled
open TwoScans TwoScans.Term TwoScans.Frames
open DirectS DirectReader DirectMemory DirectMemory.Compiled DirectMemory.Encoding DirectControl
local infixl:65 " ⋄ " => Term.app
variable {Q Γ : Type} [DecidableEq Q] [DecidableEq Γ]

def Journey (tags : Tags Q Γ) (emit : Bool) (t : Term) (q : State Q Γ) (v : Term) (s : State Q Γ) : Prop :=
  ∃ n p, Span (reader tags) emit n p t q v s

theorem Journey.one {tags : Tags Q Γ} {emit n p t q v k} (h : Span (reader tags) emit n p t q v k) :
    Journey tags emit t q v k := ⟨_,_,h⟩

theorem Journey.comp {tags : Tags Q Γ} {emit t q v k z s}
    (a : Journey tags emit t q v k) (b : Journey tags false v k z s) :
    Journey tags emit t q z s := by
  obtain ⟨_,_,x⟩ := a
  obtain ⟨_,_,y⟩ := b
  exact .one (x.comp y)

abbrev CP : State Q Γ := ([],.check)

private theorem env3 (tags : Tags Q Γ) {u v x} (hu : nf u=true) (hv : nf v=true)
    (hx : nf x=true) (side : Bool) (op : Atom (Key Q Γ)) :
    Journey tags false (env u v ⋄ x) ([true,true,side],op)
      ((if side then cell v else u) ⋄ x) ([],op) := by
  apply Journey.comp (.one (go_pair tags hv (by simp [hu,hv]) hx true [true,side] op))
  apply Journey.comp (.one (go_pair tags hv (by simp [hu,hv]) hx true [side] op))
  exact .one (go_pair tags hu (by simp [hv]) hx side [] op)

def libExit (tags : Tags Q Γ) (target : Option (Key Q Γ)) : State Q Γ :=
  match target with
  | none => ([true],.check)
  | some a => (false :: (address a (tags.prod tags).items ++ [false,false,true,false]),.installed a.1.endAfter)

/-- Dispatch mode and address survive each recursive library lookup. -/
theorem lib (tags : Tags Q Γ) (δ) (blank) (v : Desc Q Γ) (goal : Option (Key Q Γ))
    {x} (hx : nf x=true) (has : v.hasLibrary = true) :
    let e := encoding tags δ blank
    Journey tags false (e.encode v ⋄ x) ([],.lib goal) (e.library ⋄ x) (libExit tags goal) := by
  let e := encoding tags δ blank
  induction v with
  | zero => contradiction
  | baseEmpty m =>
    cases goal <;>
      apply Journey.comp (.one (tag_pair tags (.lib _) (by intro impossible; cases impossible) _ (by simp) hx)) <;>
      exact .one (go_pair tags (nf_library e) (by simp) hx false _ _)
  | base m c t ih =>
    cases goal <;>
      apply Journey.comp (.one (tag_pair tags (.lib _) (by intro impossible; cases impossible) _ (by simp) hx)) <;>
      exact .one (go_pair tags (nf_library e) (by simp) hx false _ _)
  | grown b m c u v hu hv =>
    apply Journey.comp (.one (tag_pair tags (.lib goal) (by intro impossible; cases impossible) _ (by simp) hx))
    have route := Journey.one (go_pair tags (b:=pair (e.encode v) (pair (e.encode u) (cell (e.encode v)))) (nf_encode e v) (by simp) hx false [] (.lib goal))
    cases b <;> exact route.comp (hv has)

/-- At a nonempty tail, every recursive reversal follows the stored old focus
with the same dispatch argument. -/
theorem pop (tags : Tags Q Γ) (δ) (blank) (u : Desc Q Γ)
    {x} (hx : nf x=true) (has : u.tailEmpty = false) :
    let e := encoding tags δ blank
    Journey tags false (e.encode u ⋄ x) ([],.pop) (cell (e.encode u.tail) ⋄ x) CP := by
  let e := encoding tags δ blank
  induction u with
  | zero | baseEmpty => contradiction
  | base m a t ih =>
    have ht : t.empty = false := has
    simp only [Desc.tail, Desc.canonical, ht, Bool.false_eq_true, ↓reduceIte]
    apply Journey.comp (.one (tag_pair tags .pop (by intro impossible; cases impossible) _ (by simp) hx))
    exact .one (go_pair tags (nf_library e) (by simp) hx true [] .check)
  | grown b m c u v hu hv =>
    cases b with
    | false =>
      have ht : v.empty = false := has
      simp only [Desc.tail, Desc.canonical, ht, Bool.false_eq_true, ↓reduceIte]
      apply Journey.comp (.one (tag_pair tags .pop (by intro impossible; cases impossible) _ (by simp) hx))
      exact env3 tags (nf_encode e u) (nf_encode e v) hx true .check
    | true =>
      apply Journey.comp (.one (tag_pair tags .pop (by intro impossible; cases impossible) _ (by simp) hx))
      exact (env3 tags (nf_encode e u) (nf_encode e v) hx false .pop).comp (hu has)

theorem continuation (tags : Tags Q Γ) (δ) (blank) (u v : Desc Q Γ) (b : Bool)
    (m : Mark Q) (c : Γ) {x} (hx : nf x=true) (has : v.hasLibrary=true) :
    let e := encoding tags δ blank
    Journey tags false (env (e.encode u) (e.encode v) ⋄ x)
      (after tags (.installed u.tailEmpty) (Desc.grown b m c u v).tag)
      (cell (e.encode (if b then v else u.tail)) ⋄ x) CP := by
  let e := encoding tags δ blank
  cases b with
  | true => exact env3 tags (nf_encode e u) (nf_encode e v) hx true .check
  | false =>
    cases ht : u.tailEmpty with
    | false => exact (env3 tags (nf_encode e u) (nf_encode e v) hx false .pop).comp (pop tags δ blank u hx ht)
    | true =>
      rw [Desc.tail_eq_zero ht]
      apply Journey.comp (.one (go_pair tags (nf_encode e v) (by simp) hx false [] (.lib none)))
      exact (lib tags δ blank v none hx has).comp
        (.one (go_pair tags e.table_normal (by simp) hx true [] .check))

theorem lookupDirectory (tags : Tags Q Γ) (f : Key Q Γ → Term) (hf : ∀ k, nf (f k)=true)
    (k : Key Q Γ) (keys : List (Key Q Γ)) (mem : k ∈ keys) {x} (hx : nf x=true)
    (todo : List Bool) (op : Atom (Key Q Γ)) :
    Journey tags false (directory f keys ⋄ x) (address k keys ++ todo,op) (f k ⋄ x) (todo,op) := by
  induction keys with
  | nil => contradiction
  | cons head ks ih =>
    by_cases he : k = head
    · subst head
      simpa [address, directory] using Journey.one (go_pair tags (hf k) (directory_normal _ hf _) hx false todo op)
    · have p := Journey.one (go_pair tags (hf head) (directory_normal _ hf ks) hx true (address k ks ++ todo) op)
      exact (by simpa [address, he, directory] using p.comp (ih (List.mem_of_ne_of_mem he mem)))

theorem seek_descriptor (tags : Tags Q Γ) (δ) (blank) (u v : Desc Q Γ) :
    let e := encoding tags δ blank
    let k := (u.tag,v.tag)
    Journey tags true (e.checkpoint ⟨u,v⟩) CP
      (e.encode v ⋄ env (e.encode u) (e.encode v)) ([],.lib (some k)) := by
  let e := encoding tags δ blank
  let k := (u.tag,v.tag)
  let op : Atom (Key Q Γ) := .lib (some k)
  let m := cell (e.encode v)
  let ctx := pair (e.encode u) m
  let j := pair (e.encode v) ctx
  let h := pair (e.encode v) j
  have hm : nf m=true := by simp [m]
  have hc : nf ctx=true := by simp [ctx,hm]
  have hj : nf j=true := by simp [j,hc]
  have hh : nf h=true := by simp [h,hj]
  have a := Journey.one (checkpoint_gate tags δ blank u v)
  have a1 := go_cell tags (nf_encode e v) hc [true,true,false] op
  have a2 := go_pair tags (nf_encode e u) hm hj true [true,false] op
  have a3 := go_cell tags (nf_encode e v) hj [false] op
  have a4 := go_pair tags (nf_encode e v) hc hh false [] op
  exact (((a.comp (.one a1)).comp (.one a2)).comp (.one a3)).comp (.one a4)

theorem make_cell (tags : Tags Q Γ) (k : Desc.Tag Q Γ) (empty : Bool) {h : Term} (hh : nf h=true) :
    let n := cell (descriptor (marker tags k) h)
    Journey tags false (install (marker tags k) ⋄ h) ([false,false,true,false],.installed empty)
      (h ⋄ n) (after tags (.installed empty) k) := by
  let t := marker tags k
  let u := descriptor t h
  let x := s ⋄ u
  let n := cell u
  have ht : nf t=true := by simp [t,Compiled.marker]
  have hu : nf u=true := by simp [u,ht,hh]
  have hx : nf x=true := by simp [x,hu]
  have hn : nf n=true := by simp [n,hu]
  let op : Atom (Key Q Γ) := .installed empty
  have f1 := Journey.one (go_feed tags (show nf (s ⋄ (s ⋄ t))=true by simp [ht])
    (show nf (feed s builder)=true by simp) hh hu [false,true,false] op)
  have f2 := go_feed tags nf_s nf_builder hu hx [true,false] op
  have f3 := go_builder tags hu [false] op
  have f4 := go_pair tags hu hn hn false [] op
  have f5 := tag_pair tags (.installed empty) (by intro imp; cases imp) k hh hn
  exact (((f1.comp (.one f2)).comp (.one f3)).comp (.one f4)).comp (.one f5)

/-- The whole S-native step with exact observer timing. All intermediate
rounds are silent; after the step the regular selector deterministically
follows the concatenated branch. -/
theorem span_step (tags : Tags Q Γ) (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ)
    (input output : Heap Q Γ) (has : input.opposite.hasLibrary = true)
    (moved : Heap.machineStep δ blank input = some output) :
    let e := encoding tags δ blank
    Journey tags true (e.checkpoint input) CP (e.checkpoint output) CP := by
  let u := input.focus
  let v := input.opposite
  let key : Key Q Γ := (u.tag,v.tag)
  let enc := encoding tags δ blank
  let h := env (enc.encode u) (enc.encode v)
  have hh : nf h=true := nf_env (nf_encode _ _) (nf_encode _ _)
  have cm : ∃ m, v.mark = some m := by
    cases hm : input.opposite.mark with
    | none => simp [Heap.machineStep, hm] at moved
    | some m => exact ⟨m,rfl⟩
  obtain ⟨m,hm⟩ := cm
  cases go : δ m.state (u.top.getD blank) with
  | none => simp [Heap.machineStep, ← show v = input.opposite from rfl,
                  ← show u = input.focus from rfl,hm,go] at moved
  | some i =>
    let turn := i.moveRight != m.rightward
    let newmark : Mark Q := ⟨i.nextState,i.moveRight⟩
    let fresh := Desc.grown turn newmark i.write u v
    have hout : Heap.advance input turn newmark i.write = output := by
      simpa [Heap.machineStep,← show v = input.opposite from rfl,
        ← show u = input.focus from rfl,hm,go,turn,newmark] using moved
    subst output
    have target : resultTag δ blank key = fresh.tag := by
      rw [show fresh.tag = Desc.newTag turn newmark i.write u.tag v.tag from Desc.tag_grown ..]
      simp [resultTag,key,Desc.tag,hm,go,turn,newmark]
    let f := fun k : Key Q Γ => install (marker tags (resultTag δ blank k))
    let op : Atom (Key Q Γ) := .installed u.tailEmpty
    have hf (k) : nf (f k) = true := by simp [f,install,Compiled.marker]
    have first := seek_descriptor tags δ blank u v
    have second := lib tags δ blank v (some key) hh has
    have enter := go_pair tags enc.table_normal (show nf (cell enc.zeroRaw) = true by simp) hh false
        (address key (tags.prod tags).items ++ [false,false,true,false]) op
    have leaf := lookupDirectory tags f hf key (tags.prod tags).items ((tags.prod tags).cover _) hh
      [false,false,true,false] op
    have build := make_cell tags fresh.tag u.tailEmpty hh
    have last := continuation tags δ blank u v turn newmark i.write
      (x:=cell (descriptor (marker tags fresh.tag) h)) (by simp [Compiled.marker,hh]) has
    have arriving := ((first.comp second).comp (.one enter)).comp leaf
    have matchLeaf : f key = install (marker tags fresh.tag) := by simp only [f,target]
    rw [matchLeaf] at arriving
    exact (arriving.comp build).comp last

end DirectControlled

#print axioms DirectControlled.span_step
