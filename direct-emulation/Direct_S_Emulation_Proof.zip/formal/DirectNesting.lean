import DirectSerial

/-! Every actual successor checkpoint is a proper descendant. After one
round the old root has a different left child. After two rounds its left
child has only one argument and stays fixed, even if the right child stops. -/
namespace DirectNesting
open TwoScans TwoScans.Term TwoScans.Frames DirectS DirectReader
open DirectTrajectory DirectTerminal DirectMemory DirectControl
local infixl:65 " ⋄ " => Term.app

private theorem sheltered (k r : Term) (hk : nf k = true) (n : Nat) :
    rounds n ((s ⋄ k) ⋄ r) = (s ⋄ k) ⋄ rounds n r := by
  induction n generalizing r with
  | zero => rfl
  | succ n ih =>
    have one : pi ((s ⋄ k) ⋄ r) = (s ⋄ k) ⋄ pi r := by
      have locked : pi (s ⋄ k) = s ⋄ k := fixed (by simp [hk])
      conv_lhs => rw [pi]
      cases hr : nf r with
      | false => simp [locked]
      | true => simp [hk,root,fixed hr]
    simp only [rounds,one,ih]

theorem checkpoint_off_root {u v u' v' : Term} {n : Nat}
    (hu : nf u = true) (hv : nf v = true) (positive : 0 < n) :
    rounds n (cell u ⋄ cell v) ≠ cell u' ⋄ cell v' := by
  cases n with
  | zero => omega
  | succ n =>
    have mv : nf (cell v) = true := by simp [hv]
    cases n with
    | zero =>
      change pi ((s ⋄ A ⋄ (s ⋄ u)) ⋄ cell v) ≠ _
      rw [pi_redex nf_A (by simp [hu]) mv]
      simp [cell,A,B]
    | succ n =>
      rw [show n+1+1 = 2+n by omega,rounds_add,cell_rounds hu mv]
      rw [sheltered _ _ (by simp [hu,hv])]
      simp [cell,A,B]

theorem nonempty_track {Q Γ : Type} (e : Encoding Q Γ) (h h' : Heap Q Γ)
    {n p} (positive : 0 < n) (tr : Track n p (e.checkpoint h) (e.checkpoint h')) :
    p ≠ [] := by
  rintro rfl
  have bad := tr.located
  rw [Reaches, DirectMemory.Decode.at_nil] at bad
  exact checkpoint_off_root (Encoding.nf_encode e _) (Encoding.nf_encode e _) positive
    (Option.some.inj bad)

/-- The same branch and times witness all three assertions: each next address
strictly extends the last, denotes the real canonical S checkpoint, and is
selected exactly once for each source instruction, in source order. -/
theorem strict_ancestry {Q Γ : Type} [DecidableEq Q] [DecidableEq Γ]
    (tags : Tags Q Γ) (M : Machine Q Γ) (blank : Γ) (c : Tape Q Γ) :
    ∃ (duration : Nat → Nat) (branch : Nat → List Bool),
      (∀ i, 0 < duration i) ∧
      (∀ i, time duration i < time duration (i+1)) ∧
      (∀ i, (location branch i).length < (location branch (i+1)).length) ∧
      (∀ i, Track (duration i) (branch i) (point tags M blank c i) (point tags M blank c (i+1))) ∧
      (∀ i, atPath (rounds (time duration i) (seed tags M blank c)) (location branch i) =
        some (point tags M blank c i)) ∧
      (∀ i k, k < duration i → select tags (rounds (time duration i+k) (seed tags M blank c)) =
        (if k=0 then some (location branch i) else none)) ∧
      ∀ i k, k < duration i → readSnapshot tags (rounds (time duration i+k) (seed tags M blank c)) =
        (if k=0 then some (clock (next M blank) i c) else none) := by
  obtain ⟨d,b,pos,times,track,physical,whereAt,value⟩ := all_snapshots tags M blank c
  refine ⟨d,b,pos,times,?_,track,physical,whereAt,value⟩
  intro i
  have ne := nonempty_track (Compiled.encoding tags (optional M) blank)
    (history M blank c i) (history M blank c (i+1)) (pos i) (track i)
  have longer := List.length_pos_iff.mpr ne
  simp only [location,List.length_append]
  omega

end DirectNesting
#print axioms DirectNesting.strict_ancestry
