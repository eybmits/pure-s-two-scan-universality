import DirectS
import DirectMemory

/-! Exact ground-S representation of the descriptor memory, and native
navigation down its library pointers and indirect tails. -/
namespace DirectMemory
open TwoScans TwoScans.Term TwoScans.Frames DirectS
local infixl:65 " ⋄ " => Term.app
variable {Q Γ : Type}

structure Encoding (Q Γ : Type) where
  marker : Desc.Tag Q Γ → Term
  marker_normal : ∀ t, nf (marker t) = true
  table : Term
  table_normal : nf table = true

namespace Encoding

def zeroRaw (e : Encoding Q Γ) := descriptor (e.marker (Desc.zero : Desc Q Γ).tag) s
def library (e : Encoding Q Γ) := pair e.table (cell e.zeroRaw)
abbrev environment := DirectS.env

/-- Each initial list tail occurs exactly once in its descriptor. Allocated
cells carry the literal environment assembled by the S macros. -/
def encode (e : Encoding Q Γ) : Desc Q Γ → Term
  | .zero => e.zeroRaw
  | w@(.baseEmpty _) => descriptor (e.marker w.tag) (pair e.library (cell e.zeroRaw))
  | w@(.base _ _ t) => descriptor (e.marker w.tag) (pair e.library (cell (e.encode t)))
  | w@(.grown _ _ _ u v) => descriptor (e.marker w.tag) (environment (e.encode u) (e.encode v))

@[simp] theorem nf_zeroRaw (e : Encoding Q Γ) : nf e.zeroRaw = true := by
  simp [zeroRaw, e.marker_normal]
@[simp] theorem nf_library (e : Encoding Q Γ) : nf e.library = true := by
  simp [library, e.table_normal]
@[simp] theorem nf_environment {u v : Term} (hu : nf u = true) (hv : nf v = true) :
    nf (environment u v) = true := by simp [environment, hu, hv]
@[simp] theorem nf_encode (e : Encoding Q Γ) (u : Desc Q Γ) : nf (e.encode u) = true := by
  induction u <;> simp [encode, e.marker_normal, *]

def checkpoint (e : Encoding Q Γ) (h : Heap Q Γ) :=
  cell (e.encode h.focus) ⋄ cell (e.encode h.opposite)

/-- The selected child is required to be a subterm of the actual parallel
orbit at the concatenated path. -/
def Native (a b : Term) : Prop := ∃ n p, Track n p a b

theorem Native.of_track {n p t u} (h : Track n p t u) : Native t u := ⟨_, _, h⟩
theorem Native.trans {t u v} (ha : Native t u) (hb : Native u v) : Native t v := by
  obtain ⟨_, _, h1⟩ := ha
  obtain ⟨_, _, h2⟩ := hb
  exact .of_track (h1.comp h2)

private theorem payload {k h x} (hk : nf k = true) (hh : nf h = true)
    (hx : nf x = true) : Native (descriptor k h ⋄ x) (h ⋄ x) :=
  .of_track (pair_right (by simp [hk]) hh hx)

private theorem leftP {a b x} (ha : nf a = true) (hb : nf b = true) (hx : nf x = true) :
    Native (pair a b ⋄ x) (a ⋄ x) := .of_track (pair_left ha hb hx)

private theorem rightP {a b x} (ha : nf a = true) (hb : nf b = true) (hx : nf x = true) :
    Native (pair a b ⋄ x) (b ⋄ x) := .of_track (pair_right ha hb hx)

theorem env_focus {u v x} (hu : nf u = true) (hv : nf v = true) (hx : nf x = true) :
    Native (environment u v ⋄ x) (u ⋄ x) := by
  apply Native.trans (rightP hv (by simp [hu,hv]) hx)
  apply Native.trans (rightP hv (by simp [hu,hv]) hx)
  exact leftP hu (by simp [hv]) hx

theorem env_opposite {u v x} (hu : nf u = true) (hv : nf v = true) (hx : nf x = true) :
    Native (environment u v ⋄ x) (cell v ⋄ x) := by
  apply Native.trans (rightP hv (by simp [hu,hv]) hx)
  apply Native.trans (rightP hv (by simp [hu,hv]) hx)
  exact rightP hu (by simp [hv]) hx

theorem env_previous {u v x} (hu : nf u = true) (hv : nf v = true) (hx : nf x = true) :
    Native (environment u v ⋄ x) (v ⋄ x) := leftP hv (by simp [hu,hv]) hx

/-- Following old opposite links reaches the physical library, preserving
the argument on every field access. -/
theorem library_access (e : Encoding Q Γ) (v : Desc Q Γ) {x}
    (hx : nf x = true) (lib : v.hasLibrary = true) :
    Native (e.encode v ⋄ x) (e.library ⋄ x) := by
  induction v with
  | zero => contradiction
  | baseEmpty s =>
    apply Native.trans (payload (e.marker_normal _) (by simp) hx)
    exact leftP (nf_library _) (by simp) hx
  | base s c t ih =>
    apply Native.trans (payload (e.marker_normal _) (by simp) hx)
    exact leftP (nf_library _) (by simp) hx
  | grown b s c u v hu hv =>
    apply Native.trans (payload (e.marker_normal _) (by simp) hx)
    exact (env_previous (nf_encode _ _) (nf_encode _ _) hx).trans (hv lib)

/-- Indirect pops through any finite chain of reversal cells preserve x.
The emptiness bit is local. The nonempty branch returns the actual tail value. -/
theorem tail_nonempty (e : Encoding Q Γ) (u : Desc Q Γ) {x}
    (hx : nf x = true) (nonempty : u.tailEmpty = false) :
    Native (e.encode u ⋄ x) (cell (e.encode u.tail) ⋄ x) := by
  induction u with
  | zero | baseEmpty => contradiction
  | base s c t ih =>
    have ht : t.empty = false := nonempty
    simp only [Desc.tail, Desc.canonical, ht, Bool.false_eq_true, ↓reduceIte]
    apply Native.trans (payload (e.marker_normal _) (by simp) hx)
    exact rightP (nf_library _) (by simp) hx
  | grown b s c u v hu hv =>
    cases b with
    | false =>
      have ht : v.empty = false := nonempty
      simp only [Desc.tail, Desc.canonical, ht, Bool.false_eq_true, ↓reduceIte]
      apply Native.trans (payload (e.marker_normal _) (by simp) hx)
      exact env_opposite (nf_encode _ _) (nf_encode _ _) hx
    | true =>
      apply Native.trans (payload (e.marker_normal _) (by simp) hx)
      exact (env_focus (nf_encode _ _) (nf_encode _ _) hx).trans (hu nonempty)

/-- A reversal returns the current opposite stack. A straight move either
returns the actual tail or invokes the sentinel physically stored in the library. -/
theorem next_focus (e : Encoding Q Γ) (u v : Desc Q Γ) (turn : Bool) {x}
    (hx : nf x = true) (lib : v.hasLibrary = true) :
    Native (environment (e.encode u) (e.encode v) ⋄ x)
      (cell (e.encode (if turn then v else u.tail)) ⋄ x) := by
  cases turn with
  | true => exact env_opposite (nf_encode _ _) (nf_encode _ _) hx
  | false =>
    cases endbit : u.tailEmpty with
    | false => exact (env_focus (nf_encode _ _) (nf_encode _ _) hx).trans (tail_nonempty e u hx endbit)
    | true =>
      rw [Desc.tail_eq_zero endbit]
      exact (env_previous (nf_encode _ _) (nf_encode _ _) hx).trans
        ((library_access e v hx lib).trans (rightP e.table_normal (by simp) hx))

/-- This prefix includes positive time. The remaining reductions are concatenated
within its selected child, so the next checkpoint is physically descended from this one. -/
theorem step_given_leaf (e : Encoding Q Γ) (u v : Desc Q Γ) (turn : Bool)
    (s : Mark Q) (c : Γ) (lib : v.hasLibrary = true)
    (entry : let key := e.marker (Desc.grown turn s c u v).tag
      let h := environment (e.encode u) (e.encode v)
      Native (e.table ⋄ h) (install key ⋄ h)) :
    ∃ n p, 0 < n ∧ Track n p (e.checkpoint ⟨u,v⟩)
      (e.checkpoint (Heap.advance ⟨u,v⟩ turn s c)) := by
  let h := environment (e.encode u) (e.encode v)
  let k := e.marker (Desc.grown turn s c u v).tag
  let newCell := cell (descriptor k h)
  have hh : nf h = true := nf_environment (nf_encode _ _) (nf_encode _ _)
  have hk : nf k = true := e.marker_normal _
  have he := checkpoint_to_descriptor (nf_encode e u) (nf_encode e v)
  have toTable : Native (e.encode v ⋄ h) (e.table ⋄ h) :=
    (library_access e v hh lib).trans (leftP e.table_normal (by simp) hh)
  have make := Native.of_track (install_reaches hk hh)
  have cont := next_focus e u v turn (x:=newCell) (by simp [newCell,hk,hh]) lib
  obtain ⟨j,p,r⟩ := ((toTable.trans entry).trans make).trans cont
  exact ⟨8+j,_,by omega,he.comp r⟩

end Encoding

/-- An explicitly enumerated finite alphabet; duplicates do not affect decoding. -/
structure Alphabet (α : Type) where
  items : List α
  cover : ∀ a, a ∈ items

namespace Alphabet
def bools : Alphabet Bool := ⟨[false,true], by intro a; cases a <;> simp⟩
def kinds : Alphabet Kind := ⟨[.zero,.baseEmpty,.base,.straight,.turn], by intro a; cases a <;> simp⟩
def option (a : Alphabet α) : Alphabet (Option α) :=
  ⟨none :: a.items.map some, by intro v; cases v <;> simp [a.cover]⟩

def prod (a : Alphabet α) (b : Alphabet β) : Alphabet (α × β) :=
  ⟨a.items.flatMap (fun i => b.items.map (fun j => (i,j))), by
    rintro ⟨i,j⟩
    exact List.mem_flatMap.mpr ⟨i,a.cover i,List.mem_map.mpr ⟨j,b.cover j,rfl⟩⟩⟩

def project (a : Alphabet α) (f : α → β) (g : β → α) (h : ∀ y, f (g y) = y) : Alphabet β :=
  ⟨a.items.map f, fun y => List.mem_map.mpr ⟨g y,a.cover _,h y⟩⟩

def tags (q : Alphabet Q) (a : Alphabet Γ) : Alphabet (Desc.Tag Q Γ) :=
  let marks := (q.prod bools).project (fun x => Mark.mk x.1 x.2)
    (fun x => (x.state,x.rightward)) (fun _ => rfl)
  let raw := kinds.prod (marks.option.prod (a.option.prod bools))
  raw.project (fun x => ⟨x.1,x.2.1,x.2.2.1,x.2.2.2⟩)
    (fun x => (x.k,x.control,x.head,x.endAfter)) (fun _ => rfl)
end Alphabet

namespace Compiled
open Encoding
variable [DecidableEq Q] [DecidableEq Γ]

def markerNat : Nat → Term
  | 0 => s
  | n+1 => s ⋄ markerNat n

@[simp] theorem marker_normal (n) : nf (markerNat n) = true := by
  induction n <;> simp [markerNat, *]

theorem marker_injective {i j} (h : markerNat i = markerNat j) : i = j := by
  induction i generalizing j with
  | zero => cases j <;> simp_all [markerNat]
  | succ n ih =>
    cases j with
    | zero => simp [markerNat] at h
    | succ j => exact congrArg Nat.succ (ih (Term.app.inj h).2)

def marker (tags : Alphabet (Desc.Tag Q Γ)) (k : Desc.Tag Q Γ) :=
  markerNat (tags.items.idxOf k)

private theorem idx_inj [DecidableEq α] (ls : List α) {a b : α}
    (ha : a ∈ ls) (hb : b ∈ ls) (eq : ls.idxOf a = ls.idxOf b) : a = b := by
  induction ls with
  | nil => contradiction
  | cons z ls ih =>
    by_cases hza : z = a <;> by_cases hzb : z = b
    · exact hza.symm.trans hzb
    · subst a; simp [List.idxOf_cons, hzb] at eq
    · subst b; simp [List.idxOf_cons, hza] at eq
    · apply ih (List.mem_of_ne_of_mem (Ne.symm hza) ha) (List.mem_of_ne_of_mem (Ne.symm hzb) hb)
      simpa [List.idxOf_cons, Ne.symm hza, Ne.symm hzb, hza, hzb] using eq

theorem marker_unique (tags : Alphabet (Desc.Tag Q Γ)) {a b} (eq : marker tags a = marker tags b) :
    a = b := idx_inj tags.items (tags.cover a) (tags.cover b) (marker_injective eq)

abbrev Key (Q Γ : Type) := Desc.Tag Q Γ × Desc.Tag Q Γ

/-- The interpreter table stores its instruction in the S term at each key.
The reader only follows the input key in this finite address space. -/
def resultTag (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ)
    (k : Key Q Γ) : Desc.Tag Q Γ :=
  ((do
    let control ← k.2.control
    let i ← δ control.state (k.1.head.getD blank)
    pure (Desc.newTag (i.moveRight != control.rightward) ⟨i.nextState,i.moveRight⟩ i.write k.1 k.2)
      : Option (Desc.Tag Q Γ))).getD (Desc.zero : Desc Q Γ).tag

def directory {α : Type} (leaf : α → Term) : List α → Term
  | [] => s
  | k :: ks => pair (leaf k) (directory leaf ks)

theorem directory_normal {α : Type} (leaf : α → Term) (hl : ∀ k, nf (leaf k) = true)
    (ks : List α) : nf (directory leaf ks) = true := by
  induction ks <;> simp [directory, *]

/-- Structural table address: skip one pair to the right per preceding key,
then take the left child. No simulated transition is consulted to choose it. -/
def address {α : Type} [DecidableEq α] (k : α) : List α → List Bool
  | [] => []
  | z :: zs => if k = z then [false] else true :: address k zs

theorem directory_hit {α : Type} [DecidableEq α] (leaf : α → Term) (hl : ∀ k, nf (leaf k) = true)
    (k : α) (ks : List α) (mem : k ∈ ks) {x : Term} (hx : nf x = true) :
    Track (address k ks).length (address k ks) (directory leaf ks ⋄ x) (leaf k ⋄ x) := by
  induction ks with
  | nil => contradiction
  | cons a ks ih =>
    by_cases same : k = a
    · subst a
      simpa [address, directory] using pair_left (hl k) (directory_normal _ hl ks) hx
    · have rest := List.mem_of_ne_of_mem same mem
      simpa [address, directory, same,Nat.add_comm] using
        (pair_right (hl a) (directory_normal _ hl ks) hx).comp (ih rest)

def encoding (tags : Alphabet (Desc.Tag Q Γ)) (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ) :
    Encoding Q Γ where
  marker := marker tags
  marker_normal k := marker_normal _
  table := directory (fun k => install (marker tags (resultTag δ blank k))) (tags.prod tags).items
  table_normal := directory_normal _ (by intro k; simp [install,marker]) _

theorem step (tags : Alphabet (Desc.Tag Q Γ)) (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ)
    (h h' : Heap Q Γ) (lib : h.opposite.hasLibrary = true)
    (moved : Heap.machineStep δ blank h = some h') :
    let e := encoding tags δ blank
    ∃ n p, 0 < n ∧ Track n p (e.checkpoint h) (e.checkpoint h') := by
  have cm : ∃ m, h.opposite.mark = some m := by
    cases hm : h.opposite.mark with
    | none => simp [Heap.machineStep, hm] at moved
    | some m => exact ⟨m,rfl⟩
  obtain ⟨m,hm⟩ := cm
  cases go : δ m.state (h.focus.top.getD blank) with
  | none => simp [Heap.machineStep, hm, go] at moved
  | some i =>
    have hp : Heap.advance h (i.moveRight != m.rightward) ⟨i.nextState,i.moveRight⟩ i.write = h' := by
      simpa [Heap.machineStep,hm,go] using moved
    subst h'
    apply step_given_leaf _ h.focus h.opposite _ _ _ lib
    let k := (h.focus.tag, h.opposite.tag)
    have target : resultTag δ blank k = (Desc.grown (i.moveRight != m.rightward)
        ⟨i.nextState,i.moveRight⟩ i.write h.focus h.opposite).tag := by
      rw [Desc.tag_grown]
      simp [resultTag,k,Desc.tag,hm,go]
    have path := directory_hit
      (fun j => install (marker tags (resultTag δ blank j)))
      (by intro j; simp [install,marker]) k (tags.prod tags).items ((tags.prod tags).cover _)
      (x:=environment ((encoding tags δ blank).encode h.focus) ((encoding tags δ blank).encode h.opposite))
      (nf_environment (nf_encode _ _) (nf_encode _ _))
    rw [target] at path
    exact Native.of_track path

@[simp] theorem markerNat_size (n : Nat) : size (markerNat n) = n+1 := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [markerNat, size, ih]; omega

theorem marker_bound (tags : Alphabet (Desc.Tag Q Γ)) (k : Desc.Tag Q Γ) :
    size (marker tags k) ≤ tags.items.length := by
  have lt := List.idxOf_lt_length_of_mem (tags.cover k)
  simp only [marker, markerNat_size]
  omega

private theorem szpair (a b : Term) : size (pair a b) = 1 + size a + size b := rfl
private theorem szcell (a : Term) : size (cell a) = 3 + (1 + size a) := rfl
private theorem szdesc (k h : Term) : size (descriptor k h) = 1 + (1 + size k) + size h := rfl

theorem initial_list_size (e : Encoding Q Γ) (k : Nat)
    (bound : ∀ t, size (e.marker t) ≤ k) (s : Mark Q) (xs : List Γ) :
    let c := 7 + k + size e.library
    size (e.encode (Desc.initial s xs)) ≤ c * (xs.length+1) + size e.zeroRaw := by
  induction xs with
  | nil =>
    have hk := bound (Desc.baseEmpty s).tag
    simp only [Desc.initial, encode, szdesc, szpair, szcell, List.length_nil, Nat.zero_add, Nat.mul_one]
    omega
  | cons x xs ih =>
    have hk := bound (Desc.base s x (Desc.initial s xs)).tag
    simp only [Desc.initial, encode, szdesc, szpair, szcell, List.length_cons, Nat.mul_succ]
    dsimp only at ih
    rw [Nat.mul_succ] at ih
    omega

theorem seed_linear_size (tags : Alphabet (Desc.Tag Q Γ)) (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ) :
    let e := encoding tags δ blank
    ∃ a b, ∀ t : Tape Q Γ, size (e.checkpoint (Heap.initial t)) ≤
      a + b*(t.focus.length + t.opposite.length) := by
  let e := encoding tags δ blank
  let b := 7 + tags.items.length + size e.library
  refine ⟨8 + 2*b + 2*size e.zeroRaw,b,?_⟩
  intro t
  have one := initial_list_size e tags.items.length (marker_bound _) t.control t.focus
  have two := initial_list_size e tags.items.length (marker_bound _) t.control t.opposite
  change size (cell (e.encode (Desc.initial t.control t.focus)) ⋄
      cell (e.encode (Desc.initial t.control t.opposite))) ≤ _
  simp only [size,szcell,Nat.mul_add]
  change size _ ≤ b*(t.focus.length+1)+size e.zeroRaw at one
  change size _ ≤ b*(t.opposite.length+1)+size e.zeroRaw at two
  rw [Nat.mul_succ] at one two
  omega

/-- A stepwise witness from the origin: includes the data configuration, the
time, its address, and a protected path through all preceding native rounds. -/
structure Waypoint (e : Encoding Q Γ) (seed : Term) (t : Tape Q Γ) where
  heap : Heap Q Γ
  correct : heap.Represents t
  time : Nat
  path : List Bool
  native : Track time path seed (e.checkpoint heap)

def startPoint (e : Encoding Q Γ) (t : Tape Q Γ) :
    Waypoint e (e.checkpoint (Heap.initial t)) t :=
  ⟨_,Heap.represents_initial t,0,[], Track.refl _⟩

theorem step_lift (tags : Alphabet (Desc.Tag Q Γ)) (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ)
    {t t' : Tape Q Γ} {h : Heap Q Γ} (rep : h.Represents t) (moved : Heap.tapeStep δ blank t = some t') :
    ∃ h' n p, h'.Represents t' ∧ 0 < n ∧
      Track n p ((encoding tags δ blank).checkpoint h) ((encoding tags δ blank).checkpoint h') := by
  have hrel := Heap.machine_step_correct δ blank rep
  rw [moved] at hrel
  cases hh : Heap.machineStep δ blank h with
  | none => simp [hh, Heap.Related] at hrel
  | some h' =>
    obtain ⟨n,p,hn,hp⟩ := step tags δ blank h h' rep.2.1 hh
    exact ⟨h',n,p,by simpa [hh,Heap.Related] using hrel, hn,hp⟩

/-- A total run convention only for the index: after the first halt the
last source configuration and native checkpoint are reused. -/
def sourceAt (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ) (t : Tape Q Γ) : Nat → Tape Q Γ
  | 0 => t
  | i+1 => let old := sourceAt δ blank t i
           (Heap.tapeStep δ blank old).getD old

structure Stride {e : Encoding Q Γ} {seed : Term} {t t' : Tape Q Γ}
    (p : Waypoint e seed t) (q : Waypoint e seed t') : Prop where
  middle : ∃ k addr, 0 < k ∧ q.time = p.time + k ∧ q.path = p.path ++ addr ∧
    Track k addr (e.checkpoint p.heap) (e.checkpoint q.heap)

theorem waypoint_extend (tags : Alphabet (Desc.Tag Q Γ)) (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ)
    {seed : Term} {t t' : Tape Q Γ} (p : Waypoint (encoding tags δ blank) seed t)
    (live : Heap.tapeStep δ blank t = some t') :
    ∃ q : Waypoint (encoding tags δ blank) seed t', Stride p q := by
  obtain ⟨h,k,addr,hh,hk,tr⟩ := step_lift tags δ blank p.correct live
  exact ⟨⟨h,hh,p.time+k,p.path++addr,p.native.comp tr⟩,⟨k,addr,hk,rfl,rfl,tr⟩⟩

/-- One coherent sequence of nested checkpoints for all steps of an arbitrary
finite-table machine. Times strictly increase on each actual transition. -/
theorem nested_trajectory (tags : Alphabet (Desc.Tag Q Γ)) (δ : Q → Γ → Option (Instruction Q Γ))
    (blank : Γ) (t : Tape Q Γ) :
    let e := encoding tags δ blank
    let origin := e.checkpoint (Heap.initial t)
    let cfg := sourceAt δ blank t
    ∃ q : ∀ i, Waypoint e origin (cfg i),
      (q 0).time = 0 ∧ (q 0).path = [] ∧
      ∀ i, (Heap.tapeStep δ blank (cfg i)).isSome → Stride (q i) (q (i+1)) := by
  let e := encoding tags δ blank
  let origin := e.checkpoint (Heap.initial t)
  let cfg := sourceAt δ blank t
  let next (i : Nat) (p : Waypoint e origin (cfg i)) :
      ∃ q : Waypoint e origin (cfg (i+1)), (Heap.tapeStep δ blank (cfg i)).isSome → Stride p q := by
    cases h : Heap.tapeStep δ blank (cfg i) with
    | none =>
      have eq : cfg (i+1) = cfg i := by change (Heap.tapeStep δ blank (cfg i)).getD (cfg i) = _; simp [h]
      exact ⟨eq.symm ▸ p, by simp⟩
    | some u =>
      have eq : cfg (i+1) = u := by change (Heap.tapeStep δ blank (cfg i)).getD (cfg i) = _; simp [h]
      have h' : Heap.tapeStep δ blank (cfg i) = some (cfg (i+1)) := eq ▸ h
      obtain ⟨q,hq⟩ := waypoint_extend tags δ blank p h'
      exact ⟨q,fun _ => hq⟩
  let q (i : Nat) : Waypoint e origin (cfg i) :=
    Nat.rec (motive:=fun j => Waypoint e origin (cfg j)) (startPoint e t)
      (fun j p => Classical.choose (next j p)) i
  exact ⟨q, rfl, rfl, fun i => Classical.choose_spec (next i (q i))⟩

end Compiled
end DirectMemory
