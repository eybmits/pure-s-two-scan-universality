import ShellAutomata
import DirectS

/-! Deterministic root-to-node readers with finite-state lookahead, on the
actual ground S syntax. The finite-state construction is for the marked
node as well as the domain of the reader on unmarked trees. -/
namespace DirectReader
open TwoScans TwoScans.Automata TwoScans.Frames
open TwoScans.Term

inductive Move (Q : Type) where
  | wait | report | left (next : Q) | right (next : Q)
  deriving DecidableEq

structure Reader (Q H : Type) where
  summary : Fold H
  leaf : Q → Bool
  fork : H → H → Q → Move Q

def Reader.select {Q H : Type} (r : Reader Q H) : Term → Q → Option (List Bool)
  | .s, q => if r.leaf q then some [] else none
  | .app l t, q =>
    match r.fork (r.summary.run l) (r.summary.run t) q with
    | .wait => none
    | .report => some []
    | .left k => (r.select l k).map (false :: ·)
    | .right k => (r.select t k).map (true :: ·)

inductive Marked where
  | leaf (marked : Bool)
  | fork (marked : Bool) (left right : Marked)
  deriving DecidableEq

def Marked.erase : Marked → Term
  | .leaf _ => .s
  | .fork _ l t => .app l.erase t.erase

def Marked.atPath : Marked → List Bool → Bool
  | .leaf b, [] | .fork b _ _, [] => b
  | .leaf _, _ :: _ => false
  | .fork _ l _, false :: p => l.atPath p
  | .fork _ _ t, true :: p => t.atPath p

def Marked.allOn : Term → Marked
  | .s => .leaf true
  | .app l t => .fork true (allOn l) (allOn t)

structure MarkFold (V : Type) where
  leaf : Bool → V
  fork : Bool → V → V → V

def MarkFold.run {V : Type} (a : MarkFold V) : Marked → V
  | .leaf m => a.leaf m
  | .fork m l t => a.fork m (a.run l) (a.run t)

def MarkRegular (P : Marked → Prop) : Prop :=
  ∃ (V : Type) (_ : FinStates V) (a : MarkFold V) (f : V → Bool),
    ∀ t, f (a.run t) = true ↔ P t

def Reader.compile {Q H : Type} (r : Reader Q H) : MarkFold (H × (Q → Bool)) where
  leaf b := (r.summary.leaf, fun q => r.leaf q && b)
  fork b l t := (r.summary.fork l.1 t.1, fun q =>
    match r.fork l.1 t.1 q with
    | .wait => false
    | .report => b
    | .left k => l.2 k
    | .right k => t.2 k)

theorem compiled_summary {Q H} (r : Reader Q H) (t : Marked) :
    (r.compile.run t).1 = r.summary.run t.erase := by
  induction t with
  | leaf b => rfl
  | fork b l t il it => change r.summary.fork _ _ = r.summary.fork _ _; rw [il,it]

theorem compiled_selection {Q H} (r : Reader Q H) (t : Marked) (q : Q) :
    (r.compile.run t).2 q = (r.select t.erase q).any t.atPath := by
  induction t generalizing q with
  | leaf b =>
    cases h : r.leaf q <;> simp [MarkFold.run,Reader.compile,Reader.select,Marked.erase,h,Marked.atPath]
  | fork b l t il it =>
    change (match r.fork (r.compile.run l).1 (r.compile.run t).1 q with
      | .wait => false | .report => b | .left k => (r.compile.run l).2 k
      | .right k => (r.compile.run t).2 k) = _
    rw [compiled_summary,compiled_summary]
    cases h : r.fork (r.summary.run l.erase) (r.summary.run t.erase) q with
    | wait => simp [Marked.erase,Reader.select,h]
    | report => simp [Marked.erase,Reader.select,h,Marked.atPath]
    | left k =>
      change (r.compile.run l).2 k = _
      rw [il k]
      simp only [Marked.erase,Reader.select,h]
      cases r.select l.erase k <;> rfl
    | right k =>
      change (r.compile.run t).2 k = _
      rw [it k]
      simp only [Marked.erase,Reader.select,h]
      cases r.select t.erase k <;> rfl

/-- On a singly marked tree this tests whether its marked node is the
unique selected address. Multi-marked trees test membership in the marked set. -/
theorem regular_marked_selection {Q H} [DecidableEq Q] [FinStates Q] [FinStates H]
    (r : Reader Q H) (q : Q) :
    MarkRegular (fun t => (r.select t.erase q).any t.atPath = true) := by
  exact ⟨_,inferInstance,r.compile,(fun p => p.2 q),fun t => by simp only [compiled_selection]⟩

def Reader.domainFold {Q H} (r : Reader Q H) : Fold (H × (Q → Bool)) where
  leaf := r.compile.leaf true
  fork := r.compile.fork true

theorem compiled_domain {Q H} (r : Reader Q H) (t : Term) (q : Q) :
    (r.domainFold.run t).2 q = (r.select t q).isSome := by
  have fst : ∀ u, (r.domainFold.run u).1 = r.summary.run u := by
    intro u
    induction u with
    | s => rfl
    | app l t il it => change r.summary.fork _ _ = r.summary.fork _ _; rw [il,it]
  induction t generalizing q with
  | s => cases h : r.leaf q <;> simp [Reader.domainFold,Fold.run,Reader.compile,Reader.select,h]
  | app l t il it =>
    change (match r.fork (r.domainFold.run l).1 (r.domainFold.run t).1 q with
      | .wait => false | .report => true | .left k => (r.domainFold.run l).2 k
      | .right k => (r.domainFold.run t).2 k) = _
    rw [fst,fst]
    cases h : r.fork (r.summary.run l) (r.summary.run t) q with
    | wait => simp [Reader.select,h]
    | report => simp [Reader.select,h]
    | left k => simp [Reader.select,h,il]
    | right k => simp [Reader.select,h,it]

theorem regular_domain {Q H} [DecidableEq Q] [FinStates Q] [FinStates H]
    (r : Reader Q H) (q : Q) :
    Regular (fun t => (r.select t q).isSome = true) := by
  exact ⟨_,inferInstance,r.domainFold,(fun p => p.2 q),fun t => by simp only [compiled_domain]⟩

open DirectS
local infixl:65 " ·ₛ " => Term.app
def frame (right : Bool) (a sibling : Term) : Term :=
  if right then sibling ·ₛ a else a ·ₛ sibling

def ready (side : Bool) : Term → Bool
  | .s => false
  | .app l r => !(nf (if side then r else l))

/-- A retired branch is frozen at its parent for every future round as long
as the selected child has another contraction. Neither the sibling's normality
nor agreement between copies is required. -/
theorem rounds_frame {a sibling : Term} (b : Bool) {k}
    (active : ∀ j < k, nf (rounds j a) = false) :
    rounds k (frame b a sibling) = frame b (rounds k a) (rounds k sibling) := by
  induction k generalizing a sibling with
  | zero => rfl
  | succ k ih =>
    have na := active 0 (by omega)
    change nf a = false at na
    have one : pi (frame b a sibling) = frame b (pi a) (pi sibling) := by
      cases b <;> simp [frame,pi,na]
    simp only [rounds,one]
    exact ih (fun j hj => active (j+1) (by omega))

@[simp] theorem ready_frame (b) (a sibling) : ready b (frame b a sibling) = !(nf a) := by
  cases b <;> rfl

structure Gate (n : Nat) (side : Bool) (entry focus sibling : Term) : Prop where
  closed : ∀ k < n, ready side (rounds k entry) = false
  fired : rounds n entry = frame side focus sibling

theorem Gate.persistent {n b e a sibling} (g : Gate n b e a sibling) {k}
    (active : ∀ j ≤ k, nf (rounds j a) = false) :
    rounds (n+k) e = frame b (rounds k a) (rounds k sibling) ∧
    ready b (rounds (n+k) e) = true := by
  rw [rounds_add,g.fired,rounds_frame b (fun j hj => active j (by omega)),ready_frame,active k (by omega)]
  exact ⟨rfl,rfl⟩

theorem pair_gate {a b x : Term} (ha : nf a = true) (hb : nf b = true)
    (hx : nf x = true) (side : Bool) :
    Gate 1 side (pair a b ·ₛ x) ((if side then b else a) ·ₛ x)
      ((if side then a else b) ·ₛ x) := by
  constructor
  · intro k hk; have : k = 0 := by omega
    subst k; cases side <;> simp [rounds,ready,ha,hb,hx]
  · cases side <;> simpa only [pair,rounds,frame,Bool.false_eq_true,ite_false,ite_true] using pi_redex ha hb hx

theorem cell_gate {u m : Term} (hu : nf u = true) (hm : nf m = true) :
    Gate 2 true (cell u ·ₛ m) (m ·ₛ pair u m) (s ·ₛ pair u m) := by
  constructor
  · intro k hk
    have h : k = 0 ∨ k = 1 := by omega
    rcases h with rfl | rfl
    · simp [rounds,ready,hm]
    · change ready true (pi (s ·ₛ A ·ₛ (s ·ₛ u) ·ₛ m)) = false
      rw [pi_redex nf_A (by simp [hu]) hm]
      simp [ready,hm,hu]
  · exact cell_rounds hu hm

theorem feed_gate {g k z : Term} (hg : nf g = true) (hk : nf k = true)
    (hz : nf z = true) (hgz : nf (g ·ₛ z) = true) :
    Gate 2 false (feed g k ·ₛ z) (k ·ₛ (g ·ₛ z)) (z ·ₛ (g ·ₛ z)) := by
  constructor
  · intro i hi
    have h : i = 0 ∨ i = 1 := by omega
    rcases h with rfl | rfl
    · simp [rounds,ready,hg,hk]
    · change ready false (pi (s ·ₛ (s ·ₛ k) ·ₛ g ·ₛ z)) = false
      rw [pi_redex (by simp [hk]) hg hz]
      simp [ready,hk,hz]
  · change pi (pi (s ·ₛ (s ·ₛ k) ·ₛ g ·ₛ z)) = _
    rw [pi_redex (by simp [hk]) hg hz]
    exact pi_redex hk hz hgz

/-- In phases zero through three the right child is normal, including the
phases where the *left* child is already active. -/
theorem builder_gate {u : Term} (hu : nf u = true) :
    let x := s ·ₛ u
    let n := B ·ₛ x
    Gate 4 true (builder ·ₛ x) ((x ·ₛ n) ·ₛ n) (n ·ₛ n) := by
  let x := s ·ₛ u
  let n := B ·ₛ x
  have hx : nf x = true := by simp [x,hu]
  have hn : nf n = true := by simp [n,B,hx]
  have b1 := root_step (show nf (pair A B) = true by simp) nf_B hx
  have b2 := root_below_left nf_A nf_B hx hn
  have b3 := root_below_left nf_s hx hn hn
  have stage {j t v} (h : Track j [] t v) : rounds j t = v := by
    simpa [Reaches,atPath] using h.located
  constructor
  · intro i hi
    have casesI : i=0 ∨ i=1 ∨ i=2 ∨ i=3 := by omega
    rcases casesI with rfl | rfl | rfl | rfl
    · change (!(nf x)) = false; rw [hx]; rfl
    · change ready true (rounds 1 (builder ·ₛ x)) = false
      unfold builder; rw [stage b1]; change (!(nf n)) = false; rw [hn]; rfl
    · change ready true (rounds 2 (builder ·ₛ x)) = false
      unfold builder; rw [stage (b1.comp b2)]; change (!(nf n)) = false; rw [hn]; rfl
    · change ready true (rounds 3 (builder ·ₛ x)) = false
      unfold builder; rw [stage ((b1.comp b2).comp b3)]; change (!(nf n)) = false; rw [hn]; rfl
  · exact stage (builder_four hu)

def armed : Term → Bool
  | .app (.app (.app .s a) _) _ => decide (a = A)
  | _ => false

theorem checkpoint_phases {u m} (hu : nf u = true) (hm : nf m = true) :
    armed (cell u ·ₛ m) = true ∧ armed (pi (cell u ·ₛ m)) = false := by
  constructor
  · rfl
  · change armed (pi (s ·ₛ A ·ₛ (s ·ₛ u) ·ₛ m)) = false
    rw [pi_redex nf_A (by simp [hu]) hm]; rfl


#print axioms DirectReader.regular_marked_selection
#print axioms DirectReader.regular_domain
#print axioms DirectReader.Gate.persistent
#print axioms DirectReader.builder_gate

def emitAt (emit : Bool) (k : Nat) : Option (List Bool) :=
  if emit && k == 0 then some [] else none

def descend {Q} (side : Bool) (q : Q) : Move Q :=
  if side then .right q else .left q

/-- Branch mode on the tree at the current location. Its decision can inspect
the summaries of both children. -/
def Reader.moveAt {Q H} (r : Reader Q H) (q : Q) : Term → Move Q
  | s => if r.leaf q then .report else .wait
  | app a b => r.fork (r.summary.run a) (r.summary.run b) q

theorem select_descent {Q H} (r : Reader Q H) {b q k a sib}
    (h : r.moveAt q (frame b a sib) = descend b k) :
    r.select (frame b a sib) q = (r.select a k).map (b :: ·) := by
  cases b <;> simp only [frame,descend,ite_false,ite_true,Bool.false_eq_true,Reader.moveAt] at h ⊢ <;>
    simp [Reader.select,h]

/-- The finite route jumps to the same next mode along a frozen fork for
every future snapshot of the active child. Tags needed for this decision
live in the fixed normal sibling; other forks ignore their sibling. -/
def Locked {Q H} (r : Reader Q H) (side : Bool) (q k : Q) (sib : Term) : Prop :=
  ∀ z i, nf z = false →
    r.moveAt q (frame side z (rounds i sib)) = descend side k

structure Span {Q H} (r : Reader Q H) (emit : Bool)
    (n : Nat) (path : List Bool) (entry : Term) (q : Q) (focus : Term) (k : Q) : Prop where
  positive : n > 0
  track : Track n path entry focus
  before : ∀ i < n, r.select (rounds i entry) q = emitAt emit i
  later : ∀ i, (∀ j ≤ i, nf (rounds j focus) = false) →
    r.select (rounds (n+i) entry) q = (r.select (rounds i focus) k).map (path ++ ·)

theorem span_of_gate {Q H} {r : Reader Q H} {emit n side entry q focus k sib}
    (g : Gate n side entry focus sib) (pos : n > 0)
    (active : ∀ j < n, nf (rounds j entry) = false)
    (silent : ∀ j < n, r.select (rounds j entry) q = emitAt emit j)
    (lock : Locked r side q k sib) :
    Span r emit n [side] entry q focus k := by
  refine ⟨pos,⟨?_,active⟩,silent,?_⟩
  · unfold Reaches
    rw [g.fired]; cases side <;> cases focus <;> rfl
  · intro i hi
    rw [(g.persistent hi).1]
    exact select_descent r (lock _ i (hi _ (by omega)))

theorem track_active_through {n p entry focus} (tr : Track n p entry focus)
    {k : Nat} (active : ∀ j ≤ k, nf (rounds j focus) = false) :
    ∀ i ≤ n+k, nf (rounds i entry) = false := by
  intro i hi
  by_cases earlier : i < n
  · exact tr.before i earlier
  · obtain ⟨j,rfl⟩ := Nat.exists_eq_add_of_le (Nat.le_of_not_lt earlier)
    rw [rounds_add]
    exact inactive_child_impossible
      (rounds_at_active j tr.located (fun l hl => active l (by omega)))
      (active j (by omega))

theorem Span.comp {Q H} {r : Reader Q H} {emit i j p v q a k b m x}
    (first : Span r emit i p a q b k) (next : Span r false j v b k x m) :
    Span r emit (i+j) (p++v) a q x m := by
  refine ⟨by have := first.positive; omega,first.track.comp next.track,?_,?_⟩
  · intro t ht
    by_cases early : t < i
    · exact first.before t early
    · obtain ⟨l,rfl⟩ := Nat.exists_eq_add_of_le (Nat.le_of_not_lt early)
      have hl : l < j := by omega
      rw [first.later l (fun s hs => next.track.before s (by omega)),next.before l hl]
      have hpos := first.positive
      simp [emitAt, Nat.ne_of_gt hpos]
  · intro t ht
    rw [Nat.add_assoc,first.later (j+t) (track_active_through next.track ht),next.later t ht]
    cases r.select (rounds t x) m <;> simp [List.append_assoc]

end DirectReader
#print axioms DirectReader.Span.comp

namespace DirectReader
open TwoScans TwoScans.Automata TwoScans.Frames
open TwoScans.Term

/-- Constructive certificate that a value is available as a bottom-up
finite-state attribute. The external result type need not be finite. -/
structure Attribute (V : Type) where
  State : Type
  states : FinStates State
  alg : Fold State
  out : State → V

def Attribute.get {V} (a : Attribute V) (t : Term) := a.out (a.alg.run t)

def Attribute.map {V W} (f : V → W) (a : Attribute V) : Attribute W :=
  ⟨a.State,a.states,a.alg,fun s => f (a.out s)⟩

def Attribute.both {V W X} (f : V → W → X) (a : Attribute V) (b : Attribute W) : Attribute X :=
  letI := a.states
  letI := b.states
  ⟨a.State × b.State,inferInstance,a.alg.zip b.alg,fun p => f (a.out p.1) (b.out p.2)⟩

@[simp] theorem get_map {V W} (f : V → W) (a : Attribute V) (t) :
    (a.map f).get t = f (a.get t) := rfl

@[simp] theorem get_both {V W X} (f : V → W → X) (a : Attribute V) (b : Attribute W) (t) :
    (a.both f b).get t = f (a.get t) (b.get t) := by
  simp [Attribute.get,Attribute.both,Fold.zip_run]

def Attribute.child (b : Bool) (a : Attribute Bool) : Attribute Bool :=
  letI := a.states
  ⟨a.State × Bool,inferInstance,a.alg.extend false
    (fun l r => a.out (if b then r.1 else l.1)), Prod.snd⟩

@[simp] theorem child_leaf (b) (a : Attribute Bool) : (a.child b).get s = false := rfl

@[simp] theorem child_fork (b) (a : Attribute Bool) (l r) :
    (a.child b).get (app l r) = a.get (if b then r else l) := by
  change a.out (if b then ((a.alg.extend false _).run r).1 else ((a.alg.extend false _).run l).1) = _
  cases b <;> simp [Fold.extend_base,Attribute.get]

inductive Test where
  | leaf | normal | atLeft (t : Test) | atRight (t : Test)
  | and (t u : Test) | not (t : Test)
  deriving DecidableEq

def Test.exact : Term → Test
  | s => .leaf
  | app l r => .and (.atLeft (exact l)) (.atRight (exact r))

def Test.atPath : List Bool → Test → Test
  | [], a => a
  | false :: p, a => .atLeft (atPath p a)
  | true :: p, a => .atRight (atPath p a)

def Test.run : Test → Term → Bool
  | .leaf, s => true
  | .leaf, .app _ _ => false
  | .normal, t => nf t
  | .atLeft t, .app l _ => t.run l
  | .atRight t, .app _ r => t.run r
  | .atLeft _, s | .atRight _, s => false
  | .and t u, x => t.run x && u.run x
  | .not t, x => !(t.run x)

@[simp] theorem exact_spec (pattern t : Term) :
    (Test.exact pattern).run t = decide (t=pattern) := by
  induction pattern generalizing t with
  | s => cases t <;> rfl
  | app l r il ir =>
    cases t with
    | s => rfl
    | app x y => simp [Test.exact,Test.run,il,ir]

theorem tests_path (p : List Bool) (q : Test) (t : Term) :
    (Test.atPath p q).run t = (DirectS.atPath t p).any q.run := by
  induction p generalizing t with
  | nil => cases t <;> rfl
  | cons b p ih => cases b <;> cases t <;> simp [Test.atPath,Test.run,DirectS.atPath,ih]

def headClass : Term → Fin 4
  | s => 0
  | app s _ => 1
  | app (app s _) _ => 2
  | _ => 3

def headNext (h : Fin 4) : Fin 4 :=
  if h = 0 then 1 else if h = 1 then 2 else 3

theorem classify_app (l r : Term) : headClass (app l r) = headNext (headClass l) := by
  cases l with
  | s => rfl
  | app a b => cases a with
    | s => rfl
    | app c d => cases c <;> rfl

theorem rootNone (l r : Term) : (root l r).isNone = decide (headClass l ≠ 2) := by
  cases l with
  | s => rfl
  | app a b => cases a with
    | s => rfl
    | app c d => cases c <;> rfl

def normalFold : Fold (Fin 4 × Bool) :=
  ⟨(0,true),fun l r => (headNext l.1, decide (l.1 ≠ 2) && l.2 && r.2)⟩

theorem normalFold_run (t : Term) : normalFold.run t = (headClass t, nf t) := by
  induction t with
  | s => rfl
  | app l r il ir =>
    change normalFold.fork (normalFold.run l) (normalFold.run r) = _
    rw [il,ir]
    simp [normalFold,classify_app,nf,rootNone]

def Test.compile : Test → Attribute Bool
  | .leaf => ⟨Bool,inferInstance,⟨true,fun _ _ => false⟩,id⟩
  | .normal => ⟨Fin 4 × Bool,inferInstance,normalFold,Prod.snd⟩
  | .atLeft t => t.compile.child false
  | .atRight t => t.compile.child true
  | .and t u => t.compile.both (· && ·) u.compile
  | .not t => t.compile.map Bool.not

theorem compile_spec (b : Test) (t : Term) : b.compile.get t = b.run t := by
  induction b generalizing t with
  | leaf => cases t <;> rfl
  | normal => simp [Test.compile,Test.run,Attribute.get,normalFold_run]
  | atLeft b ih => cases t <;> simp [Test.compile,Test.run,ih]
  | atRight b ih => cases t <;> simp [Test.compile,Test.run,ih]
  | and a b ia ib => simp [Test.compile,Test.run,ia,ib]
  | not a ih => simp [Test.compile,Test.run,ih]

def bundle : List Test → Attribute (List Bool)
  | [] => ⟨Unit,inferInstance,⟨(),fun _ _ => ()⟩,fun _ => []⟩
  | h :: t => h.compile.both List.cons (bundle t)

theorem bundle_spec (ts : List Test) (t : Term) : (bundle ts).get t = ts.map (·.run t) := by
  induction ts with
  | nil => rfl
  | cons h ts ih => simp [bundle,compile_spec,ih]

def compileControl {Q} (tests : List Test) (leaf : Q → Bool)
    (fork : List Bool → List Bool → Q → Move Q) : Reader Q (bundle tests).State :=
  ⟨(bundle tests).alg,leaf,fun l r => fork ((bundle tests).out l) ((bundle tests).out r)⟩

theorem control_fork {Q} (tests) (leaf : Q → Bool) (fork) (q l r) :
    (compileControl tests leaf fork).moveAt q (app l r) =
    fork (tests.map (·.run l)) (tests.map (·.run r)) q := by
  change fork ((bundle tests).get l) ((bundle tests).get r) q = _
  rw [bundle_spec,bundle_spec]

theorem regular_control {Q} [DecidableEq Q] [FinStates Q]
    (tests) (leaf : Q → Bool) (fork) (q : Q) :
    MarkRegular (fun t => ((compileControl tests leaf fork).select t.erase q).any t.atPath = true)
    ∧ Regular (fun t => ((compileControl tests leaf fork).select t q).isSome = true) := by
  letI := (bundle tests).states
  exact ⟨regular_marked_selection _ _,regular_domain _ _⟩

end DirectReader
#print axioms DirectReader.regular_control

namespace DirectReader
open TwoScans TwoScans.Frames DirectS

def time (duration : Nat → Nat) : Nat → Nat
  | 0 => 0
  | i+1 => time duration i + duration i

def location (branch : Nat → List Bool) : Nat → List Bool
  | 0 => []
  | i+1 => location branch i ++ branch i

/-- Liveness of every selected descendant is derived from the next macrostep.
It is not a separate fairness assumption about the reduction strategy. -/
theorem orbit_active {Q H} {r : Reader Q H} {q : Q} {dur : Nat → Nat} {branch : Nat → List Bool} {a : Nat → Term}
    (step : ∀ i, Span r true (dur i) (branch i) (a i) q (a (i+1)) q) (k i) :
    nf (rounds k (a i)) = false := by
  induction k using Nat.strongRecOn generalizing i with
  | ind k ih =>
    by_cases early : k < dur i
    · exact (step i).track.before k early
    · obtain ⟨j,rfl⟩ := Nat.exists_eq_add_of_le (Nat.le_of_not_lt early)
      exact track_active_through (step i).track (k:=j) (fun l hl => ih l (by have := (step i).positive; omega) (i+1))
        (dur i+j) (by omega)

theorem orbit_route {Q H} {r : Reader Q H} {q : Q} {dur : Nat → Nat} {branch : Nat → List Bool} {a : Nat → Term}
    (step : ∀ i, Span r true (dur i) (branch i) (a i) q (a (i+1)) q)
    (i k : Nat) :
    r.select (rounds (time dur i+k) (a 0)) q =
      (r.select (rounds k (a i)) q).map (location branch i ++ ·) := by
  induction i generalizing k with
  | zero => simp [time,location]
  | succ i ih =>
    rw [time,Nat.add_assoc,ih (dur i+k),(step i).later k (fun j _ => orbit_active step j (i+1))]
    cases r.select (rounds k (a (i+1))) q <;> simp [location,List.append_assoc]

theorem orbit_checkpoint {Q H} {r : Reader Q H} {q : Q} {dur : Nat → Nat} {branch : Nat → List Bool} {a : Nat → Term}
    (step : ∀ i, Span r true (dur i) (branch i) (a i) q (a (i+1)) q)
    (i k : Nat) (hk : k < dur i) :
    r.select (rounds (time dur i+k) (a 0)) q =
      if k=0 then some (location branch i) else none := by
  rw [orbit_route step, (step i).before k hk]
  by_cases atStart : k=0 <;> simp [emitAt,atStart]

theorem orbit_physical {Q H} {r : Reader Q H} {q : Q} {dur : Nat → Nat} {branch : Nat → List Bool} {a : Nat → Term}
    (step : ∀ i, Span r true (dur i) (branch i) (a i) q (a (i+1)) q)
    (i k : Nat) :
    atPath (rounds (time dur i+k) (a 0)) (location branch i) = some (rounds k (a i)) := by
  induction i generalizing k with
  | zero =>
    simp only [time,Nat.zero_add,location]
    cases rounds k (a 0) <;> rfl
  | succ i ih =>
    simp only [time,location,Nat.add_assoc]
    apply path_append (ih (dur i+k))
    rw [rounds_add]
    exact rounds_at_active k (step i).track.located (fun j _ => orbit_active step j (i+1))

theorem time_strict {Q H} {r : Reader Q H} {q : Q} {dur : Nat → Nat} {branch : Nat → List Bool} {a : Nat → Term}
    (step : ∀ i, Span r true (dur i) (branch i) (a i) q (a (i+1)) q) (i) :
    time dur i < time dur (i+1) := by
  simp only [time]
  have := (step i).positive
  omega

theorem time_partition {dur : Nat → Nat} (pos : ∀ i, 0 < dur i) (t : Nat) :
    ∃ i k, k < dur i ∧ t = time dur i + k := by
  induction t with
  | zero => exact ⟨0,0,pos 0,rfl⟩
  | succ t ih =>
    obtain ⟨i,k,hk,rfl⟩ := ih
    by_cases advance : k+1 < dur i
    · exact ⟨i,k+1,advance,by omega⟩
    · exact ⟨i+1,0,pos _,by simp only [time,Nat.add_zero]; omega⟩

end DirectReader
#print axioms DirectReader.orbit_checkpoint
#print axioms DirectReader.orbit_physical

namespace DirectReader
open TwoScans TwoScans.Automata DirectS

def annotate (p : Term → Bool) : Term → Marked
  | .s => .leaf (p .s)
  | .app l r => .fork (p (.app l r)) (annotate p l) (annotate p r)

@[simp] theorem annotate_erase (p) (t) : (annotate p t).erase = t := by
  induction t <;> simp [annotate,Marked.erase, *]

theorem annotate_path (p) (t) (path : List Bool) :
    (annotate p t).atPath path = (atPath t path).any p := by
  induction path generalizing t with
  | nil => cases t <;> rfl
  | cons d ps ih => cases d <;> cases t <;> simp [annotate,Marked.atPath,atPath,ih]

def Reader.propertyFold {Q H} (r : Reader Q H) (a : Attribute Bool) :
    Fold (a.State × (H × (Q → Bool))) where
  leaf := (a.alg.leaf,r.compile.leaf (a.out a.alg.leaf))
  fork l t :=
    let node := a.alg.fork l.1 t.1
    (node,r.compile.fork (a.out node) l.2 t.2)

theorem property_run {Q H} (r : Reader Q H) (a : Attribute Bool) (t) :
    (r.propertyFold a).run t = (a.alg.run t, r.compile.run (annotate a.get t)) := by
  induction t with
  | s => rfl
  | app l t il it =>
    change (r.propertyFold a).fork ((r.propertyFold a).run l) ((r.propertyFold a).run t) = _
    rw [il,it]
    rfl

theorem regular_at_selected {Q H} [DecidableEq Q] [FinStates Q] [FinStates H]
    (r : Reader Q H) (q : Q) {P : Term → Prop} (hp : Regular P) :
    Regular (fun t => ∃ p u, r.select t q = some p ∧ atPath t p = some u ∧ P u) := by
  obtain ⟨K,i,alg,pred,correct⟩ := hp
  let a : Attribute Bool := ⟨K,i,alg,pred⟩
  letI := a.states
  refine ⟨_,inferInstance,r.propertyFold a,fun root => root.2.2 q,?_⟩
  intro t
  change ((r.propertyFold a).run t).2.2 q = true ↔ _
  rw [property_run,compiled_selection,annotate_erase]
  cases eq : r.select t q with
  | none => simp [eq]
  | some p =>
    simp only [Option.any_some, annotate_path]
    cases eq' : atPath t p with
    | none => simp [eq,eq']
    | some u => simpa [eq,eq',a,Attribute.get] using correct u

end DirectReader
#print axioms DirectReader.regular_at_selected
