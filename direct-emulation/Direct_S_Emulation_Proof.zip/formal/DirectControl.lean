import DirectMemoryRoute
import DirectReader

/-! Concrete control of the marked-node reader. Every observation is a finite
bottom-up attribute on an arbitrary raw tree; the universal machine transition
function does not appear in the control decisions. -/
namespace DirectControl
open TwoScans TwoScans.Term TwoScans.Automata TwoScans.Frames
open DirectS DirectReader DirectMemory DirectMemory.Compiled
local infixl:65 " ⋄ " => Term.app

inductive Atom (K : Type) where
  | check | lib (target : Option K) | pop | installed (empty : Bool)
  deriving DecidableEq

abbrev State (Q Γ : Type) := List Bool × Atom (Key Q Γ)
abbrev Tags (Q Γ : Type) := Alphabet (Desc.Tag Q Γ)
variable {Q Γ : Type} [DecidableEq Q] [DecidableEq Γ]

def after (tags : Tags Q Γ) (op : Atom (Key Q Γ)) (k : Desc.Tag Q Γ) : State Q Γ :=
  match op with
  | .check => ([],.check)
  | .lib target =>
    match k.k with
    | .base | .baseEmpty =>
      match target with
      | none => ([false,true],.check)
      | some a => ([false,false] ++ address a (tags.prod tags).items ++ [false,false,true,false],
                   .installed a.1.endAfter)
    | _ => ([false],.lib target)
  | .pop =>
    match k.k with
    | .base => ([true],.check)
    | .straight => ([true,true,true],.check)
    | _ => ([true,true,false],.pop)
  | .installed empty =>
    if k.k == .turn then ([true,true,true],.check)
    else if empty then ([false],.lib none) else ([true,true,false],.pop)

def tagPath := [false,true,true]
def markerAfter := [false,true]
def focusKeyPath := [true,false,true] ++ tagPath
def oppKeyPath := [true,true,true,true] ++ tagPath

def lookup (tags : Tags Q Γ) (path : List Bool) :
    List (Desc.Tag Q Γ) → Attribute (Option (Desc.Tag Q Γ))
  | [] => ⟨Unit,inferInstance,⟨(), fun _ _ => ()⟩, fun _ => none⟩
  | k::ks => ((Test.exact (marker tags k)).atPath path).compile.both
       (fun yes rest => if yes then some k else rest) (lookup tags path ks)

theorem lookup_spec (tags : Tags Q Γ) (path : List Bool) (ls : List (Desc.Tag Q Γ))
    (t : Term) (k : Desc.Tag Q Γ) (has : k ∈ ls)
    (hit : atPath t path = some (marker tags k)) :
    (lookup tags path ls).get t = some k := by
  induction ls with
  | nil => contradiction
  | cons a ls ih =>
    simp only [lookup, get_both, compile_spec, tests_path, hit, Option.any_some, exact_spec]
    by_cases eq : a = k
    · subst a; simp
    · have ne : marker tags k ≠ marker tags a := fun h => eq ((marker_unique tags h).symm)
      simp [ne,ih (List.mem_of_ne_of_mem (Ne.symm eq) has)]

structure Header (Q Γ : Type) where
  normal : Bool
  armed : Bool
  label : Option (Desc.Tag Q Γ)
  focus : Option (Desc.Tag Q Γ)
  opposite : Option (Desc.Tag Q Γ)

def summary (tags : Tags Q Γ) : Attribute (Header Q Γ) :=
  let p := (Test.normal.compile).both Prod.mk ((Test.exact A).atPath [false,true]).compile
  let labels := (lookup tags markerAfter tags.items).both Prod.mk
    ((lookup tags focusKeyPath tags.items).both Prod.mk (lookup tags oppKeyPath tags.items))
  p.both (fun a b => ⟨a.1,a.2,b.1,b.2.1,b.2.2⟩) labels

theorem summary_normal (tags : Tags Q Γ) (t) : ((summary tags).get t).normal = nf t := by
  simp [summary,get_both,compile_spec,Test.run]
theorem summary_armed (tags : Tags Q Γ) (t) :
    ((summary tags).get t).armed = (atPath t [false,true]).any (fun u => decide (u=A)) := by
  simp [summary,get_both,compile_spec,tests_path]
  cases atPath t [false,true] <;> simp [exact_spec]
theorem summary_label (tags : Tags Q Γ) (t k)
    (h : atPath t markerAfter = some (marker tags k)) : ((summary tags).get t).label = some k := by
  simp [summary,lookup_spec tags _ _ t k (tags.cover k) h]
theorem summary_focus (tags : Tags Q Γ) (t k)
    (h : atPath t focusKeyPath = some (marker tags k)) : ((summary tags).get t).focus = some k := by
  simp [summary,lookup_spec tags _ _ t k (tags.cover k) h]
theorem summary_opposite (tags : Tags Q Γ) (t k)
    (h : atPath t oppKeyPath = some (marker tags k)) : ((summary tags).get t).opposite = some k := by
  simp [summary,lookup_spec tags _ _ t k (tags.cover k) h]

def checkpointNext (a b : Desc.Tag Q Γ) : State Q Γ :=
  ([true,true,true,false], .lib (some (a,b)))

def control (tags : Tags Q Γ) (l r : Header Q Γ) : State Q Γ → Move (State Q Γ)
  | (side :: rest, op) =>
    if (if side then r else l).normal then .wait else descend side (rest,op)
  | ([],.check) =>
    if r.normal then (if l.armed then .report else .wait)
    else match l.focus, l.opposite with
      | some a, some b => .right (checkpointNext a b)
      | _, _ => .wait
  | ([],op) =>
    if r.normal then .wait else
      match l.label with
      | none => .wait
      | some k => .right (after tags op k)

def reader (tags : Tags Q Γ) : Reader (State Q Γ) (summary tags).State :=
  ⟨(summary tags).alg,fun _ => false,fun l r => control tags ((summary tags).out l) ((summary tags).out r)⟩

theorem move_fork (tags : Tags Q Γ) (l r m) :
    (reader tags).moveAt m (l ⋄ r) = control tags ((summary tags).get l) ((summary tags).get r) m := rfl

theorem go_move (tags : Tags Q Γ) (side : Bool) (p : List Bool) (op : Atom (Key Q Γ))
    (l r : Term) : (reader tags).moveAt (side::p,op) (l ⋄ r) =
    if nf (if side then r else l) then .wait else descend side (p,op) := by
  cases side <;> simp [move_fork,control,summary_normal]

theorem select_wait {M H} (r : Reader M H) {q t} (h : r.moveAt q t = .wait) :
    r.select t q = none := by
  cases t with
  | s => cases hl : r.leaf q <;> simp_all [Reader.select, Reader.moveAt]
  | app l t => simp [Reader.select,Reader.moveAt] at h ⊢; rw [h]

theorem select_report {M H} (r : Reader M H) {q t} (h : r.moveAt q t = .report) :
    r.select t q = some [] := by
  cases t with
  | s => cases hl : r.leaf q <;> simp_all [Reader.select, Reader.moveAt]
  | app l t => simp [Reader.select,Reader.moveAt] at h ⊢; rw [h]

/-- A statically prescribed child is followed exactly when that child is active.
The waiting phase of a pair, cell, builder or feed can have different lengths. -/
theorem go_gate (tags : Tags Q Γ) {e a sibling n side}
    (g : Gate n side e a sibling) (pos : 0<n)
    (active : ∀ j<n, nf (rounds j e) = false)
    (p : List Bool) (op : Atom (Key Q Γ)) :
    Span (reader tags) false n [side] e (side::p,op) a (p,op) := by
  apply span_of_gate g pos active
  · intro j hj
    apply select_wait
    have shut := g.closed j hj
    cases ht : rounds j e with
    | s => rfl
    | app l r =>
      rw [ht] at shut
      simp [ready] at shut
      simp [go_move,shut]
  · intro z i hn
    cases side <;> simp [frame,go_move,hn]

theorem go_pair (tags : Tags Q Γ) {a b x} (ha : nf a=true) (hb : nf b=true)
    (hx : nf x=true) (side : Bool) (p : List Bool) (op : Atom (Key Q Γ)) :
    Span (reader tags) false 1 [side] (pair a b ⋄ x) (side::p,op)
      ((if side then b else a) ⋄ x) (p,op) := by
  exact go_gate tags (pair_gate ha hb hx side) (by decide) (pair_left ha hb hx).before p op

theorem go_cell (tags : Tags Q Γ) {u m} (hu : nf u=true) (hm : nf m=true)
    (p : List Bool) (op : Atom (Key Q Γ)) :
    Span (reader tags) false 2 [true] (cell u ⋄ m) (true::p,op)
      (m ⋄ pair u m) (p,op) :=
  go_gate tags (cell_gate hu hm) (by decide) (cell_right hu hm).before p op

theorem go_feed (tags : Tags Q Γ) {g k z} (hg : nf g=true) (hk : nf k=true)
    (hz : nf z=true) (hgz : nf (g ⋄ z)=true) (p : List Bool) (op : Atom (Key Q Γ)) :
    Span (reader tags) false 2 [false] (feed g k ⋄ z) (false::p,op)
      (k ⋄ (g ⋄ z)) (p,op) :=
  go_gate tags (feed_gate hg hk hz hgz) (by decide) (feed_left hg hk hz hgz).before p op

theorem go_builder (tags : Tags Q Γ) {u} (hu : nf u=true)
    (p : List Bool) (op : Atom (Key Q Γ)) :
    let x := s ⋄ u; let n := cell u
    Span (reader tags) false 4 [true] (builder ⋄ x) (true::p,op)
      ((x ⋄ n) ⋄ n) (p,op) :=
  go_gate tags (builder_gate hu) (by decide) (builder_four hu).before p op

/-- The left sibling of a descriptor is a normal raw tag carrier. It stays
the same through every subsequent round of computation in its right child. -/
theorem tag_pair (tags : Tags Q Γ) (op : Atom (Key Q Γ)) (other : op ≠ .check)
    (k : Desc.Tag Q Γ) {v x : Term} (hv : nf v = true) (hx : nf x = true) :
    Span (reader tags) false 1 [true] (descriptor (marker tags k) v ⋄ x)
      ([],op) (v ⋄ x) (after tags op k) := by
  have ht : nf (s ⋄ marker tags k) = true := by simp [marker]
  apply span_of_gate (pair_gate ht hv hx true) (by decide) (pair_right ht hv hx).before
  · intro i hi
    have h : i=0 := by omega
    subst i
    apply select_wait
    change control tags _ ((summary tags).get x) ([],op) = _
    cases op <;> simp_all [control,summary_normal]
  · intro z i hn
    let l := (s ⋄ marker tags k) ⋄ x
    have hl : nf l = true := by simp [l,marker,hx]
    change control tags ((summary tags).get (rounds i l)) ((summary tags).get z) ([],op) = _
    rw [rounds_fixed hl]
    have label : ((summary tags).get l).label = some k :=
      summary_label tags l k (by simp [l,markerAfter,atPath])
    cases op <;> simp_all [control,summary_normal,descend]

/-- Key extraction never traverses the data payload. The two physical marks
are at constant paths from the frozen left sibling. -/
theorem checkpoint_raw (tags : Tags Q Γ) {u v : Term} (a b : Desc.Tag Q Γ)
    (hu : nf u = true) (hv : nf v = true)
    (ua : atPath u tagPath = some (marker tags a)) (vb : atPath v tagPath = some (marker tags b)) :
    Span (reader tags) true 2 [true] (cell u ⋄ cell v) ([],.check)
      (cell v ⋄ pair u (cell v)) (checkpointNext a b) := by
  have hm : nf (cell v) = true := by simp [hv]
  apply span_of_gate (cell_gate hu hm) (by decide) (cell_right hu hm).before
  · intro i hi
    have cut : i=0 ∨ i=1 := by omega
    rcases cut with rfl | rfl
    · apply select_report
      rw [show rounds 0 (cell u ⋄ cell v) = cell u ⋄ cell v from rfl,move_fork]
      have armed : ((summary tags).get (cell u)).armed = true := by
        rw [summary_armed]; rfl
      simp [control,summary_normal,hv,armed]
    · apply select_wait
      change (reader tags).moveAt _ (pi ((s ⋄ A ⋄ (s ⋄ u)) ⋄ cell v)) = _
      rw [pi_redex nf_A (by simp [hu]) hm,move_fork]
      have armed : ((summary tags).get (A ⋄ cell v)).armed = false := by
        rw [summary_armed]; rfl
      simp [control, armed, summary_normal, hu, hv]
  · intro z i hn
    let l := s ⋄ pair u (cell v)
    have hl : nf l = true := by simp [l,hu,hv]
    change control tags ((summary tags).get (rounds i l)) ((summary tags).get z) ([],.check) = _
    rw [rounds_fixed hl]
    have f := summary_focus tags l a (by exact ua)
    have o := summary_opposite tags l b (by exact vb)
    simp [control,summary_normal,hn,f,o,descend]

theorem encoded_tag (tags : Tags Q Γ) (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ)
    (w : Desc Q Γ) :
    atPath ((encoding tags δ blank).encode w) tagPath = some (marker tags w.tag) := by
  cases w <;> simp [Encoding.encode,Encoding.zeroRaw,descriptor,pair,encoding,tagPath,atPath]

theorem checkpoint_gate (tags : Tags Q Γ) (δ : Q → Γ → Option (Instruction Q Γ)) (blank : Γ)
    (u v : Desc Q Γ) :
    let e := encoding tags δ blank
    Span (reader tags) true 2 [true] (cell (e.encode u) ⋄ cell (e.encode v)) ([],.check)
      (cell (e.encode v) ⋄ pair (e.encode u) (cell (e.encode v))) (checkpointNext u.tag v.tag) :=
  checkpoint_raw tags u.tag v.tag (Encoding.nf_encode _ _) (Encoding.nf_encode _ _)
    (encoded_tag tags δ blank u) (encoded_tag tags δ blank v)


def bound (tags : Tags Q Γ) := (tags.prod tags).items.length + 8
def Fits (tags : Tags Q Γ) (s : State Q Γ) : Prop := s.1.length ≤ bound tags
abbrev Small (tags : Tags Q Γ) := {s : State Q Γ // Fits tags s}

theorem address_short {K} [DecidableEq K] (k : K) (ks : List K) :
    (address k ks).length ≤ ks.length := by
  induction ks with
  | nil => exact Nat.le_refl 0
  | cons a ks ih => by_cases same : k = a <;> simp [address,same] <;> omega

theorem after_fits (tags : Tags Q Γ) (op : Atom (Key Q Γ)) (k : Desc.Tag Q Γ) :
    Fits tags (after tags op k) := by
  cases op with
  | check => simp [Fits,after,bound]
  | lib target =>
    cases v : k.k <;> cases target <;>
      simp [Fits,after,v,bound] <;> (first | apply Nat.le_trans (address_short ..); omega | omega)
  | pop => cases v : k.k <;> simp [Fits,after,v,bound] <;> omega
  | installed empty =>
    cases v : k.k <;> cases empty <;> simp [Fits,after,v,bound] <;> omega

omit [DecidableEq Q] [DecidableEq Γ] in
theorem checkpoint_fits (tags : Tags Q Γ) (a b : Desc.Tag Q Γ) :
    Fits tags (checkpointNext a b) := by simp [Fits,bound,checkpointNext]

def GoodMove (tags : Tags Q Γ) : Move (State Q Γ) → Prop
  | .wait | .report => True
  | .left st | .right st => Fits tags st

theorem control_fits (tags : Tags Q Γ) (l r : Header Q Γ) (q : State Q Γ)
    (hq : Fits tags q) : GoodMove tags (control tags l r q) := by
  rcases q with ⟨p,op⟩
  cases p with
  | cons side rest =>
    have small : Fits tags (rest,op) := by
      change rest.length ≤ bound tags
      change rest.length+1 ≤ bound tags at hq
      omega
    cases side <;> simp [control,descend] <;> split <;> first | exact True.intro | exact small
  | nil =>
    cases op with
    | check =>
      cases hr : r.normal <;> cases hl : l.armed <;> cases hf : l.focus <;> cases ho : l.opposite <;>
        simp [control,hr,hl,hf,ho,GoodMove,checkpoint_fits]
    | lib op =>
      cases hr : r.normal <;> cases h : l.label <;> simp [control,hr,h,GoodMove,after_fits]
    | pop =>
      cases hr : r.normal <;> cases h : l.label <;> simp [control,hr,h,GoodMove,after_fits]
    | installed b =>
      cases hr : r.normal <;> cases h : l.label <;> simp [control,hr,h,GoodMove,after_fits]

private def paths : Nat → List (List Bool)
  | 0 => [[]]
  | n+1 => [] :: ((paths n).map (false :: ·) ++ (paths n).map (true :: ·))

private theorem paths_cover {p n} (h : p.length ≤ n) : p ∈ paths n := by
  induction n generalizing p with
  | zero => cases p <;> simp_all [paths]
  | succ n ih =>
    cases p with
    | nil => simp [paths]
    | cons b p =>
      have hp : p ∈ paths n := ih (by simpa using h)
      cases b <;> simp [paths,hp]

private def atoms (keys : List K) : List (Atom K) :=
  [.check,.lib none,.pop,.installed false,.installed true] ++ keys.map (fun key => .lib (some key))

private theorem atoms_cover {keys : List K} (h : ∀ k, k ∈ keys) (a : Atom K) : a ∈ atoms keys := by
  cases a with
  | check | pop => simp [atoms]
  | installed b => cases b <;> simp [atoms]
  | lib target => cases target <;> simp [atoms,h]

@[instance_reducible] def finiteModes (tags : Tags Q Γ) : FinStates (Small tags) := by
  let keys := tags.prod tags
  let states : List (State Q Γ) :=
    (paths (bound tags)).flatMap (fun p => (atoms keys.items).map (fun a => (p,a)))
  let f (q : State Q Γ) : Option (Small tags) :=
    if h : q.1.length ≤ bound tags then some ⟨q,h⟩ else none
  refine ⟨states.filterMap f,?_⟩
  rintro ⟨⟨p,op⟩,hp⟩
  apply List.mem_filterMap.mpr
  refine ⟨(p,op),List.mem_flatMap.mpr ⟨p,paths_cover hp,?_⟩,?_⟩
  · exact List.mem_map.mpr ⟨op,atoms_cover keys.cover op,rfl⟩
  · simp [f, show p.length ≤ bound tags from hp]

def trim (tags : Tags Q Γ) (q : State Q Γ) : Small tags :=
  ⟨(q.1.take (bound tags),q.2),by simp [Fits,Nat.min_le_left]⟩

omit [DecidableEq Q] [DecidableEq Γ] in
theorem trim_of_fits (tags : Tags Q Γ) {q : State Q Γ} (hq : Fits tags q) :
    trim tags q = ⟨q,hq⟩ := by
  apply Subtype.ext
  simp [trim,List.take_of_length_le (by exact hq : q.1.length ≤ bound tags)]

def smallMove (tags : Tags Q Γ) : Move (State Q Γ) → Move (Small tags)
  | .wait => .wait | .report => .report
  | .left q => .left (trim tags q) | .right q => .right (trim tags q)

def boundedReader (tags : Tags Q Γ) : Reader (Small tags) (summary tags).State :=
  ⟨(summary tags).alg, fun _ => false, fun l r q =>
    smallMove tags (control tags ((summary tags).out l) ((summary tags).out r) q.1)⟩

private def applyMove {M} (left right : M → Option (List Bool)) : Move M → Option (List Bool)
  | .wait => none | .report => some []
  | .left k => (left k).map (false :: ·) | .right k => (right k).map (true :: ·)

theorem bounded_agrees (tags : Tags Q Γ) (t : Term) (q : State Q Γ) (hq : Fits tags q) :
    (boundedReader tags).select t ⟨q,hq⟩ = (reader tags).select t q := by
  induction t generalizing q with
  | s => rfl
  | app a b ia ib =>
    let l := (summary tags).get a
    let r := (summary tags).get b
    let raw := reader tags
    let sm := boundedReader tags
    change applyMove (sm.select a) (sm.select b) (smallMove tags (control tags l r q)) =
      applyMove (raw.select a) (raw.select b) (control tags l r q)
    have good := control_fits tags l r q hq
    cases g : control tags l r q with
    | wait | report => rfl
    | left k =>
      rw [g] at good
      have hh : Fits tags k := good
      simp only [smallMove,applyMove,trim_of_fits tags hh]
      exact congrArg _ (ia k hh)
    | right k =>
      rw [g] at good
      have hh : Fits tags k := good
      simp only [smallMove,applyMove,trim_of_fits tags hh]
      exact congrArg _ (ib k hh)

theorem full_regular (tags : Tags Q Γ) (q : State Q Γ) (hq : Fits tags q) :
    MarkRegular (fun t => ((reader tags).select t.erase q).any t.atPath = true) ∧
    Regular (fun t => ((reader tags).select t q).isSome = true) := by
  classical
  letI := finiteModes tags
  letI := (summary tags).states
  have m := regular_marked_selection (boundedReader tags) (⟨q,hq⟩ : Small tags)
  have d := regular_domain (boundedReader tags) (⟨q,hq⟩ : Small tags)
  simpa only [bounded_agrees] using And.intro m d


end DirectControl

#print axioms DirectControl.full_regular
#print axioms DirectControl.checkpoint_gate
