import DirectTerminal
import BinaryInput
import TapeDecoder

namespace DirectOutput
open DirectMemory DirectPost DirectTerminal Turing TwoScans
open UniversalPost TapeDecoder
abbrev Code := Nat.Partrec.Code
abbrev Physical (P : Type) := Phase (DirectPost.Control P)
abbrev SourceTape (P : Type) := DirectMemory.Tape (Physical P) UniversalPost.Cell

def signal {Q : Type} : Phase Q → Bool
  | .signal => true | _ => false

/-- A signal is produced by one move right without changing the cell.
Read the pre-signal inclusive right tape by observing the new tape one
cell to its left. Everything here is a list operation on the readout. -/
def previousRight {Q Γ : Type} [Inhabited Γ] (t : DirectMemory.Tape Q Γ) : List Γ :=
  let left := if t.control.rightward then t.opposite else t.focus.tail
  let right := if t.control.rightward then t.focus.tail else t.opposite
  left.head?.getD default :: t.focus.head?.getD default :: right

theorem previousRight_spec {Q Γ : Type} [Inhabited Γ] (t : DirectMemory.Tape Q Γ) :
    ListBlank.mk (previousRight t) = ((view t).move .left).right₀ := by
  rcases t with ⟨⟨q,d⟩,f,m⟩
  cases d <;> cases f with
  | nil => cases m <;> rfl
  | cons a f => cases f <;> cases m <;> rfl

theorem source_signal {P : Type} [Inhabited P] (M : TM0.Machine UniversalPost.Cell P)
    (domain : ∀ (c : Code) x, (TM0.eval M (tapeInput c x)).Dom ↔ (c.eval x).Dom)
    (output : ∀ (c : Code) (x y : Nat) t, y ∈ c.eval x → t ∈ TM0.eval M (tapeInput c x) → Outputs t y)
    (c : Code) (x : Nat) (bits : List Bool) :
    (∃ i, let t := clock (DirectTerminal.step (instruction M)) i (liftTape (start (tapeInput c x)))
          t.control.state = .signal ∧ digits (previousRight t) = bits) ↔
      ∃ y ∈ c.eval x, bits = binary y := by
  let δ := instruction M
  let input := start (P:=P) (tapeInput c x)
  constructor
  · rintro ⟨i,hs,he⟩
    let snap := clock (DirectTerminal.step δ) i (liftTape input)
    change snap.control.state = .signal at hs
    change digits (previousRight snap) = bits at he
    obtain ⟨v,hv,whereAt⟩ := (signal_exact δ input snap).mp ⟨i,rfl,hs⟩
    have hout := (eval_tape M (tapeInput c x) (view v).right₀).mpr ⟨v,hv,rfl⟩
    obtain ⟨y,hy⟩ := Part.dom_iff_mem.mp ((domain c x).mp hout.1)
    obtain ⟨L,first,rest⟩ := output c x y _ hy hout
    have right : ListBlank.mk (previousRight snap) = (view v).right₀ := by
      rw [whereAt,previousRight_spec,signal_view]
    exact ⟨y,hy,he ▸ reads _ L y (first.trans right.symm) rest⟩
  · rintro ⟨y,hy,rfl⟩
    obtain ⟨out,ho⟩ := Part.dom_iff_mem.mp ((domain c x).mpr hy.1)
    obtain ⟨v,hv,eq⟩ := (eval_tape M (tapeInput c x) _).mp ho
    obtain ⟨i,atTime,hs⟩ := (signal_exact δ input (signalTape v)).mpr ⟨v,hv,rfl⟩
    obtain ⟨L,first,rest⟩ := output c x y out hy ho
    refine ⟨i,?_⟩
    change (clock (DirectTerminal.step δ) i (liftTape input)).control.state = _ ∧ _
    rw [atTime]
    refine ⟨hs,reads _ L y ?_ rest⟩
    rw [previousRight_spec,signal_view,eq]
    exact first

end DirectOutput
#print axioms DirectOutput.source_signal
