import DirectOutput
import DirectTrajectoryQueries
import DirectCost

/-! Direct universality with a fixed source transition table compiled into the
ground S seed, and a reader taking only a finite alphabet, never that table. -/
set_option linter.style.haveILetI false
namespace DirectCertified
open TwoScans TwoScans.Frames TwoScans.Automata Turing
open DirectMemory DirectMemory.Compiled DirectTerminal DirectPost
open DirectTrajectory DirectOutput DirectControl

def alphabet (α : Type) [FinStates α] : Alphabet α :=
  ⟨FinStates.enum,FinStates.covers⟩

def symbols (P : Type) [FinStates P] : Tags (Physical P) UniversalPost.Cell :=
  Alphabet.tags (phases ((alphabet P).prod Alphabet.bools)) (alphabet UniversalPost.Cell)

def encode {P : Type} [FinStates P] [DecidableEq P] [Inhabited P]
    (M : TM0.Machine UniversalPost.Cell P) (p x : List Bool) : Term :=
  seed (symbols P) (extend (instruction M)) default (liftTape (start (BinaryInput.tape p x)))

def outputBits {P : Type} (c : SourceTape P) : List Bool :=
  (TapeDecoder.digits (previousRight c)).dropLast

/-- Defined on all raw trees. A malformed payload at a selected signal has
a fixed default; on a seed orbit, hit_iff and all_snapshots give a real tape. -/
def read (P : Type) [FinStates P] [DecidableEq P] (t : Term) : Option (List Bool) :=
  if DirectQueries.hit (symbols P) signal t then
    some (((readSnapshot (symbols P) t).map outputBits).getD [])
  else none

theorem read_regular (P : Type) [FinStates P] [DecidableEq P] :
    Regular (fun t => ∃ y, read P t = some y) := by
  obtain ⟨s,fs,a,b,h⟩ := DirectQueries.hit_regular (symbols P) signal
  refine ⟨s,fs,a,b,fun t => (h t).trans ?_⟩
  cases eq : DirectQueries.hit (symbols P) signal t <;> simp [read,eq]

theorem encode_linear {P : Type} [FinStates P] [DecidableEq P] [Inhabited P]
    (M : TM0.Machine UniversalPost.Cell P) :
    ∃ a b, ∀ p x, size (encode M p x) ≤ a + b*(p.length+x.length) := by
  obtain ⟨a,b,cap⟩ := linear_seed (symbols P) (extend (instruction M)) default
  refine ⟨a+b*3,b,?_⟩
  intro p x
  have z := cap (liftTape (start (P:=P) (BinaryInput.tape p x)))
  simpa [encode,liftTape,start,BinaryInput.tape_size,Nat.mul_add,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using z

private theorem reported {P : Type} [FinStates P] [DecidableEq P] [Inhabited P]
    (M : TM0.Machine UniversalPost.Cell P) (c : SourceTape P) (y : List Bool) :
    (∃ n, read P (rounds n (seed (symbols P) (extend (instruction M)) default c)) = some y) ↔
    ∃ i, let v := clock (DirectTerminal.step (instruction M)) i c
         v.control.state = .signal ∧ outputBits v = y := by
  let m := extend (instruction M)
  let s := symbols P
  have test (v : SourceTape P) : signal v.control.state = true ↔ v.control.state = .signal := by
    cases v.control.state <;> simp [signal]
  have one (n) (v : SourceTape P) (seen : readSnapshot s (rounds n (seed s m default c)) = some v)
      (hs : v.control.state = .signal) : read P (rounds n (seed s m default c)) = some (outputBits v) := by
    unfold read
    rw [hit_iff s m default c signal n,seen]
    simp [test v |>.mpr hs]
  constructor
  · rintro ⟨n,h⟩
    unfold read at h
    rw [hit_iff s m default c signal n] at h
    cases hv : readSnapshot s (rounds n (seed s m default c)) with
    | none => simp [hv] at h
    | some v =>
      by_cases hs : signal v.control.state = true
      · change readSnapshot (symbols P) (rounds n (seed (symbols P) (extend (instruction M)) default c)) = some v at hv
        have he : outputBits v = y := by simpa [s,m,hv,hs] using h
        obtain ⟨i,hi⟩ := (read_graph s m default c v).mp ⟨n,hv⟩
        exact ⟨i, hi ▸ (test v |>.mp hs), hi ▸ he⟩
      · simp [hv,hs] at h
  · rintro ⟨i,hs,he⟩
    let v := clock (DirectTerminal.step (instruction M)) i c
    obtain ⟨n,hn⟩ := (read_graph s m default c v).mpr ⟨i,rfl⟩
    exact ⟨n,(one n v hn hs).trans (congrArg some he)⟩

/-- Every partial computable function on binary words is realized on a
single canonical schedule. The actual encoder, finite detector, and decoder
are fixed before the partial function is quantified. -/
theorem universality :
    ∃ (P : Type) (fp : FinStates P) (dp : DecidableEq P) (st : Inhabited P)
      (M : @TM0.Machine UniversalPost.Cell P st) (a b : Nat), letI := fp; letI := dp; letI := st
      Regular (fun t => ∃ y, read P t = some y) ∧
      (∀ p x, size (encode M p x) ≤ a + b*(p.length+x.length)) ∧
      ∀ f : List Bool →. List Bool, Partrec f → ∃ p : List Bool, ∀ x y,
        (∃ n, read P (rounds n (encode M p x)) = some y) ↔ y ∈ f x := by
  obtain ⟨P,fp,dp,q,M,dom,out⟩ := FiniteUniversalPost.finite_universal
  letI := fp
  letI := dp
  letI : Inhabited P := ⟨q⟩
  obtain ⟨a,b,hcap⟩ := encode_linear M
  refine ⟨P,fp,dp,⟨q⟩,M,a,b,read_regular P,hcap,?_⟩
  intro f hf
  obtain ⟨c,pg⟩ := StringCoding.program hf
  refine ⟨BinaryInput.program c,?_⟩
  intro x y
  unfold encode
  rw [BinaryInput.source_tape,reported]
  let init := liftTape (start (P:=P) (UniversalPost.tapeInput c (StringCoding.pack x)))
  let run := fun i => clock (DirectTerminal.step (instruction M)) i init
  constructor
  · rintro ⟨i,hs,he⟩
    let bits := TapeDecoder.digits (previousRight (run i))
    obtain ⟨k,hk,bk⟩ := (source_signal M dom out c (StringCoding.pack x) bits).mp ⟨i,hs,rfl⟩
    rw [pg] at hk
    obtain ⟨z,hz,rfl⟩ := (Part.mem_map_iff _).mp hk
    rw [StringCoding.binary_pack] at bk
    change bits.dropLast = y at he
    have eq : z = y := by simpa [bk] using he
    exact eq ▸ hz
  · intro hy
    have hy' : StringCoding.pack y ∈ c.eval (StringCoding.pack x) := by
      rw [pg]
      exact (Part.mem_map_iff _).mpr ⟨y,hy,rfl⟩
    obtain ⟨i,hs,hyb⟩ := (source_signal M dom out c (StringCoding.pack x) _).mpr
      ⟨StringCoding.pack y,hy',rfl⟩
    exact ⟨i,hs,by simp [outputBits,hyb,StringCoding.binary_pack]⟩

end DirectCertified
#print axioms DirectCertified.universality
