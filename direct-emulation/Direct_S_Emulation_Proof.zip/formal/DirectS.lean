import Frames

/-! Direct, located macrosteps on the existing ground-S parallel innermost orbit.
A path is read from the root of the current tree; false means left and true right. -/
namespace DirectS
open TwoScans TwoScans.Term TwoScans.Frames
local infixl:65 " ·ₛ " => Term.app

def pair (a b : Term) := s ·ₛ a ·ₛ b
def cell (u : Term) := B ·ₛ (s ·ₛ u)
def descriptor (tag payload : Term) := pair (s ·ₛ tag) payload
def feed (g k : Term) := pair (s ·ₛ k) g
def builder := pair (pair A B) B
def install (tag : Term) := feed (s ·ₛ (s ·ₛ tag)) (feed s builder)

def atPath : Term → List Bool → Option Term
  | t, [] => some t
  | app l _, false :: p => atPath l p
  | app _ r, true :: p => atPath r p
  | s, _ :: _ => none

theorem path_append {t u v p q}
    (hp : atPath t p = some u) (hq : atPath u q = some v) :
    atPath t (p ++ q) = some v := by
  induction p generalizing t with
  | nil => simpa [atPath] using (by simpa [atPath] using hp : t = u) ▸ hq
  | cons b p ih =>
    cases t with
    | s => simp [atPath] at hp
    | app l r => cases b <;> exact ih hp

theorem inactive_child_impossible {t u p} (h : atPath t p = some u) (hu : nf u = false) :
    nf t = false := by
  induction p generalizing t with
  | nil => simpa [atPath] using (by simpa [atPath] using h : t = u) ▸ hu
  | cons b p ih =>
    cases t with
    | s => simp [atPath] at h
    | app l r =>
      cases b with
      | false => simp [nf, ih (t := l) h]
      | true => simp [nf, ih (t := r) h]

theorem pi_at_active {t u p} (h : atPath t p = some u) (hu : nf u = false) :
    atPath (pi t) p = some (pi u) := by
  induction p generalizing t with
  | nil => simpa [atPath] using congrArg (some ∘ pi) (by simpa [atPath] using h : t = u)
  | cons b p ih =>
    cases t with
    | s => simp [atPath] at h
    | app l r =>
      cases b with
      | false =>
        have hn := inactive_child_impossible (p := p) (t := l) h hu
        simpa [pi, hn, atPath] using ih (t := l) h
      | true =>
        have hn := inactive_child_impossible (p := p) (t := r) h hu
        simpa [pi, hn, atPath] using ih (t := r) h

/-- Position p remains valid while the selected subtree still has work.
    Its siblings can evolve freely. The last selected subtree can be normal. -/
theorem rounds_at_active {t u p} (n : Nat) (h : atPath t p = some u)
    (active : ∀ j < n, nf (rounds j u) = false) :
    atPath (rounds n t) p = some (rounds n u) := by
  induction n generalizing t u with
  | zero => exact h
  | succ n ih =>
    exact ih (pi_at_active h (active 0 (by omega))) (fun j hj => active (j+1) (by omega))

def Reaches (n : Nat) (p : List Bool) (t u : Term) :=
  atPath (rounds n t) p = some u

structure Track (n : Nat) (p : List Bool) (t u : Term) : Prop where
  located : Reaches n p t u
  before : ∀ j < n, nf (rounds j t) = false

theorem Track.refl (t : Term) : Track 0 [] t t := ⟨by cases t <;> rfl, by omega⟩

theorem Track.comp {i j p q t u v} (first : Track i p t u) (next : Track j q u v) :
    Track (i+j) (p++q) t v := by
  constructor
  · unfold Reaches
    rw [rounds_add]
    exact path_append (rounds_at_active j first.located next.before) next.located
  · intro k hk
    by_cases earlier : k < i
    · exact first.before k earlier
    · obtain ⟨l,rfl⟩ := Nat.exists_eq_add_of_le (Nat.le_of_not_lt earlier)
      rw [rounds_add]
      apply inactive_child_impossible (rounds_at_active l first.located (by
        intro a ha; exact next.before a (by omega)))
      exact next.before l (by omega)

theorem Track.one {p t u} (active : nf t = false) (loc : atPath (pi t) p = some u) :
    Track 1 p t u := ⟨loc, by intro j hj; have := Nat.eq_zero_of_le_zero (show j ≤ 0 by omega); subst j; exact active⟩

@[simp] theorem nf_s : nf s = true := rfl
@[simp] theorem nf_s1 (x) : nf (s ·ₛ x) = nf x := by simp [nf,root]
@[simp] theorem nf_pair (x y) : nf (pair x y) = (nf x && nf y) := by simp [pair,nf,root]
@[simp] theorem nf_s2 (x y) : nf (s ·ₛ x ·ₛ y) = (nf x && nf y) := nf_pair x y
@[simp] theorem nf_redex (x y z) : nf (s ·ₛ x ·ₛ y ·ₛ z) = false := by simp [nf,root]
@[simp] theorem nf_cell (x) : nf (cell x) = nf x := by simp [cell,B,A]
@[simp] theorem nf_descriptor (k h) : nf (descriptor k h) = (nf k && nf h) := by simp [descriptor]
@[simp] theorem nf_A : nf A = true := rfl
@[simp] theorem nf_B : nf B = true := rfl
@[simp] theorem nf_builder : nf builder = true := rfl
@[simp] theorem nf_feed (g k) : nf (feed g k) = (nf k && nf g) := by simp [feed]

theorem pi_redex {a b x : Term} (ha : nf a = true) (hb : nf b = true) (hx : nf x = true) :
    pi (s ·ₛ a ·ₛ b ·ₛ x) = (a ·ₛ x) ·ₛ (b ·ₛ x) := by
  simp [pi,root,ha,hb,hx]

theorem pair_left {a b x : Term} (ha : nf a = true) (hb : nf b = true) (hx : nf x = true) :
    Track 1 [false] (pair a b ·ₛ x) (a ·ₛ x) := by
  apply Track.one (by simp [pair])
  simp [pair,pi_redex ha hb hx,atPath]

theorem pair_right {a b x : Term} (ha : nf a = true) (hb : nf b = true) (hx : nf x = true) :
    Track 1 [true] (pair a b ·ₛ x) (b ·ₛ x) := by
  apply Track.one (by simp [pair])
  simp [pair,pi_redex ha hb hx,atPath]

theorem root_step {a b x : Term} (ha : nf a = true) (hb : nf b = true) (hx : nf x = true) :
    Track 1 [] (pair a b ·ₛ x) ((a ·ₛ x) ·ₛ (b ·ₛ x)) := by
  apply Track.one (by simp [pair])
  simp [pair,pi_redex ha hb hx,atPath]

/-- This exact tree retains the normal environment (u,m) in the left branch. -/
theorem cell_rounds {u m : Term} (hu : nf u = true) (hm : nf m = true) :
    rounds 2 (cell u ·ₛ m) = (s ·ₛ pair u m) ·ₛ (m ·ₛ pair u m) := by
  change pi (pi ((s ·ₛ A ·ₛ (s ·ₛ u)) ·ₛ m)) = _
  rw [pi_redex nf_A (by simp [hu]) hm]
  simp only [A, pair]
  exact pi_redex nf_s hm (by simp [hu,hm])

theorem cell_right {u m : Term} (hu : nf u = true) (hm : nf m = true) :
    Track 2 [true] (cell u ·ₛ m) (m ·ₛ pair u m) := by
  have first := root_step nf_A (show nf (s ·ₛ u) = true by simp [hu]) hm
  have second := pair_right nf_s hm (show nf (pair u m) = true by simp [hu,hm])
  exact first.comp second

theorem feed_left {g k z : Term} (hg : nf g = true) (hk : nf k = true)
    (hz : nf z = true) (hgz : nf (g ·ₛ z) = true) :
    Track 2 [false] (feed g k ·ₛ z) (k ·ₛ (g ·ₛ z)) := by
  exact (root_step (show nf (s ·ₛ k) = true by simp [hk]) hg hz).comp (pair_left hk hz hgz)

/-- One contraction in the left child while a normal right child stays in place. -/
theorem root_below_left {a b x r : Term} (ha : nf a = true) (hb : nf b = true)
    (hx : nf x = true) (hr : nf r = true) :
    Track 1 [] ((pair a b ·ₛ x) ·ₛ r) (((a ·ₛ x) ·ₛ (b ·ₛ x)) ·ₛ r) := by
  have active : nf (pair a b ·ₛ x) = false := by simp [pair]
  refine Track.one (by change (_ && nf (pair a b ·ₛ x) && nf r) = false; simp only [active, Bool.and_false, Bool.false_and]) ?_
  change some (if nf (pair a b ·ₛ x) && nf r then _ else _) = _
  simp [pair, pi_redex ha hb hx, fixed hr]

/-- Four steps in the builder. Both spurious (n n) and genuine right residual
    are shown in the same exact parallel snapshot. -/
theorem builder_four {u : Term} (hu : nf u = true) :
    let x := s ·ₛ u
    let n := B ·ₛ x
    Track 4 [] (builder ·ₛ x) ((n ·ₛ n) ·ₛ ((x ·ₛ n) ·ₛ n)) := by
  let x := s ·ₛ u
  let n := B ·ₛ x
  have hx : nf x = true := by simp [x,hu]
  have hn : nf n = true := by simp [n,B,hx]
  have hxn : nf (x ·ₛ n) = true := by simp [x,hn,hu]
  have b1 := root_step (show nf (pair A B) = true by simp) nf_B hx
  have b2 := root_below_left nf_A nf_B hx hn
  have b3 := root_below_left nf_s hx hn hn
  have b4 := root_step hn hxn hn
  exact ((b1.comp b2).comp b3).comp b4

/-- The selected branch at step four is the right branch. -/
theorem builder_right {u : Term} (hu : nf u = true) :
    let x := s ·ₛ u
    let n := B ·ₛ x
    Track 4 [true] (builder ·ₛ x) ((x ·ₛ n) ·ₛ n) := by
  let h := builder_four hu
  constructor
  · exact path_append h.located (by rfl : atPath _ [true] = some _)
  · exact h.before

/-- S itself builds the new cell n and applies the old (normal) payload h to
    n after exactly ten rounds along LLRLR. No decoder participates. -/
theorem install_reaches {tag h : Term} (ht : nf tag = true) (hh : nf h = true) :
    Track 10 [false,false,true,false,true] (install tag ·ₛ h)
      (h ·ₛ cell (descriptor tag h)) := by
  let u := descriptor tag h
  let x := s ·ₛ u
  let n := cell u
  have hu : nf u = true := by simp [u,ht,hh]
  have hx : nf x = true := by simp [x,hu]
  have hn : nf n = true := by simp [n,hu]
  have f1 := feed_left (show nf (s ·ₛ (s ·ₛ tag)) = true by simp [ht])
    (show nf (feed s builder) = true by simp) hh hu
  have f2 := feed_left nf_s nf_builder hu hx
  have f3 := builder_right hu
  have f4 := pair_left hu hn hn
  have f5 := pair_right (show nf (s ·ₛ tag) = true by simp [ht]) hh hn
  exact (((f1.comp f2).comp f3).comp f4).comp f5

/-- Normal step environment retaining v, u and the old counterstack m=C(v). -/
def env (u v : Term) := pair v (pair v (pair u (cell v)))

@[simp] theorem nf_env {u v} (hu : nf u = true) (hv : nf v = true) :
    nf (env u v) = true := by simp [env,hu,hv]

theorem checkpoint_to_descriptor {u v : Term} (hu : nf u = true) (hv : nf v = true) :
    Track 8 [true,true,true,true,false] (cell u ·ₛ cell v) (v ·ₛ env u v) := by
  let m := cell v
  let e := pair u m
  let j := pair v e
  let h := pair v j
  have hm : nf m = true := by simp [m,hv]
  have he : nf e = true := by simp [e,hu,hm]
  have hj : nf j = true := by simp [j,hv,he]
  have hh : nf h = true := by simp [h,hv,hj]
  have a := cell_right hu hm
  have b := cell_right hv he
  have c := pair_right hu hm hj
  have d := cell_right hv hj
  have f := pair_left hv he hh
  exact (((a.comp b).comp c).comp d).comp f

theorem env_to_counter {u v x : Term} (hu : nf u = true) (hv : nf v = true)
    (hx : nf x = true) :
    Track 3 [true,true,true] (env u v ·ₛ x) (cell v ·ₛ x) := by
  have he : nf (pair u (cell v)) = true := by simp [hu,hv]
  have hj : nf (pair v (pair u (cell v))) = true := by simp [hv,he]
  exact ((pair_right hv hj hx).comp (pair_right hv he hx)).comp
        (pair_right hu (by simpa using hv) hx)

theorem env_to_focus {u v x : Term} (hu : nf u = true) (hv : nf v = true)
    (hx : nf x = true) :
    Track 3 [true,true,false] (env u v ·ₛ x) (u ·ₛ x) := by
  have he : nf (pair u (cell v)) = true := by simp [hu,hv]
  have hj : nf (pair v (pair u (cell v))) = true := by simp [hv,he]
  exact ((pair_right hv hj hx).comp (pair_right hv he hx)).comp
        (pair_left hu (by simpa using hv) hx)

/-- A finite table of cell constructors, with one addressed branch per bit.
    The reduction schedule traverses both branches. The path identifies one. -/
inductive Dispatch where
  | leaf (tag : Term)
  | branch (left right : Dispatch)

namespace Dispatch

def compile : Dispatch → Term
  | .leaf tag => install tag
  | .branch l r => pair l.compile r.compile

def normalTags : Dispatch → Prop
  | .leaf tag => nf tag = true
  | .branch l r => normalTags l ∧ normalTags r

inductive Entry : Dispatch → List Bool → Term → Prop where
  | leaf (tag) : Entry (.leaf tag) [] tag
  | left {l r p tag} : Entry l p tag → Entry (.branch l r) (false :: p) tag
  | right {l r p tag} : Entry r p tag → Entry (.branch l r) (true :: p) tag

theorem compiled_normal {table : Dispatch} (h : table.normalTags) :
    nf table.compile = true := by
  induction table with
  | leaf tag => simpa [compile,install,normalTags] using h
  | branch l r ihl ihr => exact (nf_pair _ _).trans (by simp [ihl h.1, ihr h.2])

theorem Entry.tag_normal {table p tag} (e : Entry table p tag) (h : table.normalTags) :
    nf tag = true := by
  induction e with
  | leaf => exact h
  | left _ ih => exact ih h.1
  | right _ ih => exact ih h.2

/-- The addressed leaf receives the original argument after exactly one
    parallel round per address bit. -/
theorem Entry.located {table p tag x} (e : Entry table p tag)
    (h : table.normalTags) (hx : nf x = true) :
    Track p.length p (table.compile ·ₛ x) (install tag ·ₛ x) := by
  induction e with
  | leaf tag => exact Track.refl _
  | @left l r p tag ent ih =>
    simpa [compile,Nat.add_comm] using
      (pair_left (compiled_normal h.1) (compiled_normal h.2) hx).comp (ih h.1)
  | @right l r p tag ent ih =>
    simpa [compile,Nat.add_comm] using
      (pair_right (compiled_normal h.1) (compiled_normal h.2) hx).comp (ih h.2)

theorem Entry.install {table p tag x} (e : Entry table p tag)
    (h : table.normalTags) (hx : nf x = true) :
    Track (p.length + 10) (p ++ [false,false,true,false,true])
      (table.compile ·ₛ x) (x ·ₛ cell (descriptor tag x)) :=
  (e.located h hx).comp (install_reaches (e.tag_normal h) hx)

end Dispatch

/-- A finite certificate for the library in the history of a counterstack.
    Initial descriptors keep it explicitly. A new node captures its predecessor
    in field 1 of its saved step environment. -/
inductive LibraryOrigin (lib : Term) : Term → Prop where
  | base {tag tail} (ht : nf tag = true) (hr : nf tail = true) :
      LibraryOrigin lib (descriptor tag (pair lib tail))
  | built {tag u v} (ht : nf tag = true) (hu : nf u = true)
      (old : LibraryOrigin lib v) : LibraryOrigin lib (descriptor tag (env u v))

theorem LibraryOrigin.normal {lib v} (origin : LibraryOrigin lib v) (hl : nf lib = true) :
    nf v = true := by
  induction origin with
  | base ht hr => simp [ht,hr,hl]
  | built ht hu _ ih => simp [ht,hu,ih]

/-- Library search is a finite sequence of genuine native contractions with
    x kept unchanged even when many built counterstack descriptors intervene. -/
theorem LibraryOrigin.find {lib v x} (origin : LibraryOrigin lib v)
    (hl : nf lib = true) (hx : nf x = true) :
    ∃ n p, Track n p (v ·ₛ x) (lib ·ₛ x) := by
  induction origin with
  | base ht hr =>
    refine ⟨2,[true,false],?_⟩
    exact (pair_right (by simp [ht]) (by simp [hl,hr]) hx).comp (pair_left hl hr hx)
  | @built tag u v ht hu old ih =>
    obtain ⟨n,p,h⟩ := ih
    have hv := old.normal hl
    have envNorm := nf_env hu hv
    have right := pair_right (show nf (s ·ₛ tag) = true by simp [ht]) envNorm hx
    have sel := pair_left hv (show nf (pair v (pair u (cell v))) = true by simp [hv,hu]) hx
    exact ⟨_,_,(right.comp sel).comp h⟩

/-- A complete native trip from a checkpoint through its retained library and
    a selected finite table leaf to a newly allocated cell. -/
theorem construct_from_checkpoint {table : Dispatch} {p tag z u v}
    (hn : table.normalTags) (entry : table.Entry p tag)
    (hz : nf z = true) (hu : nf u = true)
    (origin : LibraryOrigin (pair table.compile z) v) :
    ∃ k q, Track k q (cell u ·ₛ cell v)
      (env u v ·ₛ cell (descriptor tag (env u v))) := by
  have hg := Dispatch.compiled_normal hn
  have hlib : nf (pair table.compile z) = true := by simp [hg,hz]
  have hv := origin.normal hlib
  have he := nf_env hu hv
  obtain ⟨m,q,libStep⟩ := origin.find hlib he
  have lookup := pair_left hg hz he
  exact ⟨_,_,(((checkpoint_to_descriptor hu hv).comp libStep).comp lookup).comp
    (entry.install hn he)⟩


end DirectS

#print axioms DirectS.rounds_at_active
#print axioms DirectS.install_reaches
#print axioms DirectS.checkpoint_to_descriptor
